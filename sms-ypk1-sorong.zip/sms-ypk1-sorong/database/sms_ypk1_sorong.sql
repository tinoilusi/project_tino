-- =====================================================================
-- DATABASE: SISTEM MANAJEMEN SEKOLAH & ABSENSI QR CODE
-- SMAS YPK 1 SORONG - NPSN 60403645
-- =====================================================================
-- CARA IMPORT:
-- 1. Buka phpMyAdmin -> New -> beri nama "db_sms_ypk1_sorong" -> Create
-- 2. Klik tab Import -> pilih file ini -> Go
-- ATAU lewat terminal:
--    mysql -u root -p -e "CREATE DATABASE db_sms_ypk1_sorong"
--    mysql -u root -p db_sms_ypk1_sorong < sms_ypk1_sorong.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS db_sms_ypk1_sorong CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_sms_ypk1_sorong;

-- ---------------------------------------------------------------------
-- TABEL PENGATURAN (jam masuk/pulang, identitas sekolah, dsb)
-- ---------------------------------------------------------------------
CREATE TABLE pengaturan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_pengaturan VARCHAR(100) NOT NULL UNIQUE,
  nilai_pengaturan VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

INSERT INTO pengaturan (nama_pengaturan, nilai_pengaturan) VALUES
('nama_sekolah', 'SMAS YPK 1 Sorong'),
('npsn', '60403645'),
('alamat_sekolah', 'Jl. Mawar Klademak 3, Kel. Klademak (Kampung Baru), Distrik Sorong Kota, Kota Sorong, Papua Barat Daya'),
('email_sekolah', 'smuypk_ebenhaizer@yahoo.com'),
('naungan_yayasan', 'YPK DI TANAH PAPUA'),
('jam_masuk', '07:30:00'),
('jam_pulang', '13:45:00'),
('toleransi_terlambat_menit', '15'),
('pulang_buka_menit_sebelum', '0'),
('zona_waktu', 'WIT (Asia/Jayapura)'),
('logo_sekolah', ''),
('background_sekolah', ''),
('warna_tema', 'navy');

-- ---------------------------------------------------------------------
-- TAHUN AJARAN & SEMESTER
-- ---------------------------------------------------------------------
CREATE TABLE tahun_ajaran (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tahun VARCHAR(15) NOT NULL,              -- contoh: 2026/2027
  semester ENUM('Ganjil','Genap') NOT NULL,
  status_aktif TINYINT(1) NOT NULL DEFAULT 0,
  tanggal_mulai DATE DEFAULT NULL,
  tanggal_selesai DATE DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO tahun_ajaran (tahun, semester, status_aktif, tanggal_mulai) VALUES
('2026/2027', 'Ganjil', 1, '2026-07-13');

-- ---------------------------------------------------------------------
-- KELAS  (kelas_lanjutan_id = kelas tujuan saat naik kelas, NULL = lulus)
-- ---------------------------------------------------------------------
CREATE TABLE kelas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_kelas VARCHAR(50) NOT NULL,
  tingkat INT NOT NULL,                    -- 10, 11, 12
  jurusan VARCHAR(50) DEFAULT NULL,
  wali_kelas_id INT DEFAULT NULL,
  kelas_lanjutan_id INT DEFAULT NULL,
  tahun_ajaran_id INT DEFAULT NULL,
  FOREIGN KEY (kelas_lanjutan_id) REFERENCES kelas(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Sesuai Daftar Peserta Didik resmi sekolah: 3 kelas (X, XI A, XII).
-- Jika ke depan kelas XI dibagi per jurusan, tinggal tambah kelas baru
-- lewat menu Manajemen Sekolah -> Data Kelas.
INSERT INTO kelas (id, nama_kelas, tingkat, jurusan) VALUES
(1, 'X', 10, NULL),
(2, 'XI A', 11, NULL),
(4, 'XII', 12, NULL);

-- default alur kenaikan kelas (bisa diubah kepala sekolah di menu Kelas)
UPDATE kelas SET kelas_lanjutan_id = 2 WHERE id = 1;   -- X -> XI A
UPDATE kelas SET kelas_lanjutan_id = 4 WHERE id = 2;   -- XI A -> XII
UPDATE kelas SET kelas_lanjutan_id = NULL WHERE id = 4; -- XII -> LULUS

-- ---------------------------------------------------------------------
-- PEGAWAI (Kepala Sekolah, Guru, Tata Usaha, Penjaga Sekolah)
-- ---------------------------------------------------------------------
CREATE TABLE pegawai (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nip_nuptk VARCHAR(30) DEFAULT NULL,
  nama VARCHAR(100) NOT NULL,
  jenis ENUM('Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah') NOT NULL,
  status_kepegawaian ENUM('PNS','Honorer') NOT NULL DEFAULT 'Honorer',
  jenis_kelamin ENUM('L','P') DEFAULT 'L',
  no_hp VARCHAR(20) DEFAULT NULL,
  alamat VARCHAR(255) DEFAULT NULL,
  foto VARCHAR(255) DEFAULT NULL,
  qr_token VARCHAR(64) NOT NULL UNIQUE,
  status_aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 1 Kepala Sekolah + 11 Guru + 1 Tata Usaha + 1 Penjaga Sekolah = 14 pegawai
INSERT INTO pegawai (nama, jenis, status_kepegawaian, qr_token) VALUES
('Juliana Pattipelohy', 'Kepala Sekolah', 'PNS', 'PEG-KEPSEK-JULIANA-001'),
('Guru 1', 'Guru', 'PNS', 'PEG-GURU-002'),
('Guru 2', 'Guru', 'PNS', 'PEG-GURU-003'),
('Guru 3', 'Guru', 'PNS', 'PEG-GURU-004'),
('Guru 4', 'Guru', 'PNS', 'PEG-GURU-005'),
('Guru 5', 'Guru', 'Honorer', 'PEG-GURU-006'),
('Guru 6', 'Guru', 'Honorer', 'PEG-GURU-007'),
('Guru 7', 'Guru', 'Honorer', 'PEG-GURU-008'),
('Guru 8', 'Guru', 'Honorer', 'PEG-GURU-009'),
('Guru 9', 'Guru', 'Honorer', 'PEG-GURU-010'),
('Guru 10', 'Guru', 'Honorer', 'PEG-GURU-011'),
('Guru 11', 'Guru', 'Honorer', 'PEG-GURU-012'),
('Selly Baselisa Bille', 'Tata Usaha', 'Honorer', 'PEG-TU-SELLY-013'),
('Penjaga Sekolah', 'Penjaga Sekolah', 'Honorer', 'PEG-PENJAGA-014');

-- tetapkan wali kelas (guru id 2,3,5 -> kelas X, XI A, XII). Bisa diubah kepala sekolah.
UPDATE kelas SET wali_kelas_id = 2 WHERE id = 1;  -- Kelas X
UPDATE kelas SET wali_kelas_id = 3 WHERE id = 2;  -- Kelas XI A
UPDATE kelas SET wali_kelas_id = 5 WHERE id = 4;  -- Kelas XII

-- ---------------------------------------------------------------------
-- SISWA
-- ---------------------------------------------------------------------
CREATE TABLE siswa (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nis VARCHAR(20) NOT NULL UNIQUE,
  nisn VARCHAR(20) DEFAULT NULL,
  nik VARCHAR(20) DEFAULT NULL,
  nama VARCHAR(100) NOT NULL,
  jenis_kelamin ENUM('L','P') DEFAULT 'L',
  tempat_lahir VARCHAR(100) DEFAULT NULL,
  tanggal_lahir DATE DEFAULT NULL,
  alamat VARCHAR(255) DEFAULT NULL,
  nama_ortu VARCHAR(100) DEFAULT NULL,
  no_hp_ortu VARCHAR(20) DEFAULT NULL,
  kelas_id INT DEFAULT NULL,
  foto VARCHAR(255) DEFAULT NULL,
  qr_token VARCHAR(64) NOT NULL UNIQUE,
  status ENUM('Aktif','Lulus','Pindah','Keluar') NOT NULL DEFAULT 'Aktif',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Data 40 siswa AKTIF sesuai Daftar Peserta Didik resmi SMAS YPK 1 Sorong
-- (sumber: dokumen PDF per 23 Agustus 2026, ditandatangani Kepala Sekolah).
-- Catatan: NIS (nomor induk sekolah) tidak tercantum di dokumen sumber,
-- sehingga dibuat otomatis oleh sistem (format 2026xxx/2025xxx/2024xxx).
-- Jenis kelamin diperkirakan dari nama depan (dokumen sumber tidak
-- mencantumkan kolom ini) -- mohon dicek & diperbaiki lewat menu Data Siswa.
-- 2 data ganda pada dokumen asli (Emerikus Wafom tercatat 2x, dan
-- Marvel David Sanadi tercatat di 2 kelas berbeda dengan NIK sama)
-- sudah dirapikan menjadi 1 data masing-masing.

INSERT INTO siswa (nis, nisn, nik, nama, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, nama_ortu, kelas_id, qr_token) VALUES
('2026001', '0073151958', '9271034904070001', 'Aplenia Duwith', 'P', 'Sorong', '2007-04-09', 'Jalan Danau Swiki', 'Elisabeth Blesia', 1, 'SIS-2026001'),
('2026002', '0081934729', '9271030511080004', 'Ehud Albertho Safes Trogea', 'L', 'Sorong', '2008-11-05', 'Danau Swiki', 'Penina Jarfi', 1, 'SIS-2026002'),
('2026003', '0112461891', '9271010403110003', 'Israel Almendo Marvel Rastafara Tuhehay', 'L', 'Manado', '2011-03-04', 'Jl. Tulip No. 08', 'Gyta Praditia Ariani', 1, 'SIS-2026003'),
('2026004', '0092626868', '9671010903090001', 'Markus Marthen Albertho Ogabuy', 'L', 'Sorong', '2009-03-09', 'Klademak III B', 'Ester Elisabeth Ogabuy', 1, 'SIS-2026004'),
('2026005', '0096526341', '9271061803090003', 'Marvel David Sanadi', 'L', 'Sorong', '2009-03-18', 'Jl. Rejauw', 'Agustina Emauri', 1, 'SIS-2026005'),
('2026006', '0105177017', '9206146807100001', 'Virdalina Talenta Siwana', 'P', 'Sorong', '2010-07-28', 'Tanah Merah', 'Anace Ginuny', 1, 'SIS-2026006'),
('2026007', '0108714955', '9271011407100001', 'Yoppi Metusala Baransano', 'L', 'Kasim', '2010-07-14', 'Jl. Teratai, Klademak', 'Afsalomina Rumaikeo', 1, 'SIS-2026007'),
('2026008', NULL, NULL, 'Heldita Ellesia Sesa', 'P', 'Sorong', '2010-01-25', 'Puncak Cendrawasih', 'Yustinus Sesa', 1, 'SIS-2026008'),
('2026009', NULL, NULL, 'Brian Momot', 'L', NULL, NULL, NULL, NULL, 1, 'SIS-2026009'),
('2025101', '0092720058', '9271011509100004', 'Polli Henri Tao', 'L', 'Sorong', '2009-09-15', 'Jl. Menur', 'Enggle Reni Rirei', 2, 'SIS-2025101'),
('2025102', '0056821525', '9271061108050003', 'Agustus Alexander Tonjau', 'L', 'Jayapura', '2006-12-26', 'Jl. Feri Lurus Pantai', 'Karolina L. Tonjau', 2, 'SIS-2025102'),
('2025103', '0107699546', '9271032409100002', 'Amo Henry Andreuw Mayor', 'L', 'Sorong', '2010-09-24', 'R.A Kartini', 'Hetreda K. Herlince', 2, 'SIS-2025103'),
('2025104', '0088020050', '9271030804100002', 'Barack Obama Sahbuku', 'L', 'Sorong', '2008-10-26', 'Danau Swiki', 'Anselma Asem', 2, 'SIS-2025104'),
('2025105', NULL, '9271010805070002', 'Defretes Devis Way', 'L', 'Sorong', '2007-03-05', 'Jl. Nusa Indah Klademak Rt 1/RW 2', 'Ketsia Sawoy', 2, 'SIS-2025105'),
('2025106', '0107776641', '9271011408100001', 'Dominggus Kambuaya', 'L', 'Sorong', '2010-08-14', 'Jl. Menur', 'Dominggas Kocu', 2, 'SIS-2025106'),
('2025107', '0075264726', '9271030102070001', 'Ellon Elliaser Kamesfle', 'L', 'Sorong', '2007-04-17', 'Jl. D. Swiki', 'Rikamia Salamuk', 2, 'SIS-2025107'),
('2025108', NULL, '9110021708030001', 'Hengki T. Uduas', 'L', 'Sorong', '2006-08-17', 'Jl. Mawar', 'Anike Arifin', 2, 'SIS-2025108'),
('2025109', '0045409651', '9271033108040005', 'Jonny Blesia', 'L', 'Sorong', '2004-08-31', 'Danau Swiki', 'Yermina Boltal', 2, 'SIS-2025109'),
('2025110', '0071194014', '9271050508070003', 'Josua Jordan Kabrahanubun', 'L', 'Sorong', '2007-08-05', 'Jl. F. Kalasuat', 'Yubelina Linda Rumbino', 2, 'SIS-2025110'),
('2025111', '0106378531', '9271010605100002', 'Julian Dimara', 'L', 'Sorong', '2010-05-06', 'Jl. Kembang Sepatu', 'Rosita Dimara', 2, 'SIS-2025111'),
('2025112', '3105986587', '9271014512100002', 'Kheren Homer', 'P', 'Manokwari', '2010-12-05', 'Jl. Sriti II', 'Ruth Tuty Jitmau', 2, 'SIS-2025112'),
('2025113', '0068178420', '9271035503070000', 'Marike Refyana Assem', 'P', 'Nabire', '2007-03-15', 'Jl. Trikora Kampung Salak', 'Selma Inwasef', 2, 'SIS-2025113'),
('2025114', '0058452958', '9271056911050004', 'Noni Wanma', 'P', 'Sorong', '2005-11-29', 'Jl. TG. Dofior', 'Oce Mansumber', 2, 'SIS-2025114'),
('2025115', NULL, '9271054708070002', 'Pujalina Rosina Kalasuat', 'P', 'Sorong', '2007-08-07', 'Jl. Anni Weho', 'Anna Sani', 2, 'SIS-2025115'),
('2025116', '0087825822', '9210211403090001', 'Reinaldo R. Kareth', 'L', 'Fak-Fak', '2009-03-14', 'Ayamaru-Sorong', 'Feronika Duwith', 2, 'SIS-2025116'),
('2025117', '0062258254', '9271012107060005', 'Riof Oscar Naa', 'L', 'Manokwari', '2006-07-21', 'Jl. Mawar', 'Stevelin Korwa', 2, 'SIS-2025117'),
('2025118', '0086962276', '9271011312080001', 'Sabatino Rikardo Konjol', 'L', 'Sorong', '2008-12-13', 'Jl. Kemuning No. 49', 'Lusiana Bleskadit', 2, 'SIS-2025118'),
('2025119', '0099865396', '9271016302090001', 'Sarlota Febrianty Basembun', 'P', 'Sorong', '2009-02-23', 'Jl. Jend. Sudirman', 'Nangki Mamari', 2, 'SIS-2025119'),
('2025120', '0072847935', '9201060306070001', 'William Wilson Wihelmus Fairio', 'L', 'Tanah Merah', '2007-06-03', 'Jl. Danau Siwiki', 'Agustina Yarollo', 2, 'SIS-2025120'),
('2024301', '0095166430', NULL, 'Daud Geraldo Nauw', 'L', 'Sorong', '2009-04-01', 'Jl. Selat Rumberpon (Blkg Mandiri)', 'Rosita Kareth', 4, 'SIS-2024301'),
('2024302', '0079818189', '9271030706070007', 'Emerikus Wafom', 'L', 'Sorong', '2007-06-07', 'Jl. D. Swiki', 'Susance Tenau', 4, 'SIS-2024302'),
('2024303', '0083530917', '9271011912080002', 'Denias Braen Moby', 'L', 'Sorong', '2008-12-19', 'Jl. Putri Malu', 'Maryam Ambo', 4, 'SIS-2024303'),
('2024304', '0082286163', '9271010702070006', 'Gilbertd A Aronggear', 'L', 'Sorong', '2008-02-07', 'Jl. Nuri', 'Abtri Yethfi Paulin Solossa', 4, 'SIS-2024304'),
('2024305', '0081810805', '9271071412080001', 'Jack Moses Msikibis Burdam', 'L', 'Sorong', '2008-12-14', 'Jl. Rejauw KLD 1', 'Anthonia Saleo', 4, 'SIS-2024305'),
('2024306', '0089467638', '9204225311080001', 'Hystyfora Aksamina Kemesrar', 'P', 'Mlaswat', '2008-11-13', 'Jl. Kampung Mlaswat', 'Fince Su', 4, 'SIS-2024306'),
('2024307', '0085805055', '9202133012080002', 'Julshan Dhinno Putra Suharsono Rumbekwan', 'L', 'Sorong', '2008-12-30', 'Jl. Pasir Putih', 'Ernii Amallia Samantha Ayomi', 4, 'SIS-2024307'),
('2024308', '0069182662', '9271015411080006', 'Klarita Bertha Mahuse', 'P', 'Sorong', '2008-11-14', 'Jln. Ampi', 'Doly Nauw', 4, 'SIS-2024308'),
('2024309', '0089429743', NULL, 'Mivelstei Tauran', 'L', 'Sorong', '2008-04-26', 'Jln. Bukit Baru', 'Ledy Sondak', 4, 'SIS-2024309'),
('2024310', '0086264690', '9271031912080001', 'Muzakir Bakri Badarudin', 'L', 'Sorong', '2008-12-19', 'Danau Ranau', 'Siti Hawa Lanani', 4, 'SIS-2024310'),
('2024311', '3063838875', '9202120407080009', 'Rendy Orton Msiren', 'L', 'Sorong', '2008-07-04', 'Jl. Pertanian', 'Elsina Loisa Msiren', 4, 'SIS-2024311');

-- ---------------------------------------------------------------------
-- USERS (akun login: Kepala Sekolah = akses penuh, Guru = wali kelas)
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pegawai_id INT DEFAULT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('kepala_sekolah','guru') NOT NULL,
  status_aktif TINYINT(1) NOT NULL DEFAULT 1,
  last_login DATETIME DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (pegawai_id) REFERENCES pegawai(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- password default untuk SEMUA akun di bawah: "sekolah123"  (WAJIB diganti setelah login pertama!)
-- hash ini adalah hasil password_hash('sekolah123', PASSWORD_DEFAULT)
INSERT INTO users (pegawai_id, username, password, role) VALUES
(1, 'kepsek', '$2b$10$okzSu2Q.6PL6VgyQQJeE8OPRtU79TyrtuaC.nqS6Q9iUfVVuTzevK', 'kepala_sekolah'),
(2, 'wali.x',  '$2b$10$okzSu2Q.6PL6VgyQQJeE8OPRtU79TyrtuaC.nqS6Q9iUfVVuTzevK', 'guru'),
(3, 'wali.xia', '$2b$10$okzSu2Q.6PL6VgyQQJeE8OPRtU79TyrtuaC.nqS6Q9iUfVVuTzevK', 'guru'),
(5, 'wali.xii', '$2b$10$okzSu2Q.6PL6VgyQQJeE8OPRtU79TyrtuaC.nqS6Q9iUfVVuTzevK', 'guru');

-- ---------------------------------------------------------------------
-- ABSENSI SISWA
-- ---------------------------------------------------------------------
CREATE TABLE absensi_siswa (
  id INT AUTO_INCREMENT PRIMARY KEY,
  siswa_id INT NOT NULL,
  tahun_ajaran_id INT DEFAULT NULL,
  tanggal DATE NOT NULL,
  jam_masuk TIME DEFAULT NULL,
  jam_pulang TIME DEFAULT NULL,
  jenis_pulang ENUM('Normal','Izin Pulang Awal','Dipulangkan Sekolah') DEFAULT NULL,
  status ENUM('Hadir','Terlambat','Sakit','Izin','Alpa') NOT NULL DEFAULT 'Hadir',
  metode ENUM('QR','Manual') NOT NULL DEFAULT 'QR',
  keterangan VARCHAR(255) DEFAULT NULL,
  input_by INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unik_absen_siswa_harian (siswa_id, tanggal),
  FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ABSENSI PEGAWAI (Guru, Tata Usaha, Penjaga Sekolah) -- dipegang Kepala Sekolah
-- ---------------------------------------------------------------------
CREATE TABLE absensi_pegawai (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pegawai_id INT NOT NULL,
  tanggal DATE NOT NULL,
  jam_masuk TIME DEFAULT NULL,
  jam_pulang TIME DEFAULT NULL,
  jenis_pulang ENUM('Normal','Izin Pulang Awal','Dipulangkan Sekolah') DEFAULT NULL,
  status ENUM('Hadir','Terlambat','Sakit','Izin','Alpa') NOT NULL DEFAULT 'Hadir',
  metode ENUM('QR','Manual') NOT NULL DEFAULT 'QR',
  keterangan VARCHAR(255) DEFAULT NULL,
  input_by INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unik_absen_pegawai_harian (pegawai_id, tanggal),
  FOREIGN KEY (pegawai_id) REFERENCES pegawai(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- PENGUMUMAN
-- ---------------------------------------------------------------------
CREATE TABLE pengumuman (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(150) NOT NULL,
  isi TEXT NOT NULL,
  dibuat_oleh INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO pengumuman (judul, isi, dibuat_oleh) VALUES
('Selamat Datang di Sistem Manajemen & Absensi SMAS YPK 1 Sorong', 'Sistem absensi QR Code resmi mulai digunakan. Jam masuk 07:30 WIT dan jam pulang 13:45 WIT.', 1);

-- ---------------------------------------------------------------------
-- RIWAYAT KENAIKAN KELAS / KELULUSAN
-- ---------------------------------------------------------------------
CREATE TABLE riwayat_kenaikan_kelas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  siswa_id INT NOT NULL,
  dari_kelas_id INT DEFAULT NULL,
  ke_kelas_id INT DEFAULT NULL,
  tahun_ajaran_asal_id INT DEFAULT NULL,
  tahun_ajaran_tujuan_id INT DEFAULT NULL,
  status ENUM('Naik Kelas','Tinggal Kelas','Lulus') NOT NULL,
  diproses_oleh INT DEFAULT NULL,
  tanggal_proses TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- PERMINTAAN LAPORAN BULANAN (Kepala Sekolah -> Wali Kelas)
-- ---------------------------------------------------------------------
CREATE TABLE laporan_bulanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kelas_id INT NOT NULL,
  bulan CHAR(7) NOT NULL,                     -- format: YYYY-MM
  status ENUM('Diminta','Sudah Dikirim') NOT NULL DEFAULT 'Diminta',
  diminta_oleh INT DEFAULT NULL,
  tanggal_diminta TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  dikirim_oleh INT DEFAULT NULL,
  tanggal_dikirim DATETIME DEFAULT NULL,
  catatan_wali_kelas TEXT DEFAULT NULL,
  catatan_kepsek VARCHAR(255) DEFAULT NULL,
  UNIQUE KEY unik_permintaan (kelas_id, bulan),
  FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- SELESAI. Total: 3 kelas (X, XI A, XII), 40 siswa, 14 pegawai, 4 akun login.
-- =====================================================================
