-- =====================================================================
-- MIGRASI: PERBARUI DATA SISWA SESUAI DAFTAR PESERTA DIDIK RESMI
-- SMAS YPK 1 Sorong — sumber: PDF "Daftar Peserta Didik" per 23 Agustus 2026
-- =====================================================================
-- CARA PAKAI:
-- 1. Buka phpMyAdmin -> pilih database db_sms_ypk1_sorong -> tab SQL
-- 2. Salin SELURUH ISI file ini -> tempel -> klik Go
-- 3. Skrip ini AMAN dijalankan walau tabel/kolom yang dibutuhkan belum ada
--    di instalasi lama Anda (otomatis dibuatkan). Namun sebaiknya HANYA
--    DIJALANKAN SATU KALI: jika dijalankan ulang setelah Anda mengedit
--    manual data siswa (misalnya memperbaiki jenis kelamin atau NIS),
--    perbaikan manual tersebut akan TERTIMPA kembali ke data asli PDF.
--
-- CATATAN PENTING SEBELUM MENJALANKAN:
-- - Skrip ini MENGHAPUS seluruh data siswa & riwayat absensi siswa yang
--   LAMA (data contoh/placeholder), lalu menggantinya dengan 40 siswa
--   ASLI dari dokumen PDF yang Anda berikan.
-- - Struktur kelas disesuaikan dari 4 kelas (X, XI Sosial, XI Kesehatan,
--   XII IPA) MENJADI 3 KELAS SESUAI DATA RIIL: X, XI A, XII — karena
--   dokumen PDF hanya mencatat siswa pada 3 kelas tersebut (belum ada
--   pembagian jurusan Sosial/Kesehatan). Jika ke depan sekolah membagi
--   XI menjadi beberapa jurusan lagi, tinggal tambah kelas baru lewat
--   menu Manajemen Sekolah -> Data Kelas.
-- - DITEMUKAN 2 DATA GANDA di dokumen PDF asli, sudah saya perbaiki:
--     1) "EMERIKUS WAFOM" tercatat 2x di daftar Kelas XII (baris 2 & 4)
--        -> hanya disimpan 1x.
--     2) "Marvel David Sanadi" (NIK 9271061803090003) tercatat di
--        daftar Kelas X DAN Kelas XII dengan NIK yang sama persis
--        -> saya masukkan ke Kelas X saja (sesuai daftar khusus Kelas X).
--        Mohon dicek kembali apakah ini benar 1 orang yang salah catat,
--        atau sebenarnya ada 2 siswa berbeda yang datanya perlu diperbaiki.
-- - Jenis kelamin (L/P) TIDAK ADA di dokumen PDF, sehingga diisi
--   berdasarkan perkiraan dari nama depan. MOHON DICEK & DIPERBAIKI
--   satu per satu lewat menu Manajemen Sekolah -> Data Siswa jika ada
--   yang keliru.
-- - Nomor Induk Siswa (NIS) sekolah TIDAK ADA di dokumen PDF (yang ada
--   hanya NIK/Kependudukan & NISN), sehingga NIS dibuat otomatis oleh
--   sistem (format 2026xxx/2025xxx/2024xxx). Silakan ganti dengan NIS
--   resmi sekolah Anda lewat menu edit siswa jika sudah ada.
-- =====================================================================

-- 0) Siapkan struktur tabel/kolom yang mungkin belum ada di instalasi lama Anda
--    (aman dijalankan walau tabel/kolom ini sudah ada sebelumnya)
ALTER TABLE siswa ADD COLUMN IF NOT EXISTS nik VARCHAR(20) DEFAULT NULL AFTER nisn;

INSERT INTO pengaturan (nama_pengaturan, nilai_pengaturan) VALUES
('logo_sekolah', ''), ('background_sekolah', ''), ('warna_tema', 'navy')
ON DUPLICATE KEY UPDATE nama_pengaturan = nama_pengaturan;

CREATE TABLE IF NOT EXISTS laporan_bulanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kelas_id INT NOT NULL,
  bulan CHAR(7) NOT NULL,
  status ENUM('Diminta','Sudah Dikirim') NOT NULL DEFAULT 'Diminta',
  diminta_oleh INT DEFAULT NULL,
  tanggal_diminta TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  dikirim_oleh INT DEFAULT NULL,
  tanggal_dikirim DATETIME DEFAULT NULL,
  catatan_wali_kelas TEXT DEFAULT NULL,
  catatan_kepsek VARCHAR(255) DEFAULT NULL,
  UNIQUE KEY unik_permintaan (kelas_id, bulan),
  FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 1) Tambah kolom NIK (Nomor Induk Kependudukan) - sudah dilakukan di langkah 0 di atas
-- (langkah ini sengaja dikosongkan, lihat langkah 0)

-- 2) Sesuaikan struktur kelas dengan data riil: X, XI A, XII
UPDATE kelas SET nama_kelas='XI A', jurusan=NULL WHERE id=2;
UPDATE kelas SET nama_kelas='XII', jurusan=NULL WHERE id=4;
-- lepas kelas "XI Kesehatan" (id=3) karena belum ada siswanya di data riil saat ini
UPDATE kelas SET kelas_lanjutan_id=NULL WHERE kelas_lanjutan_id=3;
DELETE FROM laporan_bulanan WHERE kelas_id=3;
DELETE FROM kelas WHERE id=3;
-- pastikan alur kenaikan kelas tetap benar: X -> XI A -> XII -> (lulus)
UPDATE kelas SET kelas_lanjutan_id=2 WHERE id=1;
UPDATE kelas SET kelas_lanjutan_id=4 WHERE id=2;
UPDATE kelas SET kelas_lanjutan_id=NULL WHERE id=4;

-- 3) Rapikan akun login supaya sesuai kelas yang tersisa
UPDATE users SET status_aktif=0 WHERE username='wali.xikesehatan'; -- kelasnya sudah tidak ada
UPDATE users SET username='wali.xia' WHERE username='wali.xisosial';
UPDATE users SET username='wali.xii' WHERE username='wali.xiiipa';

-- 4) Hapus seluruh data siswa LAMA (contoh/placeholder) beserta riwayat absensinya
DELETE FROM siswa;
ALTER TABLE siswa AUTO_INCREMENT = 1;

-- 5) Masukkan 40 siswa ASLI sesuai dokumen PDF
INSERT INTO siswa (nis, nisn, nik, nama, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, nama_ortu, kelas_id, qr_token) VALUES
('2026001', '0073151958', '9271034904070001', 'Aplenia Duwith', 'P', 'Sorong', '2007-04-09', 'Jalan Danau Swiki', 'Elisabeth Blesia', 1, 'SIS-2026001'),
('2026002', '0081934729', '9271030511080004', 'Ehud Albertho Safes Trogea', 'L', 'Sorong', '2008-11-05', 'Danau Swiki', 'Penina Jarfi', 1, 'SIS-2026002'),
('2026003', '0112461891', '9271010403110003', 'Israel Almendo Marvel Rastafara Tuhehay', 'L', 'Manado', '2011-03-04', 'Jl. Tulip No. 08', 'Gyta Praditia Ariani', 1, 'SIS-2026003'),
('2026004', '0092626868', '9671010903090001', 'Markus Marthen Albertho Ogabuy', 'L', 'Sorong', '2009-03-09', 'Klademak III B', 'Ester Elisabeth Ogabuy', 1, 'SIS-2026004'),
('2026005', '0096526341', '9271061803090003', 'Marvel David Sanadi', 'L', 'Sorong', '2009-03-18', 'Jl. Rejauw', 'Agustina Emauri', 1, 'SIS-2026005'),
('2026006', '0105177017', '9206146807100001', 'Virdalina Talenta Siwana', 'P', 'Sorong', '2010-07-28', 'Tanah Merah', 'Anace Ginuny', 1, 'SIS-2026006'),
('2026007', '0108714955', '9271011407100001', 'Yoppi Metusala Baransano', 'L', 'Kasim', '2010-07-14', 'Jl. Teratai, Klademak', 'Afsalomina Rumaikeo', 1, 'SIS-2026007'),
('2026008', NULL, NULL, 'Heldita Ellesia Sesa', 'P', 'Sorong', '2010-01-25', 'Puncak Cendrawasih', 'Yustinus Sesa', 1, 'SIS-2026008'),
('2026009', NULL, NULL, 'Brian Momot', 'L', NULL, NULL, NULL, NULL, 1, 'SIS-2026009'),
('2025101', '0092720058', '9271011509100004', 'Polli Henri Tao', 'L', 'Sorong', '2009-09-15', 'Jl. Menur', 'Enggle Reni Rirei', 2, 'SIS-2025101'),
('2025102', '0056821525', '9271061108050003', 'Agustus Alexander Tonjau', 'L', 'Jayapura', '2006-12-26', 'Jl. Feri Lurus Pantai', 'Karolina L. Tonjau', 2, 'SIS-2025102'),
('2025103', '0107699546', '9271032409100002', 'Amo Henry Andreuw Mayor', 'L', 'Sorong', '2010-09-24', 'R.A Kartini', 'Hetreda K. Herlince', 2, 'SIS-2025103'),
('2025104', '0088020050', '9271030804100002', 'Barack Obama Sahbuku', 'L', 'Sorong', '2008-10-26', 'Danau Swiki', 'Anselma Asem', 2, 'SIS-2025104'),
('2025105', NULL, '9271010805070002', 'Defretes Devis Way', 'L', 'Sorong', '2007-03-05', 'Jl. Nusa Indah Klademak Rt 1/RW 2', 'Ketsia Sawoy', 2, 'SIS-2025105'),
('2025106', '0107776641', '9271011408100001', 'Dominggus Kambuaya', 'L', 'Sorong', '2010-08-14', 'Jl. Menur', 'Dominggas Kocu', 2, 'SIS-2025106'),
('2025107', '0075264726', '9271030102070001', 'Ellon Elliaser Kamesfle', 'L', 'Sorong', '2007-04-17', 'Jl. D. Swiki', 'Rikamia Salamuk', 2, 'SIS-2025107'),
('2025108', NULL, '9110021708030001', 'Hengki T. Uduas', 'L', 'Sorong', '2006-08-17', 'Jl. Mawar', 'Anike Arifin', 2, 'SIS-2025108'),
('2025109', '0045409651', '9271033108040005', 'Jonny Blesia', 'L', 'Sorong', '2004-08-31', 'Danau Swiki', 'Yermina Boltal', 2, 'SIS-2025109'),
('2025110', '0071194014', '9271050508070003', 'Josua Jordan Kabrahanubun', 'L', 'Sorong', '2007-08-05', 'Jl. F. Kalasuat', 'Yubelina Linda Rumbino', 2, 'SIS-2025110'),
('2025111', '0106378531', '9271010605100002', 'Julian Dimara', 'L', 'Sorong', '2010-05-06', 'Jl. Kembang Sepatu', 'Rosita Dimara', 2, 'SIS-2025111'),
('2025112', '3105986587', '9271014512100002', 'Kheren Homer', 'P', 'Manokwari', '2010-12-05', 'Jl. Sriti II', 'Ruth Tuty Jitmau', 2, 'SIS-2025112'),
('2025113', '0068178420', '9271035503070000', 'Marike Refyana Assem', 'P', 'Nabire', '2007-03-15', 'Jl. Trikora Kampung Salak', 'Selma Inwasef', 2, 'SIS-2025113'),
('2025114', '0058452958', '9271056911050004', 'Noni Wanma', 'P', 'Sorong', '2005-11-29', 'Jl. TG. Dofior', 'Oce Mansumber', 2, 'SIS-2025114'),
('2025115', NULL, '9271054708070002', 'Pujalina Rosina Kalasuat', 'P', 'Sorong', '2007-08-07', 'Jl. Anni Weho', 'Anna Sani', 2, 'SIS-2025115'),
('2025116', '0087825822', '9210211403090001', 'Reinaldo R. Kareth', 'L', 'Fak-Fak', '2009-03-14', 'Ayamaru-Sorong', 'Feronika Duwith', 2, 'SIS-2025116'),
('2025117', '0062258254', '9271012107060005', 'Riof Oscar Naa', 'L', 'Manokwari', '2006-07-21', 'Jl. Mawar', 'Stevelin Korwa', 2, 'SIS-2025117'),
('2025118', '0086962276', '9271011312080001', 'Sabatino Rikardo Konjol', 'L', 'Sorong', '2008-12-13', 'Jl. Kemuning No. 49', 'Lusiana Bleskadit', 2, 'SIS-2025118'),
('2025119', '0099865396', '9271016302090001', 'Sarlota Febrianty Basembun', 'P', 'Sorong', '2009-02-23', 'Jl. Jend. Sudirman', 'Nangki Mamari', 2, 'SIS-2025119'),
('2025120', '0072847935', '9201060306070001', 'William Wilson Wihelmus Fairio', 'L', 'Tanah Merah', '2007-06-03', 'Jl. Danau Siwiki', 'Agustina Yarollo', 2, 'SIS-2025120'),
('2024301', '0095166430', NULL, 'Daud Geraldo Nauw', 'L', 'Sorong', '2009-04-01', 'Jl. Selat Rumberpon (Blkg Mandiri)', 'Rosita Kareth', 4, 'SIS-2024301'),
('2024302', '0079818189', '9271030706070007', 'Emerikus Wafom', 'L', 'Sorong', '2007-06-07', 'Jl. D. Swiki', 'Susance Tenau', 4, 'SIS-2024302'),
('2024303', '0083530917', '9271011912080002', 'Denias Braen Moby', 'L', 'Sorong', '2008-12-19', 'Jl. Putri Malu', 'Maryam Ambo', 4, 'SIS-2024303'),
('2024304', '0082286163', '9271010702070006', 'Gilbertd A Aronggear', 'L', 'Sorong', '2008-02-07', 'Jl. Nuri', 'Abtri Yethfi Paulin Solossa', 4, 'SIS-2024304'),
('2024305', '0081810805', '9271071412080001', 'Jack Moses Msikibis Burdam', 'L', 'Sorong', '2008-12-14', 'Jl. Rejauw KLD 1', 'Anthonia Saleo', 4, 'SIS-2024305'),
('2024306', '0089467638', '9204225311080001', 'Hystyfora Aksamina Kemesrar', 'P', 'Mlaswat', '2008-11-13', 'Jl. Kampung Mlaswat', 'Fince Su', 4, 'SIS-2024306'),
('2024307', '0085805055', '9202133012080002', 'Julshan Dhinno Putra Suharsono Rumbekwan', 'L', 'Sorong', '2008-12-30', 'Jl. Pasir Putih', 'Ernii Amallia Samantha Ayomi', 4, 'SIS-2024307'),
('2024308', '0069182662', '9271015411080006', 'Klarita Bertha Mahuse', 'P', 'Sorong', '2008-11-14', 'Jln. Ampi', 'Doly Nauw', 4, 'SIS-2024308'),
('2024309', '0089429743', NULL, 'Mivelstei Tauran', 'L', 'Sorong', '2008-04-26', 'Jln. Bukit Baru', 'Ledy Sondak', 4, 'SIS-2024309'),
('2024310', '0086264690', '9271031912080001', 'Muzakir Bakri Badarudin', 'L', 'Sorong', '2008-12-19', 'Danau Ranau', 'Siti Hawa Lanani', 4, 'SIS-2024310'),
('2024311', '3063838875', '9202120407080009', 'Rendy Orton Msiren', 'L', 'Sorong', '2008-07-04', 'Jl. Pertanian', 'Elsina Loisa Msiren', 4, 'SIS-2024311');

-- =====================================================================
-- SELESAI. Total 40 siswa dimasukkan: Kelas X (9), Kelas XI A (20), Kelas XII (11).
-- Login wali kelas yang baru: wali.x (Kelas X), wali.xia (Kelas XI A), wali.xii (Kelas XII).
-- Password tetap: sekolah123 (segera ganti lewat menu Akun Pengguna).
-- =====================================================================
