<?php
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/includes/functions.php';

if (isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . 'home.php');
    exit;
}

$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$logo_url = url_logo_sekolah($conn);
$bg_url = url_background_sekolah($conn);
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex"><title>Masuk - <?php echo bersihkan($nama_sekolah); ?></title>
<link rel="stylesheet" href="<?php echo aset('assets/css/style.css'); ?>">
<script>window.SMS = { base: <?php echo json_encode(BASE_URL); ?>, bell: false };</script>
<script src="<?php echo aset('assets/js/notify.js'); ?>" defer></script>
</head>
<body>
<div class="login-wrap <?php echo $bg_url ? 'has-photo' : ''; ?>" <?php echo $bg_url ? 'style="background-image:linear-gradient(135deg,rgba(6,28,46,.86),rgba(6,28,46,.92)),url(\'' . $bg_url . '\');background-size:cover;background-position:center;"' : ''; ?>>
  <?php if (!$bg_url): ?><div class="papua-watermark" style="opacity:.06;"></div><?php endif; ?>
  <div class="login-card">
    <?php if ($logo_url): ?>
      <img src="<?php echo $logo_url; ?>" alt="Logo Sekolah" style="width:76px;height:76px;object-fit:contain;display:block;margin:0 auto 14px;border-radius:50%;filter:drop-shadow(0 4px 10px rgba(11,60,93,.25));">
    <?php else: ?>
      <div class="school-badge">YPK</div>
    <?php endif; ?>
    <h1><?php echo bersihkan($nama_sekolah); ?></h1>
    <p class="sub">Sistem Manajemen Sekolah &amp; Absensi QR Code</p>

    <?php if ($error === '1'): ?>
      <div class="alert alert-error" data-nt-inline>Username atau password salah. Silakan coba lagi.</div>
    <?php elseif ($error === '2'): ?>
      <div class="alert alert-error" data-nt-inline>Akun Anda tidak aktif. Hubungi Kepala Sekolah.</div>
    <?php endif; ?>

    <form method="POST" action="<?php echo BASE_URL; ?>proses_login.php">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required autofocus placeholder="Masukkan username" autocomplete="username">
      </div>
      <div class="form-group">
        <label>Password</label>
        <div class="pw-field"><input type="password" name="password" class="form-control" required placeholder="Masukkan password" autocomplete="current-password"><button type="button" class="pw-toggle" aria-label="Tampilkan password" aria-pressed="false" title="Tampilkan password"><svg class="ic-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M1.5 12s3.8-7 10.5-7 10.5 7 10.5 7-3.8 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg><svg class="ic-off" viewBox="0 0 24 24" aria-hidden="true"><path d="M17.9 17.9A10.9 10.9 0 0 1 12 19c-6.7 0-10.5-7-10.5-7a19 19 0 0 1 4.6-5.4M9.9 5.2A10.4 10.4 0 0 1 12 5c6.7 0 10.5 7 10.5 7a19 19 0 0 1-2.2 3.1M14.1 14.1a3 3 0 1 1-4.2-4.2M2 2l20 20"/></svg></button></div>
      </div>
      <button type="submit" class="btn btn-primary">Masuk ke Sistem</button>
    </form>
    <p class="sub" style="margin-top:18px;">Yayasan Pendidikan Kristen (YPK) di Tanah Papua</p>
  </div>
</div>
<script src="<?php echo aset('assets/js/password-toggle.js'); ?>"></script>
<script src="<?php echo aset('assets/js/lightbox.js'); ?>"></script>
</body>
</html>
