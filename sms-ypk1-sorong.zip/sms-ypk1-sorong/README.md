# Sistem Manajemen Sekolah & Absensi QR Code
### SMAS YPK 1 Sorong — NPSN 60403645

Sistem berbasis **PHP + MySQL**, responsif di PC, tablet, maupun HP, dengan absensi QR Code yang dilengkapi bunyi dan suara otomatis (Text-to-Speech Bahasa Indonesia).

---

## 1. Isi Paket

```
sms-ypk1-sorong/
├── database/sms_ypk1_sorong.sql   <- Import file ini ke MySQL/MariaDB (instalasi baru)
├── database/update_data_siswa_real.sql <- Migrasi data siswa asli (jika sudah pernah install versi lama)
├── config/koneksi.php             <- Atur host/user/password DB & nama folder di sini
├── manajemen/                     <- Modul Manajemen Sekolah (khusus Kepala Sekolah)
├── absensi/                       <- Modul Absensi QR Code
├── keuangan/                      <- Modul Keuangan Sekolah & Komite (buku kas, SPP, gaji guru honorer)
├── erapor/                        <- Modul E-Rapor (nilai, sikap, cetak rapor)
├── assets/                        <- CSS, JS (html5-qrcode & qrcode.js sudah disertakan, TIDAK butuh internet)
├── includes/                      <- Komponen tampilan bersama (header, sidebar, footer)
├── index.php                      <- Halaman login
└── pilihan.php                    <- Menu utama Kepala Sekolah (4 pilihan: Manajemen / Absensi / Keuangan / E-Rapor)
```

## 2. Cara Instalasi (XAMPP / Laragon / VPS)

### Langkah 1 — Salin folder project
Salin seluruh folder `sms-ypk1-sorong` ke dalam folder `htdocs` (XAMPP) atau `www` (Laragon).

### Langkah 2 — Buat & Import Database
1. Buka **phpMyAdmin** → klik **New** → beri nama database `db_sms_ypk1_sorong` → **Create**.
2. Klik tab **Import** → pilih file `database/sms_ypk1_sorong.sql` → klik **Go**.
3. Pastikan muncul tabel-tabel inti berikut (tabel modul Keuangan & E-Rapor dibuat otomatis saat aplikasi pertama dibuka): `pengaturan`, `tahun_ajaran`, `kelas`, `pegawai`, `siswa`, `users`, `absensi_siswa`, `absensi_pegawai`, `pengumuman`, `riwayat_kenaikan_kelas`.

Atau lewat terminal:
```bash
mysql -u root -p -e "CREATE DATABASE db_sms_ypk1_sorong"
mysql -u root -p db_sms_ypk1_sorong < database/sms_ypk1_sorong.sql
```

### Langkah 3 — Atur Koneksi
Buka `config/koneksi.php`, sesuaikan jika perlu:
```php
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'db_sms_ypk1_sorong';

// PENTING: sesuaikan dengan nama folder project Anda di htdocs
define('BASE_URL', '/sms-ypk1-sorong/');
```
- Jika folder Anda diberi nama lain, ganti `sms-ypk1-sorong` sesuai nama foldernya.
- Jika project diakses dari domain utama/root (bukan subfolder), ubah menjadi `define('BASE_URL', '/');`

### Langkah 4 — Jalankan
Buka browser: `http://localhost/sms-ypk1-sorong/`

> **Untuk akses dari HP/tablet di jaringan WiFi sekolah yang sama:** gunakan alamat IP komputer server, contoh `http://192.168.1.5/sms-ypk1-sorong/`. Kamera untuk scan QR memerlukan koneksi **HTTPS** ATAU akses lewat **localhost** — jika ingin diakses dari HP lain di jaringan lokal via HTTP biasa, sebagian browser (terutama Chrome di Android versi baru) akan memblokir akses kamera. Solusi: gunakan HTTPS (misalnya lewat reverse proxy / sertifikat self-signed / layanan seperti ngrok), atau jalankan scanner langsung dari komputer/HP yang berfungsi sebagai server (localhost).

---

## 3. Akun Login

| Username | Password | Role | Keterangan |
|---|---|---|---|
| `kepsek` | `sekolah123` | Kepala Sekolah | Akses penuh — Manajemen & Absensi |
| `wali.x` | `sekolah123` | Guru/Wali Kelas | Wali Kelas X (9 siswa) |
| `wali.xia` | `sekolah123` | Guru/Wali Kelas | Wali Kelas XI A (20 siswa) |
| `wali.xii` | `sekolah123` | Guru/Wali Kelas | Wali Kelas XII (11 siswa) |

**⚠️ WAJIB segera ganti semua password setelah instalasi pertama** melalui menu *Manajemen Sekolah → Akun Pengguna* (khusus Kepala Sekolah, tombol "Edit Username / Password").

**Data siswa sudah berisi 40 siswa ASLI** sesuai Daftar Peserta Didik resmi yang Anda berikan (bukan lagi data contoh/placeholder). Data guru masih berupa placeholder ("Guru 1" s.d. "Guru 11") — silakan edit nama asli melalui menu **Manajemen Sekolah → Data Guru & Staf**.

**Catatan tentang data siswa:**
- Jenis kelamin (L/P) diperkirakan otomatis dari nama depan karena dokumen sumber tidak mencantumkan kolom ini — mohon dicek satu per satu lewat menu Data Siswa dan diperbaiki jika ada yang keliru.
- Nomor Induk Siswa (NIS) dibuat otomatis oleh sistem (format 2026xxx/2025xxx/2024xxx) karena dokumen sumber tidak mencantumkan NIS resmi sekolah — silakan diganti lewat menu edit siswa jika sekolah sudah memiliki NIS resmi.
- Ditemukan 2 baris data ganda pada dokumen PDF asli ("Emerikus Wafom" tercatat 2x, dan "Marvel David Sanadi" tercatat di 2 kelas berbeda dengan NIK yang sama) — sudah dirapikan menjadi 1 data masing-masing. Mohon dicek kembali kebenarannya.
- Struktur kelas disesuaikan menjadi **3 kelas sesuai data riil**: X, XI A, XII (bukan 4 kelas seperti rencana awal), karena dokumen belum mencatat pembagian jurusan Sosial/Kesehatan pada kelas XI. Jika pembagian jurusan sudah berlaku, tambahkan kelas baru lewat menu Data Kelas kapan saja.

**Jika Anda sudah pernah instalasi versi sebelumnya** (dengan data contoh 43 siswa/4 kelas) dan ingin mengupdate ke data asli ini tanpa install ulang dari nol, gunakan file `database/update_data_siswa_real.sql` — buka phpMyAdmin, pilih database Anda, tab SQL, tempel isi file tersebut, lalu Go. **Cukup dijalankan satu kali.**

---

## 4. Struktur Hak Akses (Role)

- **Kepala Sekolah** (akses penuh — bisa lihat & ubah seluruh data sistem):
  - Setelah login akan diarahkan ke halaman **pilihan 2 menu utama**: *Manajemen Sekolah* atau *Absensi Sekolah*.
  - Mengelola: data siswa, guru & staf, kelas, tahun ajaran, kenaikan kelas, akun pengguna, pengumuman, pengaturan sekolah.
  - Memegang absensi QR untuk **Guru, Tata Usaha, dan Penjaga Sekolah**.
  - Bisa memantau/mengubah absensi semua kelas siswa.
- **Guru (Wali Kelas)**:
  - Hanya bisa memindai/mengelola absensi **siswa kelas yang diwalikannya sendiri** (sistem otomatis menolak scan siswa dari kelas lain).
  - Bisa input manual (Sakit/Izin/Alpa), melihat rekap kelasnya, dan mencetak kartu QR kelasnya.
  - Tidak bisa mengakses menu Manajemen Sekolah.

---

## 5. Cara Kerja Absensi QR Code

1. Kepala Sekolah mencetak **Kartu QR** untuk setiap siswa & pegawai lewat menu *Cetak Kartu QR* (bisa per orang atau sekaligus per kelas), lalu dilaminasi/dibagikan.
2. Saat scan pertama di hari itu → otomatis tercatat sebagai **Absen Masuk**.
   - Jika discan sebelum atau tepat pada jam masuk + toleransi (default 07:30 + 15 menit) → status **Hadir**.
   - Jika lewat dari itu → status otomatis **Terlambat**.
3. Saat kartu yang sama discan lagi di hari yang sama → otomatis tercatat sebagai **Absen Pulang**.
4. Setiap scan berhasil akan berbunyi **beep** dan **suara otomatis** (mis. "Selamat pagi, Budi. Absen masuk berhasil dicatat, status Hadir.") menggunakan Web Speech API bawaan browser.
5. Jam masuk (07:30 WIT), jam pulang (13:45 WIT), dan toleransi keterlambatan bisa diubah kapan saja di *Manajemen Sekolah → Pengaturan Sekolah*.
6. Jika kamera bermasalah, tersedia kolom **input token manual** di bawah kamera pada setiap halaman scan.

---

## 6. Pergantian Semester & Kenaikan Kelas Otomatis

Menu **Manajemen Sekolah → Kenaikan Kelas** menyediakan 2 aksi:

1. **Ganti Semester (Ganjil → Genap)** — dipakai di pertengahan tahun ajaran, siswa tetap di kelas yang sama.
2. **Tahun Ajaran Baru + Kenaikan Kelas Otomatis** — dipakai di akhir tahun ajaran. Sistem menampilkan tabel **pratinjau** seluruh siswa aktif beserta kelas tujuan (berdasarkan pengaturan "Kelas Lanjutan" di menu Data Kelas), yang **bisa disesuaikan manual per siswa** (misalnya menentukan siswa kelas X masuk ke XI Sosial atau XI Kesehatan) sebelum tombol **Konfirmasi & Proses** ditekan. Siswa kelas akhir (tanpa kelas lanjutan) otomatis berstatus **Lulus**. Semua riwayat kenaikan kelas tersimpan dan bisa dilihat kembali.

Atur alur kenaikan kelas (kelas mana naik ke kelas mana) di menu **Manajemen Sekolah → Data Kelas**, kolom "Kelas Lanjutan".

---

## 7. Tampilan Responsif

Sistem ini sudah dioptimalkan untuk **PC, tablet, dan HP**:
- Sidebar otomatis berubah menjadi menu geser (hamburger ☰) di layar kecil.
- Tabel data bisa digeser ke samping (scroll horizontal) di layar sempit.
- Halaman scan QR & kartu digital menyesuaikan ukuran layar otomatis.
- Kamera scanner akan otomatis memilih kamera belakang bila diakses dari HP.

---

## 8. Tampilan Profesional & Estetik (Logo, Latar Belakang, Grafik)

- **Logo & Latar Belakang Sekolah**: Kepala Sekolah bisa mengunggah logo resmi dan foto latar belakang sekolah lewat menu *Manajemen Sekolah → Pengaturan Sekolah*. Logo akan otomatis tampil di sidebar, halaman login, kartu QR, dan lembar cetak resmi. Foto latar belakang akan tampil di halaman login dan menu utama Kepala Sekolah. Format yang didukung: JPG, PNG, WEBP, maksimal 8MB dan diperkecil otomatis (logo maks 500px, latar maks 1920px). Logo & foto latar tampil di **sidebar semua role** dan **halaman login**. (Jika upload gagal karena "file terlalu besar", tingkatkan nilai `upload_max_filesize` dan `post_max_size` di `php.ini` server Anda.)
- **Lembar Cetak Rekap Resmi (Kop Surat)**: Tombol "🖨️ Cetak Lembar Resmi" pada halaman Rekap Siswa maupun Rekap Guru & Staf akan membuka lembar cetak profesional dengan kop surat (logo + nama sekolah + NPSN + alamat), tabel rekap rapi, dan kolom tanda tangan Wali Kelas & Kepala Sekolah — siap dicetak atau disimpan sebagai PDF langsung dari browser (Ctrl+P → Save as PDF).
- **Grafik Statistik**: Dashboard Manajemen dan halaman Rekap Absensi (siswa maupun guru/staf) kini dilengkapi grafik batang & donat interaktif untuk memvisualisasikan persentase kehadiran, keterlambatan, sakit/izin/alpa per kelas maupun per pegawai.

## 9. Permintaan Laporan dari Wali Kelas

Kepala Sekolah dapat meminta laporan absensi bulanan resmi dari wali kelas tertentu lewat menu **Manajemen Sekolah → Minta Laporan Wali Kelas**:
1. Kepala Sekolah memilih kelas & bulan, lalu mengirim permintaan (bisa disertai catatan).
2. Wali kelas terkait akan melihat notifikasi (badge angka) pada menu **Laporan Diminta Kepsek** di sidebar mereka.
3. Wali kelas meninjau rekap kelasnya, menambahkan catatan bila perlu, lalu menekan "Kirim Laporan Sekarang".
4. Kepala Sekolah bisa langsung membuka & mencetak laporan resmi tersebut begitu berstatus "Sudah Dikirim".

## 10. Foto Profil & Kartu Identitas (Lanyard / Kalung)

- Foto profil bisa diunggah untuk **Kepala Sekolah, guru, staf, dan seluruh siswa** lewat menu *Data Siswa* dan *Data Guru & Staf* (kolom "Foto Profil" pada form tambah/edit). Foto otomatis diperkecil agar rapi & ringan.
- Menu **Cetak Kartu QR** menghasilkan **kartu identitas ukuran 60×96 mm** (muat 6 kartu per lembar A4) berisi: logo & nama sekolah, foto, nama lengkap, NIS (siswa) / NIP-NUPTK (guru & staf), kelas/jabatan, dan QR Code absensi, lengkap dengan tanda slot untuk tali lanyard.
- Cetak per siswa (tombol "Kartu QR"), per kelas, atau **semua guru & staf sekaligus** (tombol "Semua Guru & Staf"). Wali kelas hanya bisa mencetak kartu kelasnya sendiri.
- Tips cetak: A4, skala 100%, aktifkan *Background graphics*, lalu laminasi.

## 11. Suara Notifikasi Scan di HP & Tablet

Browser HP/tablet (Android Chrome, iPhone Safari) **memblokir suara sebelum ada sentuhan pengguna**. Karena itu setiap halaman scan memiliki tombol **"🔈 Aktifkan Suara Notifikasi"** — ketuk sekali saat membuka halaman scan (sistem juga otomatis mencoba membuka kunci suara pada sentuhan pertama).
- Setelah aktif: terdengar nada "ti-tiit" (sukses) / nada rendah (gagal), suara pengumuman Bahasa Indonesia (mis. "Selamat pagi, Budi. Absen masuk berhasil dicatat, status Hadir."), dan **getar** pada HP.
- Jika tidak terdengar: naikkan **volume media** (bukan volume dering), matikan mode senyap (iPhone: sakelar di samping), dan pastikan Chrome/Safari tidak dalam mode hening.
- Suara Bahasa Indonesia memakai mesin suara bawaan HP. Jika HP tidak punya suara "Indonesia", instal lewat Pengaturan HP → Text-to-speech → Bahasa Indonesia. Nada beep tetap berbunyi walau suara pengucapan tidak tersedia.
- **Kamera & suara di HP membutuhkan HTTPS atau localhost.** Untuk penggunaan HP dalam jaringan sekolah, gunakan HTTPS (mis. sertifikat lokal/Cloudflare Tunnel/ngrok) atau jalankan scanner di komputer server.

## 12. Aturan Absen Masuk & Pulang (Tanpa Dobel)

- **Scan pertama = Masuk.** Scan berikutnya *sebelum jam pulang* **tidak dicatat** sebagai pulang — sistem hanya memberi tahu "sudah absen masuk pukul ..., absen pulang dibuka pukul ...". Jadi tidak ada absen masuk/pulang ganda.
- **Absen pulang baru bisa dicatat mulai jam pulang** (default 13:45 WIT). Bisa dibuka lebih awal beberapa menit lewat *Pengaturan Sekolah → "Absen pulang dibuka (menit sebelum jam pulang)"*.
- Scan pertama yang dilakukan *setelah jam sekolah berakhir* tidak dicatat sebagai masuk (gunakan Input Manual oleh wali kelas/kepala sekolah).
- Siswa/pegawai yang sudah dicatat **Alpa** secara manual lalu ternyata datang: scan QR otomatis mengubahnya menjadi Hadir/Terlambat. Yang tercatat **Sakit/Izin** tidak diubah oleh scan.
- **Izin pulang awal (per orang)** — menu *Pulang Awal / Izin Pulang Awal*: wali kelas mencatat siswa kelasnya, Kepala Sekolah mencatat siswa mana pun serta guru/staf. Waktu pulang & alasan tersimpan, tampil di log dengan label "Izin pulang awal".
- **Sekolah dipulangkan mendadak** — Kepala Sekolah menu *Pulang Awal / Dipulangkan → Sekolah Dipulangkan Mendadak*: isi jam & alasan (cuaca buruk, duka cita, rapat dinas, dsb). Sejak jam itu semua orang bisa langsung scan pulang (tercatat "Dipulangkan" + alasan), scan masuk ditolak, dan pilihan **"tandai otomatis pulang"** langsung menutup absensi semua yang hadir tapi belum pulang. Berlaku hari itu saja dan bisa dibatalkan.
- Sistem **otomatis memperbarui struktur database lama** (kolom/tabel baru) saat halaman dibuka, jadi tidak perlu menjalankan SQL tambahan setiap ada pembaruan.

## 14. Modul Keuangan Sekolah & Komite (termasuk Gaji Guru Honorer)

Diakses Kepala Sekolah lewat menu **Keuangan Sekolah & Komite**, dan dikelola sehari-hari oleh akun dengan role **Bendahara**
(buat akunnya di *Manajemen Sekolah → Akun Pengguna*, pilih role "Bendahara"; sebaiknya hubungkan ke data pegawai bendahara agar namanya
tampil di tanda tangan laporan). Isi menu: Dashboard Keuangan, Buku Kas, SPP / Iuran Komite, **Gaji Guru Honorer**, Kategori Anggaran, Cetak Laporan.

### Gaji Guru Honorer
Aturan yang dipakai (bisa diubah di halaman *Gaji Guru Honorer → Aturan Honor*):
- Honor **Rp 20.000 per jam**.
- Dalam sebulan yang dibayar hanya **1 minggu mengajar = 18 jam**, sehingga honor bawaan = 18 × Rp 20.000 = **Rp 360.000 per guru per bulan**.

Alur kerja bulanan:
1. Pastikan guru yang dimaksud berstatus **Honorer**, jenis **Guru**, dan aktif di *Manajemen Sekolah → Data Guru & Staf* (Kepala Sekolah).
2. Buka *Keuangan → Gaji Guru Honorer*, pilih bulan, klik **Buat / Lengkapi Daftar Gaji**. Semua guru honorer aktif masuk dengan 18 jam × Rp 20.000.
   Guru yang baru ditambahkan di tengah bulan bisa dimasukkan dengan menekan tombol yang sama lagi (yang sudah ada tidak dobel).
3. Bila ada guru dengan jam berbeda, atau perlu tambahan/potongan, klik **Edit** (total = jam × honor per jam + tambahan − potongan).
4. Klik **Bayar** per guru, atau **Bayar Semua yang Belum**. Pembayaran otomatis tercatat sebagai **Pengeluaran** kategori *Gaji & Honor Guru/Staf* di Buku Kas
   (dan ikut masuk Dashboard serta Laporan Keuangan bulanan). Transaksi otomatis ini tidak bisa diubah dari Buku Kas — koreksi lewat tombol **Batalkan** di halaman Gaji Honorer.
5. Cetak **Slip Gaji** per guru (dengan terbilang), **Semua Slip**, atau **Rekap Gaji** (daftar penerimaan dengan kolom tanda tangan) — semuanya bisa disimpan sebagai PDF lewat Ctrl+P.

Catatan:
- Nominal honor disalin ke tiap baris gaji saat dibuat, jadi mengubah aturan honor tidak mengubah gaji bulan-bulan yang sudah dibuat.
- Gaji yang sudah dibayar terkunci; batalkan pembayaran dulu bila perlu koreksi.
- Tabel baru (`gaji_honorer`) dan kolom penanda di Buku Kas dibuat **otomatis** saat halaman dibuka, tidak perlu import SQL tambahan.

## 15. Modul E-Rapor

Diakses lewat menu **E-Rapor (Akademik)**: Mata Pelajaran, Penugasan Guru Mapel, Input Nilai (guru mapel), Sikap & Catatan Wali Kelas, dan Cetak Rapor.

## 16. Kelola Akun Pengguna & Tampilkan Password

- **Kepala Sekolah dapat mengubah username dan password semua akun** (guru/wali kelas, bendahara, maupun akun Kepala Sekolah sendiri) lewat
  *Manajemen Sekolah → Akun Pengguna → Edit Username / Password*.
  - Username: 3–50 karakter (huruf, angka, titik, garis bawah, tanda hubung), tidak boleh sama dengan akun lain.
  - Password baru: minimal 6 karakter dan harus diketik dua kali. Kosongkan bila hanya ingin mengganti username.
  - Password disimpan terenkripsi (bcrypt), sehingga password lama tidak dapat ditampilkan — hanya bisa diganti dengan yang baru.
  - Akun sendiri tidak dapat dinonaktifkan atau dihapus, agar Kepala Sekolah tidak terkunci dari sistem.
- **Ikon mata** pada kolom password (halaman login serta form akun) untuk menampilkan/menyembunyikan password yang sedang diketik.

## 13. Catatan Teknis

- Library `html5-qrcode` (pemindai kamera) dan `qrcode.js` (pembuat kode QR) sudah disertakan secara lokal di folder `assets/js/`, sehingga sistem tetap berfungsi walau tanpa koneksi internet di lingkungan sekolah.
- Zona waktu server diset otomatis ke **Asia/Jayapura (WIT)**.
- Password disimpan dengan enkripsi `bcrypt` (aman, tidak bisa dibaca langsung dari database).
- Nomor WhatsApp/SMS gateway ke orang tua **belum termasuk** dalam paket ini (butuh layanan API berbayar pihak ketiga) — bisa dikembangkan menyusul bila diperlukan.

Selamat menggunakan! 🙏🏫

## Beranda Publik (baru)
- `index.php` = beranda promosi sekolah untuk pengunjung (tanpa tombol login). Halaman login pindah ke `login.php`.
- Kepala Sekolah: menu **Kelola Beranda** (`manajemen/beranda.php`) untuk menambah, mengubah, dan menghapus semua isi (banner, statistik, profil, visi-misi, sejarah, struktur kabinet, informasi, kontak, foto).
- Tabel `beranda_konten` dibuat otomatis beserta data contoh saat beranda pertama dibuka.
