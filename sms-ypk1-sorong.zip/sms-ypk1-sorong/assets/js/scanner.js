/* =====================================================================
   SCANNER ABSENSI QR CODE - SMAS YPK 1 SORONG
   Menggunakan html5-qrcode untuk membaca kamera, Web Audio API untuk
   bunyi beep, dan Web Speech API untuk suara pengumuman otomatis.
   ===================================================================== */

let __lastToken = null;
let __lastScanTime = 0;
const __COOLDOWN_MS = 4000; // jeda supaya kartu yang sama tidak ter-scan berkali-kali

// ---------------------------------------------------------------------
// AUDIO (kompatibel HP/tablet): browser mobile (Android Chrome, iOS Safari)
// memblokir suara sampai ada sentuhan pengguna. Jadi AudioContext dibuat
// SATU KALI dan "dibuka" lewat tombol / sentuhan pertama.
// ---------------------------------------------------------------------
let __audioCtx = null;
let __suaraAktif = false;
let __voiceId = null;

function ambilAudioCtx() {
    if (!__audioCtx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (AC) __audioCtx = new AC();
    }
    if (__audioCtx && __audioCtx.state === 'suspended') { __audioCtx.resume(); }
    return __audioCtx;
}

function pilihVoiceIndonesia() {
    if (!('speechSynthesis' in window)) return;
    const voices = window.speechSynthesis.getVoices() || [];
    __voiceId = voices.find(v => /^id[-_]ID$/i.test(v.lang)) || voices.find(v => /^id/i.test(v.lang)) || null;
}
if ('speechSynthesis' in window) {
    pilihVoiceIndonesia();
    window.speechSynthesis.onvoiceschanged = pilihVoiceIndonesia; // Android memuat daftar suara secara asinkron
}

function bunyiTone(freq, mulai, durasi, volume) {
    const ctx = ambilAudioCtx();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = 'square';
    osc.frequency.setValueAtTime(freq, ctx.currentTime + mulai);
    gain.gain.setValueAtTime(0.0001, ctx.currentTime + mulai);
    gain.gain.exponentialRampToValueAtTime(volume, ctx.currentTime + mulai + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + mulai + durasi);
    osc.start(ctx.currentTime + mulai);
    osc.stop(ctx.currentTime + mulai + durasi + 0.02);
}

function mainkanBeep(sukses) {
    try {
        if (sukses) { bunyiTone(880, 0, 0.14, 0.5); bunyiTone(1320, 0.16, 0.22, 0.5); }   // "ti-tiiit" sukses
        else { bunyiTone(220, 0, 0.35, 0.55); bunyiTone(180, 0.38, 0.35, 0.55); }        // nada rendah gagal
        if (navigator.vibrate) navigator.vibrate(sukses ? 120 : [200, 100, 200]);
    } catch (e) { console.warn('Audio tidak didukung browser ini', e); }
}

function ucapkan(teks) {
    try {
        if (!('speechSynthesis' in window) || !teks) return;
        const synth = window.speechSynthesis;
        synth.cancel();
        const u = new SpeechSynthesisUtterance(teks);
        u.lang = 'id-ID';
        u.rate = 0.95; u.pitch = 1; u.volume = 1;
        if (__voiceId) u.voice = __voiceId;
        // jeda kecil setelah cancel() agar tidak "tertelan" di Chrome Android
        setTimeout(() => synth.speak(u), 120);
    } catch (e) { console.warn('Speech synthesis gagal', e); }
}

// dipanggil dari tombol "Aktifkan Suara" (WAJIB lewat sentuhan pengguna agar diizinkan browser mobile)
function aktifkanSuara(tesBunyi) {
    ambilAudioCtx();
    try {
        if ('speechSynthesis' in window) {
            pilihVoiceIndonesia();
            const u = new SpeechSynthesisUtterance(tesBunyi ? 'Suara absensi aktif' : ' ');
            u.lang = 'id-ID'; u.volume = tesBunyi ? 1 : 0;
            if (__voiceId) u.voice = __voiceId;
            window.speechSynthesis.cancel();
            window.speechSynthesis.speak(u);
        }
    } catch (e) {}
    if (tesBunyi) { bunyiTone(880, 0, 0.14, 0.5); bunyiTone(1320, 0.16, 0.22, 0.5); }
    __suaraAktif = true;
    const btn = document.getElementById('btnSuara');
    if (btn) { btn.textContent = '🔊 Suara Aktif — Ketuk untuk Tes'; btn.classList.remove('btn-gold'); btn.classList.add('btn-primary'); }
    const info = document.getElementById('infoSuara');
    if (info) info.textContent = 'Suara aktif. Jika tidak terdengar: naikkan volume media HP, matikan mode senyap (iPhone: sakelar samping), dan pastikan tidak dalam mode hening.';
}

// tampilkan panel kontrol suara + buka kunci otomatis pada sentuhan pertama di halaman
function pasangKontrolSuara(containerId) {
    const el = document.getElementById(containerId);
    if (el) {
        el.innerHTML = '<div class="card" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">' +
            '<button type="button" id="btnSuara" class="btn btn-gold" onclick="aktifkanSuara(true)">🔈 Aktifkan Suara Notifikasi</button>' +
            '<span id="infoSuara" class="muted">Di HP/tablet, ketuk tombol ini sekali agar browser mengizinkan bunyi &amp; suara saat scan.</span></div>';
    }
    const bukaOtomatis = function () {
        if (!__suaraAktif) aktifkanSuara(false);
        document.removeEventListener('touchstart', bukaOtomatis);
        document.removeEventListener('click', bukaOtomatis);
    };
    document.addEventListener('touchstart', bukaOtomatis, { passive: true });
    document.addEventListener('click', bukaOtomatis);
}

function tampilkanHasil(boxId, sukses, telat, data) {
    const box = document.getElementById(boxId);
    if (!box) return;
    box.className = 'scan-result ' + (sukses ? (telat ? 'status-late' : 'status-ok') : (data.info ? 'status-late' : 'status-error'));
    if (!sukses && data.info) {
        box.innerHTML = `
            <div class="big-icon">ℹ️</div>
            <div class="nama">Informasi</div>
            <div class="info" style="font-size:15px;color:#333;">${data.pesan}</div>
        `;
        return;
    }
    if (sukses) {
        box.innerHTML = `
            <div class="big-icon">${telat ? '⏰' : '✅'}</div>
            <div class="nama">${data.nama}</div>
            <div class="info">${data.sub ? data.sub + ' · ' : ''}${data.jenis === 'masuk' ? 'Absen Masuk' : 'Absen Pulang'} · Pukul ${data.waktu}</div>
            <div style="margin-top:8px;">${statusBadge(data.status)}</div>
        `;
    } else {
        box.innerHTML = `
            <div class="big-icon">⚠️</div>
            <div class="nama">Gagal Diproses</div>
            <div class="info">${data.pesan}</div>
        `;
    }
}

function statusBadge(status) {
    const map = { 'Hadir': 'badge-hadir', 'Terlambat': 'badge-terlambat', 'Sakit': 'badge-sakit', 'Izin': 'badge-izin', 'Alpa': 'badge-alpa' };
    const cls = map[status] || 'badge-alpa';
    return `<span class="badge-status ${cls}">${status}</span>`;
}

function tambahLog(logId, sukses, teks) {
    const log = document.getElementById(logId);
    if (!log) return;
    const item = document.createElement('div');
    item.className = 'item';
    const jam = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    item.innerHTML = `<span>${sukses ? '✅' : '⚠️'} ${teks}</span><span class="muted">${jam}</span>`;
    log.prepend(item);
}

async function prosesTokenScan(token, tipe, baseUrl, boxId, logId) {
    const now = Date.now();
    if (token === __lastToken && (now - __lastScanTime) < __COOLDOWN_MS) return;
    __lastToken = token;
    __lastScanTime = now;

    try {
        const res = await fetch(baseUrl + 'absensi/simpan_absen.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'token=' + encodeURIComponent(token) + '&tipe=' + encodeURIComponent(tipe)
        });
        const data = await res.json();
        const telat = data.status === 'Terlambat';

        if (data.success) {
            mainkanBeep(true);
            ucapkan(data.pesan_suara || (data.nama + ' berhasil absen.'));
            tampilkanHasil(boxId, true, telat, data);
            tambahLog(logId, true, `${data.nama} - ${data.jenis === 'masuk' ? 'Masuk' : 'Pulang'} (${data.status})`);
        } else if (data.info) {
            bunyiTone(660, 0, 0.12, 0.45); bunyiTone(660, 0.2, 0.12, 0.45);   // nada netral (bukan error)
            if (navigator.vibrate) navigator.vibrate([80, 60, 80]);
            ucapkan(data.pesan_suara || data.pesan);
            tampilkanHasil(boxId, false, false, data);
            tambahLog(logId, false, 'ℹ️ ' + data.pesan);
        } else {
            mainkanBeep(false);
            ucapkan(data.pesan || 'Kode tidak dikenali.');
            tampilkanHasil(boxId, false, false, data);
            tambahLog(logId, false, data.pesan || 'Gagal memproses scan.');
        }
    } catch (e) {
        mainkanBeep(false);
        tampilkanHasil(boxId, false, false, { pesan: 'Terjadi kesalahan koneksi ke server.' });
    }
}

function mulaiScanner(elementId, tipe, baseUrl, boxId, logId) {
    const html5QrCode = new Html5Qrcode(elementId);
    // sesuaikan ukuran kotak pemindai dengan lebar layar (responsif HP/tablet/PC)
    const lebarLayar = Math.min(window.innerWidth, document.getElementById(elementId).clientWidth || window.innerWidth);
    const ukuranKotak = Math.max(180, Math.min(260, Math.floor(lebarLayar * 0.72)));
    const config = { fps: 10, qrbox: { width: ukuranKotak, height: ukuranKotak } };

    Html5Qrcode.getCameras().then(cameras => {
        if (!cameras || cameras.length === 0) {
            document.getElementById(elementId).innerHTML = '<p style="padding:20px;color:#D64545;">Kamera tidak ditemukan pada perangkat ini.</p>';
            return;
        }
        // prioritaskan kamera belakang pada HP
        let camId = cameras[0].id;
        const belakang = cameras.find(c => /back|rear|environment/i.test(c.label));
        if (belakang) camId = belakang.id;

        html5QrCode.start(
            camId,
            config,
            (decodedText) => { prosesTokenScan(decodedText, tipe, baseUrl, boxId, logId); },
            (errorMessage) => { /* diabaikan: terjadi terus saat belum ada QR di frame */ }
        ).catch(err => {
            document.getElementById(elementId).innerHTML = '<p style="padding:20px;color:#D64545;">Gagal mengakses kamera: ' + err + '</p>';
        });
    }).catch(err => {
        document.getElementById(elementId).innerHTML = '<p style="padding:20px;color:#D64545;">Izin kamera ditolak atau tidak tersedia. Aktifkan izin kamera pada browser Anda.</p>';
    });
}

// mode input manual (fallback jika kamera tidak tersedia) - ketik token lalu enter
function pasangInputManual(inputId, tipe, baseUrl, boxId, logId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && input.value.trim() !== '') {
            e.preventDefault();
            const token = input.value.trim();
            input.value = '';
            __lastToken = null; // izinkan input manual walau sama
            prosesTokenScan(token, tipe, baseUrl, boxId, logId);
        }
    });
}
