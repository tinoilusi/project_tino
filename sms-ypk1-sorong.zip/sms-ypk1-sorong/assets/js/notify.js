/* =====================================================================
   SISTEM NOTIFIKASI & POPUP — SMAS YPK 1 SORONG
   - Toast (sukses / gagal / peringatan / info) + bunyi notifikasi
   - Dialog konfirmasi modern (pengganti confirm() bawaan browser)
   - Pesan server (.alert) otomatis menjadi toast bersuara
   - Lonceng notifikasi langsung (polling) dengan bunyi saat ada kabar baru
   - Bunyi dibuat dengan Web Audio API (tanpa file audio) + tombol bisukan
   API: Notify.toast(tipe, pesan, {judul, durasi}) · Notify.confirm({...}) -> Promise
        Notify.sound(tipe) · Notify.setSound(true|false)
   Konfigurasi opsional (diisi dari PHP): window.SMS = { base:'/sms/', bell:true }
   ===================================================================== */
(function () {
  'use strict';
  if (window.Notify) return;

  var CFG = window.SMS || {};
  var BASE = CFG.base || '';

  /* ---------------------------------------------------------------
     0. UTIL
     --------------------------------------------------------------- */
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  var ICON = {
    success: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m8 12 2.7 2.7L16 9.5"/></svg>',
    error:   '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/></svg>',
    warning: '<svg viewBox="0 0 24 24"><path d="M12 3 2.5 20h19z"/><path d="M12 10v4M12 17.2v.01"/></svg>',
    info:    '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.8v.01"/></svg>',
    danger:  '<svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
    bell:    '<svg viewBox="0 0 24 24"><path d="M6 9a6 6 0 1 1 12 0c0 5 2 6.5 2 6.5H4S6 14 6 9z"/><path d="M10 19a2 2 0 0 0 4 0"/></svg>',
    close:   '<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>',
    mega:    '<svg viewBox="0 0 24 24"><path d="M3 11v3a1 1 0 0 0 1 1h3l8 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M19 9a4 4 0 0 1 0 6"/></svg>',
    doc:     '<svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h4"/></svg>',
    clock:   '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    speaker: '<svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/></svg>',
    mute:    '<svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="m17 9 4 6M21 9l-4 6"/></svg>'
  };

  /* ---------------------------------------------------------------
     1. CSS
     --------------------------------------------------------------- */
  var css = [
    ':root{--nt-navy:#0B3C5D;--nt-navy2:#082A42;--nt-gold:#C9A24B;--nt-ok:#1C8C4C;--nt-err:#C13B3B;--nt-warn:#C98A0E;--nt-info:#2672A3}',
    '.nt-ic{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round;flex:none}',
    /* toast */
    '#nt-toasts{position:fixed;top:18px;right:18px;z-index:100000;display:flex;flex-direction:column;gap:12px;width:min(390px,calc(100vw - 28px));pointer-events:none;font-family:Inter,system-ui,sans-serif}',
    '.nt-t{--c:var(--nt-info);position:relative;overflow:hidden;pointer-events:auto;display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:start;padding:14px 14px 16px 16px;border-radius:16px;background:#fff;color:#16222F;',
    'border:1px solid #E7EAEF;border-left:5px solid var(--c);box-shadow:0 18px 40px rgba(8,30,48,.20),0 2px 6px rgba(8,30,48,.08);',
    'transform:translateX(24px) scale(.97);opacity:0;transition:transform .45s cubic-bezier(.2,.9,.3,1.2),opacity .3s}',
    '.nt-t.in{transform:none;opacity:1}.nt-t.out{transform:translateX(30px);opacity:0;transition:transform .3s ease,opacity .25s}',
    '.nt-t.success{--c:var(--nt-ok)}.nt-t.error{--c:var(--nt-err)}.nt-t.warning{--c:var(--nt-warn)}.nt-t.info{--c:var(--nt-info)}',
    '.nt-t .ico{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;color:var(--c);background:color-mix(in srgb,var(--c) 12%,#fff)}',
    '.nt-t b{display:block;font-size:14px;line-height:1.3;color:var(--nt-navy);margin-bottom:2px}',
    '.nt-t p{margin:0;font-size:13px;line-height:1.5;color:#39465A;word-break:break-word}',
    '.nt-t .x{border:0;background:transparent;color:#6B7A8D;cursor:pointer;width:28px;height:28px;border-radius:8px;display:grid;place-items:center;margin:-4px -4px 0 0}',
    '.nt-t .x:hover{background:#EFF2F6;color:#16222F}.nt-t .x .nt-ic{width:16px;height:16px}',
    '.nt-t .pg{position:absolute;left:0;bottom:0;height:3px;width:100%;background:var(--c);opacity:.55;transform-origin:left;animation:nt-pg linear forwards}',
    '.nt-t:hover .pg{animation-play-state:paused}',
    '.nt-t a.go{display:inline-block;margin-top:6px;font-size:12.5px;font-weight:600;color:var(--c);text-decoration:none}.nt-t a.go:hover{text-decoration:underline}',
    '@keyframes nt-pg{from{transform:scaleX(1)}to{transform:scaleX(0)}}',
    /* dialog */
    '#nt-ov{position:fixed;inset:0;z-index:100001;display:grid;place-items:center;padding:18px;background:rgba(6,20,32,.55);backdrop-filter:blur(5px);opacity:0;transition:opacity .22s;font-family:Inter,system-ui,sans-serif}',
    '#nt-ov.in{opacity:1}',
    '.nt-d{width:min(430px,100%);background:#fff;border-radius:22px;padding:28px 26px 22px;text-align:center;box-shadow:0 30px 80px rgba(6,20,32,.45);transform:translateY(14px) scale(.94);transition:transform .35s cubic-bezier(.2,.9,.3,1.25)}',
    '#nt-ov.in .nt-d{transform:none}',
    '.nt-d .big{width:64px;height:64px;border-radius:50%;margin:0 auto 16px;display:grid;place-items:center;color:var(--nt-info);background:#E8F2FA;box-shadow:0 0 0 8px #F2F8FC}',
    '.nt-d .big .nt-ic{width:30px;height:30px}',
    '.nt-d.danger .big{color:var(--nt-err);background:#FBEAEA;box-shadow:0 0 0 8px #FDF3F3}',
    '.nt-d.warning .big{color:var(--nt-warn);background:#FCF1D9;box-shadow:0 0 0 8px #FEF8EA}',
    '.nt-d.success .big{color:var(--nt-ok);background:#E6F6EC;box-shadow:0 0 0 8px #F2FAF5}',
    '.nt-d h3{margin:0 0 8px;font:700 20px "Playfair Display",Georgia,serif;color:var(--nt-navy)}',
    '.nt-d p{margin:0 0 22px;font-size:14px;line-height:1.65;color:#4A5668;white-space:pre-line;word-break:break-word}',
    '.nt-d .bt{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}',
    '.nt-d button{font:600 14px Inter,system-ui,sans-serif;padding:11px 22px;border-radius:12px;cursor:pointer;border:1.5px solid #D9DFE7;background:#fff;color:#39465A;min-width:112px;transition:transform .15s,box-shadow .2s,background .2s}',
    '.nt-d button:hover{background:#F3F6F9}.nt-d button:active{transform:scale(.97)}',
    '.nt-d button.ok{border-color:transparent;color:#fff;background:linear-gradient(135deg,var(--nt-navy),#1A5F8E);box-shadow:0 8px 18px -6px rgba(11,60,93,.6)}',
    '.nt-d button.ok:hover{background:linear-gradient(135deg,#0E4A72,#2672A3)}',
    '.nt-d.danger button.ok{background:linear-gradient(135deg,#A82E2E,#D24B4B);box-shadow:0 8px 18px -6px rgba(193,59,59,.65)}',
    '.nt-d.warning button.ok{background:linear-gradient(135deg,#A9741A,#D9A22B);box-shadow:0 8px 18px -6px rgba(201,138,14,.6)}',
    '.nt-d button:focus-visible{outline:3px solid var(--nt-gold);outline-offset:2px}',
    /* lonceng */
    '.nt-right{display:flex;align-items:center;gap:12px}',
    '.nt-bellwrap{position:relative}',
    '.nt-bell{position:relative;width:40px;height:40px;border-radius:12px;border:1px solid #E7EAEF;background:#fff;color:var(--nt-navy);cursor:pointer;display:grid;place-items:center;transition:background .2s,transform .2s,box-shadow .2s}',
    '.nt-bell:hover{background:#F3F6F9;box-shadow:0 4px 12px rgba(11,60,93,.1)}.nt-bell:active{transform:scale(.95)}',
    '.nt-bell.dark{background:rgba(255,255,255,.09);border-color:rgba(255,255,255,.18);color:#fff;border-radius:99px}.nt-bell.dark:hover{background:rgba(255,255,255,.2)}',
    '.nt-bell.ring .nt-ic{animation:nt-ring 1.1s ease 1;transform-origin:50% 8%}',
    '@keyframes nt-ring{0%,100%{transform:rotate(0)}15%{transform:rotate(16deg)}30%{transform:rotate(-14deg)}45%{transform:rotate(10deg)}60%{transform:rotate(-8deg)}75%{transform:rotate(4deg)}}',
    '.nt-badge{position:absolute;top:-5px;right:-5px;min-width:19px;height:19px;padding:0 5px;border-radius:99px;background:#D63A3A;color:#fff;font:700 11px/19px Inter,sans-serif;text-align:center;border:2px solid #fff;display:none;box-sizing:content-box;box-shadow:0 2px 6px rgba(193,59,59,.5)}',
    '.nt-bell.dark .nt-badge{border-color:#0B3C5D}.nt-badge.on{display:block;animation:nt-pop .4s cubic-bezier(.2,.9,.3,1.5)}',
    '@keyframes nt-pop{from{transform:scale(0)}to{transform:scale(1)}}',
    '.nt-panel{position:absolute;right:0;top:calc(100% + 12px);width:min(380px,calc(100vw - 24px));max-height:min(520px,calc(100vh - 110px));display:none;flex-direction:column;background:#fff;border:1px solid #E7EAEF;border-radius:18px;box-shadow:0 26px 60px rgba(8,30,48,.24);overflow:hidden;z-index:99990;font-family:Inter,system-ui,sans-serif;text-align:left}',
    '.nt-panel.open{display:flex;animation:nt-drop .28s cubic-bezier(.2,.9,.3,1.1)}',
    '@keyframes nt-drop{from{opacity:0;transform:translateY(-8px) scale(.97)}to{opacity:1;transform:none}}',
    '.nt-ph{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:15px 18px;border-bottom:1px solid #EFF2F6;background:linear-gradient(135deg,#F7FAFC,#EEF4F8)}',
    '.nt-ph b{font:700 16px "Playfair Display",Georgia,serif;color:var(--nt-navy)}',
    '.nt-ph .acts{display:flex;gap:6px}',
    '.nt-ib{width:34px;height:34px;border-radius:10px;border:1px solid #E1E7EE;background:#fff;color:#4A5668;cursor:pointer;display:grid;place-items:center;transition:.2s}',
    '.nt-ib:hover{background:var(--nt-navy);color:#fff;border-color:var(--nt-navy)}.nt-ib .nt-ic{width:17px;height:17px}.nt-ib.off{color:#C13B3B;border-color:#F0C4C4;background:#FDF3F3}',
    '.nt-list{overflow:auto;flex:1;overscroll-behavior:contain}',
    '.nt-i{display:grid;grid-template-columns:auto 1fr;gap:12px;padding:13px 18px;border-bottom:1px solid #F1F4F8;text-decoration:none;color:inherit;position:relative;transition:background .2s}',
    'a.nt-i:hover{background:#F6F9FC;text-decoration:none}',
    '.nt-i.baru{background:#F4F9FD}.nt-i.baru:before{content:"";position:absolute;left:7px;top:50%;width:6px;height:6px;margin-top:-3px;border-radius:50%;background:#2672A3}',
    '.nt-i .ico{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;color:var(--c,#2672A3);background:color-mix(in srgb,var(--c,#2672A3) 12%,#fff)}',
    '.nt-i.success{--c:#1C8C4C}.nt-i.error{--c:#C13B3B}.nt-i.warning{--c:#C98A0E}.nt-i.info{--c:#2672A3}',
    '.nt-i b{display:block;font-size:13.5px;color:#16222F;line-height:1.35}',
    '.nt-i p{margin:2px 0 0;font-size:12.5px;line-height:1.45;color:#5B6878;word-break:break-word}',
    '.nt-i time{display:block;margin-top:4px;font-size:11.5px;color:#8A97A8;font-variant-numeric:tabular-nums}',
    '.nt-empty{padding:38px 20px;text-align:center;color:#8A97A8;font-size:13.5px}.nt-empty .nt-ic{width:34px;height:34px;color:#B8C3CF;margin-bottom:8px}',
    '.nt-pf{padding:10px 18px;border-top:1px solid #EFF2F6;background:#FAFBFC;display:flex;align-items:center;justify-content:space-between;gap:10px;font-size:12px;color:#6B7A8D}',
    '.nt-pf button{border:0;background:transparent;color:var(--nt-info);font:600 12.5px Inter,sans-serif;cursor:pointer;padding:4px 6px;border-radius:6px}.nt-pf button:hover{background:#E8F2FA}',
    /* shake utk pesan inline */
    '@keyframes nt-shake{10%,90%{transform:translateX(-2px)}20%,80%{transform:translateX(4px)}30%,50%,70%{transform:translateX(-6px)}40%,60%{transform:translateX(6px)}}',
    '.nt-shake{animation:nt-shake .55s}',
    '@media(max-width:560px){#nt-toasts{top:10px;right:14px;left:14px;width:auto}.nt-panel{position:fixed;left:12px;right:12px;top:68px;width:auto}}',
    '@media(prefers-reduced-motion:reduce){.nt-t,.nt-d,#nt-ov,.nt-panel{transition:none!important;animation:none!important}.nt-t .pg{animation-duration:0s!important}}',
    '@media print{#nt-toasts,#nt-ov,.nt-bellwrap{display:none!important}}'
  ].join('');
  var st = el('style'); st.textContent = css; (document.head || document.documentElement).appendChild(st);
  function svg(name) { return (ICON[name] || ICON.info).replace('<svg ', '<svg class="nt-ic" '); }

  /* ---------------------------------------------------------------
     2. BUNYI (Web Audio API) — dibuat sekali, dibuka lewat interaksi pengguna
     --------------------------------------------------------------- */
  var ctx = null, pending = null, pendingAt = 0, unlockBound = false;
  var soundOn = lsGet('sms_snd', '1') !== '0';

  function getCtx() {
    if (!ctx) { var AC = window.AudioContext || window.webkitAudioContext; if (AC) { try { ctx = new AC(); } catch (e) {} } }
    return ctx;
  }
  function tone(freq, t0, dur, vol, type, opts) {
    var c = ctx, o = c.createOscillator(), g = c.createGain(), now = c.currentTime + t0;
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, now);
    if (opts && opts.slideTo) o.frequency.exponentialRampToValueAtTime(opts.slideTo, now + dur);
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(vol, now + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    o.connect(g); g.connect(c.destination);
    o.start(now); o.stop(now + dur + 0.03);
  }
  var SOUNDS = {
    /* naik, ceria */
    success: function () { tone(523.25, 0, .16, .22, 'triangle'); tone(659.25, .09, .16, .22, 'triangle'); tone(783.99, .18, .32, .24, 'triangle'); tone(1046.5, .18, .32, .06, 'sine'); },
    /* turun, tegas namun tidak mengagetkan */
    error: function () { tone(311.13, 0, .2, .2, 'sawtooth'); tone(233.08, .17, .34, .2, 'sawtooth'); tone(155.56, .17, .34, .08, 'square'); },
    /* dua ketukan */
    warning: function () { tone(659.25, 0, .13, .2, 'triangle'); tone(659.25, .19, .13, .2, 'triangle'); tone(493.88, .38, .2, .18, 'triangle'); },
    /* ping lembut */
    info: function () { tone(880, 0, .35, .2, 'sine'); tone(1760, 0, .22, .04, 'sine'); },
    /* lonceng kabar baru (dua nada + harmonik) */
    notif: function () { tone(987.77, 0, .5, .2, 'sine'); tone(1975.5, 0, .3, .05, 'sine'); tone(1318.5, .17, .7, .22, 'sine'); tone(2637, .17, .4, .05, 'sine'); },
    /* dialog terbuka */
    pop: function () { tone(420, 0, .09, .16, 'sine', { slideTo: 640 }); },
    /* klik pilihan hapus */
    danger: function () { tone(392, 0, .12, .18, 'triangle'); tone(293.66, .13, .22, .2, 'triangle'); }
  };
  function bindUnlock() {
    if (unlockBound) return; unlockBound = true;
    var h = function () {
      var c = getCtx(); if (!c) return;
      var go = function () {
        if (pending && Date.now() - pendingAt < 20000) { var p = pending; pending = null; try { SOUNDS[p](); } catch (e) {} }
        pending = null;
      };
      if (c.state === 'suspended') { c.resume().then(go, go); } else go();
      ['pointerdown', 'keydown', 'touchstart', 'click'].forEach(function (ev) { document.removeEventListener(ev, h, true); });
      unlockBound = false;
    };
    ['pointerdown', 'keydown', 'touchstart', 'click'].forEach(function (ev) { document.addEventListener(ev, h, true); });
  }
  function sound(name, force) {
    if (!soundOn && !force) return;
    var fn = SOUNDS[name]; if (!fn) return;
    var c = getCtx(); if (!c) return;
    var play = function () { try { fn(); } catch (e) {} };
    if (c.state === 'running') { play(); }
    else {
      c.resume().then(function () { if (c.state === 'running') play(); else { pending = name; pendingAt = Date.now(); bindUnlock(); } },
                      function () { pending = name; pendingAt = Date.now(); bindUnlock(); });
    }
    try { if (navigator.vibrate && (name === 'error' || name === 'warning')) navigator.vibrate(name === 'error' ? [120, 70, 120] : 90); } catch (e) {}
  }
  function setSound(on) { soundOn = !!on; lsSet('sms_snd', on ? '1' : '0'); syncSoundBtns(); }

  /* ---------------------------------------------------------------
     3. TOAST
     --------------------------------------------------------------- */
  var wrap = null, TITLES = { success: 'Berhasil', error: 'Gagal', warning: 'Perhatian', info: 'Informasi' };
  function ensureWrap() {
    if (wrap && document.body.contains(wrap)) return wrap;
    wrap = el('div'); wrap.id = 'nt-toasts'; wrap.setAttribute('aria-live', 'polite'); wrap.setAttribute('aria-atomic', 'false');
    document.body.appendChild(wrap); return wrap;
  }
  function toast(tipe, pesan, o) {
    o = o || {};
    if (!ICON[tipe] || tipe === 'danger') tipe = 'info';
    if (!document.body) { document.addEventListener('DOMContentLoaded', function () { toast(tipe, pesan, o); }); return; }
    var w = ensureWrap();
    // maksimal 4 toast; buang yang tertua. Hindari duplikat identik yang sedang tampil.
    var key = tipe + '|' + (o.judul || '') + '|' + (o.html ? pesan : String(pesan));
    var dup = null;
    for (var di = 0; di < w.children.length; di++) { if (w.children[di].getAttribute('data-k') === key) { dup = w.children[di]; break; } }
    if (dup) { dup.classList.remove('nt-shake'); void dup.offsetWidth; dup.classList.add('nt-shake'); if (o.suara !== false) sound(o.suara || (tipe === 'success' ? 'success' : tipe)); return dup; }
    while (w.children.length >= 4) w.removeChild(w.firstChild);

    var dur = o.durasi != null ? o.durasi : (tipe === 'error' ? 9000 : tipe === 'warning' ? 7000 : 5000);
    var t = el('div', 'nt-t ' + tipe); t.setAttribute('role', tipe === 'error' ? 'alert' : 'status'); t.setAttribute('data-k', key);
    var body = (o.judul === false ? '' : '<b>' + esc(o.judul || TITLES[tipe]) + '</b>') + '<p>' + (o.html ? pesan : esc(pesan)) + '</p>' +
               (o.url ? '<a class="go" href="' + esc(o.url) + '">' + esc(o.urlTeks || 'Lihat') + ' →</a>' : '');
    t.innerHTML = '<span class="ico">' + svg(tipe) + '</span><div>' + body + '</div><button class="x" type="button" aria-label="Tutup">' + svg('close') + '</button>' +
                  (dur > 0 ? '<i class="pg" style="animation-duration:' + dur + 'ms"></i>' : '');
    w.appendChild(t);
    var closed = false, timer = null;
    function close() { if (closed) return; closed = true; clearTimeout(timer); t.classList.remove('in'); t.classList.add('out'); setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 320); }
    t.querySelector('.x').addEventListener('click', close);
    if (dur > 0) {
      var left = dur, started = Date.now();
      var arm = function () { started = Date.now(); timer = setTimeout(close, left); };
      t.addEventListener('mouseenter', function () { clearTimeout(timer); left -= Date.now() - started; });
      t.addEventListener('mouseleave', arm); arm();
    }
    requestAnimationFrame(function () { requestAnimationFrame(function () { t.classList.add('in'); }); });
    if (o.suara !== false) sound(o.suara || (tipe === 'success' ? 'success' : tipe));
    return t;
  }

  /* ---------------------------------------------------------------
     4. DIALOG KONFIRMASI / ALERT
     --------------------------------------------------------------- */
  var dlgOpen = false, dlgQueue = [];
  function dialog(o) {
    return new Promise(function (resolve) {
      if (dlgOpen) { dlgQueue.push(function () { dialog(o).then(resolve); }); return; }
      dlgOpen = true;
      var tipe = o.tipe || 'info', prev = document.activeElement;
      var ov = el('div'); ov.id = 'nt-ov';
      var d = el('div', 'nt-d ' + tipe); d.setAttribute('role', 'alertdialog'); d.setAttribute('aria-modal', 'true'); d.setAttribute('aria-labelledby', 'nt-dt'); d.setAttribute('aria-describedby', 'nt-dm');
      var iconName = tipe === 'danger' ? 'danger' : (tipe === 'warning' ? 'warning' : (tipe === 'success' ? 'success' : 'info'));
      d.innerHTML = '<div class="big">' + svg(iconName) + '</div><h3 id="nt-dt">' + esc(o.judul || 'Konfirmasi') + '</h3><p id="nt-dm">' + esc(o.pesan || '') + '</p>' +
        '<div class="bt">' + (o.batal === false ? '' : '<button type="button" class="no">' + esc(o.batalTeks || 'Batal') + '</button>') + '<button type="button" class="ok">' + esc(o.okTeks || 'Ya, Lanjutkan') + '</button></div>';
      ov.appendChild(d); document.body.appendChild(ov);
      var prevOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
      var ok = d.querySelector('.ok'), no = d.querySelector('.no');
      function done(v) {
        document.removeEventListener('keydown', key, true);
        ov.classList.remove('in'); document.body.style.overflow = prevOverflow;
        setTimeout(function () {
          if (ov.parentNode) ov.parentNode.removeChild(ov);
          dlgOpen = false; try { if (prev && prev.focus) prev.focus(); } catch (e) {}
          resolve(v); var n = dlgQueue.shift(); if (n) n();
        }, 220);
      }
      function key(e) {
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); done(false); }
        else if (e.key === 'Tab') {
          var f = [no, ok].filter(Boolean), i = f.indexOf(document.activeElement);
          e.preventDefault(); f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus();
        }
      }
      document.addEventListener('keydown', key, true);
      ok.addEventListener('click', function () { done(true); });
      if (no) no.addEventListener('click', function () { done(false); });
      ov.addEventListener('mousedown', function (e) { if (e.target === ov && o.batal !== false) done(false); });
      requestAnimationFrame(function () { requestAnimationFrame(function () { ov.classList.add('in'); }); });
      // fokus aman: pada aksi berbahaya, fokus ke "Batal"
      setTimeout(function () { (tipe === 'danger' && no ? no : ok).focus(); }, 60);
      sound(tipe === 'danger' ? 'danger' : tipe === 'warning' ? 'warning' : 'pop');
    });
  }
  function confirmDlg(o) { if (typeof o === 'string') o = { pesan: o }; return dialog(o); }
  function alertDlg(o) { if (typeof o === 'string') o = { pesan: o }; o.batal = false; o.okTeks = o.okTeks || 'Mengerti'; return dialog(o); }

  // Ambil judul/tombol/tipe yang cocok dari kalimat konfirmasi lama
  function describe(msg) {
    var m = String(msg || ''), o = { pesan: m, tipe: 'info', judul: 'Konfirmasi', okTeks: 'Ya, Lanjutkan' };
    if (/hapus|permanen/i.test(m)) { o.tipe = 'danger'; o.judul = 'Hapus Data?'; o.okTeks = 'Ya, Hapus'; }
    else if (/batalkan/i.test(m)) { o.tipe = 'warning'; o.judul = 'Batalkan?'; o.okTeks = 'Ya, Batalkan'; }
    else if (/perhatian/i.test(m)) { o.tipe = 'warning'; o.judul = 'Perhatian'; o.okTeks = 'Ya, Proses'; }
    else if (/dipulangkan|umumkan/i.test(m)) { o.tipe = 'warning'; o.judul = 'Umumkan Sekarang?'; o.okTeks = 'Ya, Umumkan'; }
    else if (/kirim/i.test(m)) { o.judul = 'Kirim Laporan?'; o.okTeks = 'Ya, Kirim'; }
    else if (/bayar/i.test(m)) { o.tipe = 'warning'; o.judul = 'Konfirmasi Pembayaran'; o.okTeks = 'Ya, Bayar'; }
    else if (/catat/i.test(m)) { o.judul = 'Catat Pulang Awal?'; o.okTeks = 'Ya, Catat'; }
    else if (/ganti|aktifkan/i.test(m)) { o.tipe = 'warning'; o.judul = 'Ubah Pengaturan?'; }
    return o;
  }

  /* Ubah semua onclick/onsubmit="return confirm('...')" lama menjadi dialog modern tanpa mengubah file halaman */
  var RX = /confirm\(\s*(['"])((?:\\[\s\S]|(?!\1)[^\\])*)\1\s*\)/;
  function convertInline(root) {
    (root || document).querySelectorAll('[onclick*="confirm("],[onsubmit*="confirm("]').forEach(function (n) {
      var code = n.getAttribute('onclick') || n.getAttribute('onsubmit') || '', m = RX.exec(code);
      if (!m) return;
      n.setAttribute('data-konfirm', m[2].replace(/\\(['"\\])/g, '$1').replace(/\\n/g, '\n'));
      n.removeAttribute('onclick'); n.removeAttribute('onsubmit');
    });
  }
  function proceed(n, submitter) {
    if (n.tagName === 'FORM') {
      n.__nt = true;
      try { if (n.requestSubmit) n.requestSubmit(submitter || undefined); else n.submit(); } catch (e) { n.submit(); }
    } else if (n.tagName === 'A') {
      var tg = n.getAttribute('target');
      if (tg && tg !== '_self') window.open(n.href, tg); else window.location.href = n.href;
    } else if (n.form) {
      n.form.__nt = true;
      try { if (n.form.requestSubmit) n.form.requestSubmit(n); else n.form.submit(); } catch (e) { n.form.submit(); }
    } else { n.click(); }
  }
  document.addEventListener('click', function (e) {
    var n = e.target.closest && e.target.closest('[data-konfirm]');
    if (!n || n.tagName === 'FORM') return;
    e.preventDefault(); e.stopPropagation();
    confirmDlg(describe(n.getAttribute('data-konfirm'))).then(function (ya) { if (ya) proceed(n); });
  }, true);
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.__nt) { f.__nt = false; return; }
    if (!f.hasAttribute || !f.hasAttribute('data-konfirm')) return;
    e.preventDefault(); e.stopImmediatePropagation();
    var sub = e.submitter;
    confirmDlg(describe(f.getAttribute('data-konfirm'))).then(function (ya) { if (ya) proceed(f, sub); });
  }, true);

  // window.alert() lama -> toast (tidak memblokir halaman)
  window.alert = function (msg) { toast(/gagal|tidak|error|salah/i.test(String(msg)) ? 'error' : 'info', String(msg)); };

  /* ---------------------------------------------------------------
     5. PESAN SERVER (.alert) -> TOAST BERSUARA
     --------------------------------------------------------------- */
  function convertFlash() {
    document.querySelectorAll('.alert').forEach(function (a) {
      if (a.__nt) return; a.__nt = true;
      var tipe = a.classList.contains('alert-error') ? 'error' : (a.classList.contains('alert-warning') ? 'warning' : (a.classList.contains('alert-success') ? 'success' : 'info'));
      var teks = (a.textContent || '').replace(/\s+/g, ' ').trim(); if (!teks) return;
      // beberapa halaman memakai kotak "sukses" untuk pesan gagal — deteksi dari kalimatnya
      if (tipe === 'success' && /^(gagal|tidak (dapat|bisa|ditemukan|valid)|error|maaf|data tidak|kesalahan)/i.test(teks)) tipe = 'error';
      if (a.hasAttribute('data-nt-inline')) {            // tetap tampil di tempat, hanya diberi bunyi + getar
        a.classList.add('nt-shake'); sound(tipe === 'success' ? 'success' : tipe); return;
      }
      toast(tipe, teks, { html: false });
      a.style.display = 'none';
    });
  }

  /* ---------------------------------------------------------------
     6. LONCENG NOTIFIKASI LANGSUNG
     --------------------------------------------------------------- */
  var bell = null, panel = null, listEl = null, badge = null, btn = null, soundBtn = null;
  var known = null, lastUnread = 0, pollTimer = null, offset = 0, lastItems = [], first = true;
  var ITEM_ICON = { info: 'mega', warning: 'clock', error: 'warning', success: 'doc' };

  function rel(ts) {
    var s = Math.max(0, Math.round((Date.now() / 1000 + offset) - ts));
    if (s < 45) return 'Baru saja';
    if (s < 3600) return Math.round(s / 60) + ' menit lalu';
    if (s < 86400) return Math.round(s / 3600) + ' jam lalu';
    var d = new Date(ts * 1000), p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  function syncSoundBtns() {
    if (!soundBtn) return;
    soundBtn.innerHTML = svg(soundOn ? 'speaker' : 'mute');
    soundBtn.classList.toggle('off', !soundOn);
    soundBtn.title = soundOn ? 'Bunyi notifikasi: HIDUP (klik untuk bisukan)' : 'Bunyi notifikasi: MATI (klik untuk menyalakan)';
    soundBtn.setAttribute('aria-pressed', String(!soundOn));
  }
  function render(items, unread) {
    lastItems = items;
    badge.textContent = unread > 99 ? '99+' : unread; badge.classList.toggle('on', unread > 0);
    btn.setAttribute('aria-label', 'Notifikasi' + (unread ? ', ' + unread + ' belum dibaca' : ''));
    if (!items.length) { listEl.innerHTML = '<div class="nt-empty">' + svg('bell') + '<div>Belum ada notifikasi.</div></div>'; return; }
    listEl.innerHTML = '';
    items.forEach(function (it) {
      var tag = it.url ? 'a' : 'div', n = el(tag, 'nt-i ' + (it.tipe || 'info') + (it.baru ? ' baru' : ''));
      if (it.url) n.href = it.url;
      n.innerHTML = '<span class="ico">' + svg(ITEM_ICON[it.tipe] || 'bell') + '</span><div><b>' + esc(it.judul) + '</b>' + (it.teks ? '<p>' + esc(it.teks) + '</p>' : '') + '<time>' + esc(rel(it.ts)) + '</time></div>';
      listEl.appendChild(n);
    });
  }
  function api(aksi, post) {
    var url = (CFG.api || (BASE + 'notifikasi_api.php')) + '?aksi=' + aksi;
    return fetch(url, { method: post ? 'POST' : 'GET', credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' }, cache: 'no-store' })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); });
  }
  function poll() {
    if (document.hidden) return;
    api('cek').then(function (d) {
      if (!d || !d.ok) return;
      offset = d.now - Date.now() / 1000;
      var fresh = d.items.filter(function (i) { return i.baru; });
      var isNew = fresh.filter(function (i) { return !known || !known[i.id]; });
      if (first) {
        first = false;
        if (d.unread > 0) {
          toast('info', 'Anda memiliki ' + d.unread + ' notifikasi baru.', { judul: 'Notifikasi', suara: 'notif', durasi: 6000 });
          bell.classList.add('ring');
        }
      } else if (isNew.length) {
        isNew.slice(0, 3).forEach(function (i, idx) {
          toast(i.tipe || 'info', i.teks || '', { judul: i.judul, url: i.url, urlTeks: 'Buka', suara: idx === 0 ? 'notif' : false, durasi: 8000 });
        });
        if (isNew.length > 3) toast('info', '+' + (isNew.length - 3) + ' notifikasi lainnya di lonceng.', { judul: 'Notifikasi', suara: false });
        bell.classList.remove('ring'); void bell.offsetWidth; bell.classList.add('ring');
        document.title = '(' + d.unread + ') ' + document.title.replace(/^\(\d+\)\s*/, '');
      }
      known = {}; d.items.forEach(function (i) { known[i.id] = 1; });
      lastUnread = d.unread; render(d.items, d.unread);
      if (!d.unread) document.title = document.title.replace(/^\(\d+\)\s*/, '');
    }).catch(function () {});
  }
  function markRead() {
    if (!lastUnread) return;
    api('baca', true).then(function (d) {
      if (d && d.ok) { lastUnread = 0; lastItems.forEach(function (i) { i.baru = false; }); render(lastItems, 0); document.title = document.title.replace(/^\(\d+\)\s*/, ''); }
    }).catch(function () {});
  }
  function togglePanel(force) {
    var open = force != null ? force : !panel.classList.contains('open');
    panel.classList.toggle('open', open); btn.setAttribute('aria-expanded', String(open));
    bell.classList.remove('ring');
    if (open) { render(lastItems, lastUnread); sound('pop'); setTimeout(markRead, 1800); }
  }
  function buildBell() {
    var slot = document.querySelector('[data-nt-slot]'), dark = false, host = null, clock = null;
    if (slot) { dark = slot.getAttribute('data-nt-slot') === 'dark'; host = slot; }
    else {
      var bar = document.querySelector('.topbar'); if (!bar) return false;
      clock = bar.querySelector('.clock');
      host = el('div', 'nt-right');
      if (clock) { clock.parentNode.insertBefore(host, clock); } else { bar.appendChild(host); }
    }
    var w = el('div', 'nt-bellwrap');
    btn = el('button', 'nt-bell' + (dark ? ' dark' : '')); btn.type = 'button'; btn.id = 'ntBell'; btn.setAttribute('aria-haspopup', 'true'); btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-label', 'Notifikasi');
    btn.innerHTML = svg('bell') + '<span class="nt-badge"></span>';
    badge = btn.querySelector('.nt-badge'); bell = btn;
    panel = el('div', 'nt-panel'); panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Daftar notifikasi');
    panel.innerHTML = '<div class="nt-ph"><b>Notifikasi</b><div class="acts"><button type="button" class="nt-ib" id="ntSnd"></button><button type="button" class="nt-ib" id="ntTest" title="Uji bunyi notifikasi">' + svg('bell') + '</button></div></div><div class="nt-list"></div><div class="nt-pf"><span>Diperbarui otomatis</span><button type="button" id="ntRead">Tandai semua dibaca</button></div>';
    listEl = panel.querySelector('.nt-list'); soundBtn = panel.querySelector('#ntSnd');
    w.appendChild(btn); w.appendChild(panel); host.appendChild(w);
    if (clock && host.className === 'nt-right') host.appendChild(clock);
    syncSoundBtns();
    btn.addEventListener('click', function (e) { e.stopPropagation(); getCtx() && getCtx().resume && getCtx().resume(); togglePanel(); });
    panel.addEventListener('click', function (e) { e.stopPropagation(); });
    document.addEventListener('click', function () { if (panel.classList.contains('open')) togglePanel(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && panel.classList.contains('open')) { togglePanel(false); btn.focus(); } });
    soundBtn.addEventListener('click', function () { setSound(!soundOn); if (soundOn) sound('notif'); });
    panel.querySelector('#ntTest').addEventListener('click', function () { sound('notif', true); toast('info', 'Beginilah bunyi notifikasi baru.', { judul: 'Uji bunyi', suara: false, durasi: 3000 }); });
    panel.querySelector('#ntRead').addEventListener('click', function () { lastUnread = lastUnread || 1; markRead(); });
    render([], 0);
    return true;
  }

  /* ---------------------------------------------------------------
     7. INISIALISASI
     --------------------------------------------------------------- */
  function init() {
    convertInline(document);
    convertFlash();
    // pasang kembali bila konten ditambah lewat JS (mis. baris tabel dinamis)
    if ('MutationObserver' in window) {
      new MutationObserver(function (ms) {
        var add = false; ms.forEach(function (m) { if (m.addedNodes.length) add = true; });
        if (add) { convertInline(document); }
      }).observe(document.body, { childList: true, subtree: true });
    }
    // buka kunci audio pada interaksi pertama (kebijakan autoplay browser)
    bindUnlock();
    if (CFG.bell && buildBell()) {
      poll(); pollTimer = setInterval(poll, 30000);
      document.addEventListener('visibilitychange', function () { if (!document.hidden) poll(); });
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  window.Notify = {
    toast: toast, confirm: confirmDlg, alert: alertDlg, sound: sound, setSound: setSound,
    isSoundOn: function () { return soundOn; },
    success: function (m, o) { return toast('success', m, o); }, error: function (m, o) { return toast('error', m, o); },
    warning: function (m, o) { return toast('warning', m, o); }, info: function (m, o) { return toast('info', m, o); },
    refresh: poll
  };
})();
