/* Lightbox global: klik gambar/foto mana pun untuk melihat detail (zoom, geser, galeri, unduh) */
(function () {
  var css = '#lbx{position:fixed;inset:0;z-index:99999;display:none;background:rgba(6,20,32,.94);backdrop-filter:blur(6px);touch-action:none;user-select:none;opacity:0;transition:opacity .25s}' +
    '#lbx.show{display:block}#lbx.in{opacity:1}' +
    '#lbx .st{position:absolute;inset:56px 0 48px;overflow:hidden;display:flex;align-items:center;justify-content:center}' +
    '#lbx img{max-width:92%;max-height:100%;border-radius:8px;box-shadow:0 20px 70px rgba(0,0,0,.6);cursor:zoom-in;transition:transform .2s ease;transform-origin:center;-webkit-user-drag:none}' +
    '#lbx img.zm{cursor:grab}#lbx img.dr{transition:none;cursor:grabbing}' +
    '#lbx .tb{position:absolute;top:0;left:0;right:0;height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;color:#fff;font:600 14px system-ui,sans-serif}' +
    '#lbx .cap{max-width:55%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '#lbx .bt{display:flex;gap:8px}#lbx button,#lbx a.b{width:38px;height:38px;border-radius:50%;border:1px solid rgba(201,162,75,.6);background:rgba(255,255,255,.08);color:#fff;font-size:18px;cursor:pointer;display:grid;place-items:center;text-decoration:none;transition:.2s}' +
    '#lbx button:hover,#lbx a.b:hover{background:#C9A24B;color:#082A42;transform:scale(1.08)}' +
    '#lbx .nv{position:absolute;top:50%;margin-top:-22px;width:44px;height:44px;font-size:22px}#lbx .pv{left:14px}#lbx .nx{right:14px}' +
    '#lbx .ft{position:absolute;bottom:0;left:0;right:0;height:48px;display:flex;align-items:center;justify-content:center;color:#b9c6cf;font:13px system-ui,sans-serif}' +
    'img[data-lbz]{cursor:zoom-in}@media print{#lbx{display:none!important}}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  var box, im, cap, cnt, list = [], idx = 0, sc = 1, tx = 0, ty = 0, pts = {}, pd = 0;
  function ok(e) {
    if (!e || e.tagName !== 'IMG' || e.hasAttribute('data-nozoom') || e.closest('#lbx,a[href],button,label,.no-zoom')) return false;
    var r = e.getBoundingClientRect(); return r.width >= 24 && r.height >= 24 && !!e.currentSrc;
  }
  function build() {
    if (box) return;
    box = document.createElement('div'); box.id = 'lbx';
    box.innerHTML = '<div class="tb"><span class="cap"></span><span class="bt"><button data-a="in" title="Perbesar">＋</button><button data-a="out" title="Perkecil">−</button><button data-a="rs" title="Atur ulang">⟲</button><a class="b" data-a="dl" download title="Unduh">⬇</a><button data-a="x" title="Tutup (Esc)">✕</button></span></div>' +
      '<div class="st"><img alt=""></div><button class="nv pv" data-a="pv">‹</button><button class="nv nx" data-a="nx">›</button><div class="ft"></div>';
    document.body.appendChild(box);
    im = box.querySelector('.st img'); cap = box.querySelector('.cap'); cnt = box.querySelector('.ft');
    box.addEventListener('click', function (e) {
      var a = e.target.closest('[data-a]'); if (a) { act(a.getAttribute('data-a')); return; }
      if (e.target === box || e.target.classList.contains('st')) close();
    });
    im.addEventListener('dblclick', function () { sc > 1 ? reset() : zoom(2.5); });
    im.addEventListener('click', function () { if (!im.moved && sc === 1) zoom(2.5); });
    box.addEventListener('wheel', function (e) { e.preventDefault(); zoom(sc * (e.deltaY < 0 ? 1.2 : 1 / 1.2)); }, { passive: false });
    im.addEventListener('pointerdown', function (e) { im.setPointerCapture(e.pointerId); pts[e.pointerId] = { x: e.clientX, y: e.clientY }; im.moved = false; im.classList.add('dr'); pd = dist(); });
    im.addEventListener('pointermove', function (e) {
      var p = pts[e.pointerId]; if (!p) return; var n = Object.keys(pts).length;
      if (n === 2) { pts[e.pointerId] = { x: e.clientX, y: e.clientY }; var d = dist(); if (pd) zoom(sc * d / pd); pd = d; im.moved = true; return; }
      if (sc > 1) { tx += e.clientX - p.x; ty += e.clientY - p.y; im.moved = true; apply(); }
      pts[e.pointerId] = { x: e.clientX, y: e.clientY };
    });
    function up(e) { delete pts[e.pointerId]; pd = 0; im.classList.remove('dr'); }
    im.addEventListener('pointerup', up); im.addEventListener('pointercancel', up);
    document.addEventListener('keydown', function (e) {
      if (!box.classList.contains('show')) return;
      if (e.key === 'Escape') close(); else if (e.key === 'ArrowLeft') go(-1); else if (e.key === 'ArrowRight') go(1);
      else if (e.key === '+' || e.key === '=') zoom(sc * 1.25); else if (e.key === '-') zoom(sc / 1.25);
    });
  }
  function dist() { var k = Object.keys(pts); if (k.length < 2) return 0; var a = pts[k[0]], b = pts[k[1]]; return Math.hypot(a.x - b.x, a.y - b.y); }
  function apply() { im.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(' + sc + ')'; im.classList.toggle('zm', sc > 1); }
  function zoom(v) { sc = Math.max(1, Math.min(6, v)); if (sc === 1) { tx = ty = 0; } apply(); }
  function reset() { sc = 1; tx = ty = 0; apply(); }
  function show() {
    var e = list[idx], src = e.currentSrc || e.src; reset(); im.src = src;
    cap.textContent = e.alt || e.title || 'Gambar';
    box.querySelector('[data-a=dl]').href = src; box.querySelector('[data-a=dl]').setAttribute('download', (e.alt || 'gambar').replace(/\W+/g, '_'));
    cnt.textContent = (idx + 1) + ' / ' + list.length + '   •   Scroll / cubit untuk zoom, seret untuk menggeser';
    var m = list.length < 2 ? 'none' : ''; box.querySelector('.pv').style.display = box.querySelector('.nx').style.display = m;
  }
  function go(d) { if (list.length < 2) return; idx = (idx + d + list.length) % list.length; show(); }
  function act(a) { ({ x: close, pv: function () { go(-1); }, nx: function () { go(1); }, in: function () { zoom(sc * 1.4); }, out: function () { zoom(sc / 1.4); }, rs: reset, dl: function () {} })[a](); }
  function open(el) {
    build();
    var seen = {}; list = [].filter.call(document.images, ok).filter(function (i) { var s = i.currentSrc; if (seen[s]) return i === el; seen[s] = 1; return true; });
    idx = Math.max(0, list.indexOf(el)); if (list.indexOf(el) < 0) { list.push(el); idx = list.length - 1; }
    show(); box.classList.add('show'); void box.offsetWidth; box.classList.add('in'); document.documentElement.style.overflow = 'hidden';
  }
  function close() { box.classList.remove('in'); setTimeout(function () { box.classList.remove('show'); im.removeAttribute('src'); }, 250); document.documentElement.style.overflow = ''; }
  document.addEventListener('mouseover', function (e) { var t = e.target; if (t.tagName === 'IMG' && !t.hasAttribute('data-lbz') && ok(t)) t.setAttribute('data-lbz', 1); });
  document.addEventListener('click', function (e) { var t = e.target; if (ok(t)) { e.preventDefault(); open(t); } });
})();
