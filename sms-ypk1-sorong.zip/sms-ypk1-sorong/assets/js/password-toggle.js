// Tombol "tampilkan / sembunyikan password" pada kolom password (login & Akun Pengguna)
(function () {
  document.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('.pw-toggle') : null;
    if (!btn) return;
    var field = btn.parentNode.querySelector('input');
    if (!field) return;
    var tampil = field.type === 'password';
    field.type = tampil ? 'text' : 'password';
    btn.classList.toggle('shown', tampil);
    btn.setAttribute('aria-pressed', tampil ? 'true' : 'false');
    var label = tampil ? 'Sembunyikan password' : 'Tampilkan password';
    btn.setAttribute('aria-label', label);
    btn.setAttribute('title', label);
    field.focus();
  });
})();
