<?php
require_once __DIR__ . '/config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/includes/functions.php';

$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$logo_url = url_logo_sekolah($conn);
$pf = profil_pengguna($conn);
$ta_aktif = tahun_ajaran_aktif($conn);

// helper: satu angka dari query (semua query di halaman ini tanpa input pengguna)
$angka = function ($sql) use ($conn) {
    $r = mysqli_query($conn, $sql);
    $x = $r ? mysqli_fetch_row($r) : [0];
    return (float)($x[0] ?? 0);
};

// ---- ringkasan Manajemen ----
$jml_siswa   = (int)$angka("SELECT COUNT(*) FROM siswa WHERE status='Aktif'");
$jml_pegawai = (int)$angka("SELECT COUNT(*) FROM pegawai WHERE status_aktif=1");
$jml_kelas   = (int)$angka("SELECT COUNT(*) FROM kelas");

// ---- ringkasan Absensi hari ini ----
$tgl = date('Y-m-d');
$hadir_siswa   = (int)$angka("SELECT COUNT(*) FROM absensi_siswa WHERE tanggal='$tgl' AND status IN ('Hadir','Terlambat')");
$hadir_pegawai = (int)$angka("SELECT COUNT(*) FROM absensi_pegawai WHERE tanggal='$tgl' AND status IN ('Hadir','Terlambat')");
$pct_siswa   = $jml_siswa   > 0 ? min(100, round($hadir_siswa   / $jml_siswa   * 100)) : 0;
$pct_pegawai = $jml_pegawai > 0 ? min(100, round($hadir_pegawai / $jml_pegawai * 100)) : 0;

// ---- ringkasan Keuangan ----
$bulan_ini = date('Y-m');
$masuk_bln  = $angka("SELECT COALESCE(SUM(jumlah),0) FROM transaksi_keuangan WHERE tipe='Pemasukan'   AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini'");
$keluar_bln = $angka("SELECT COALESCE(SUM(jumlah),0) FROM transaksi_keuangan WHERE tipe='Pengeluaran' AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini'");
$saldo_kas  = $angka("SELECT COALESCE(SUM(CASE WHEN tipe='Pemasukan' THEN jumlah ELSE -jumlah END),0) FROM transaksi_keuangan");

// ---- ringkasan E-Rapor ----
$target_nilai = 0; $sudah_nilai = 0;
if ($ta_aktif) {
    $taid = (int)$ta_aktif['id'];
    $target_nilai = (int)$angka("SELECT COUNT(*) FROM pengajaran p JOIN siswa s ON s.kelas_id=p.kelas_id AND s.status='Aktif' WHERE p.tahun_ajaran_id=$taid");
    $sudah_nilai  = (int)$angka("SELECT COUNT(*) FROM nilai_akademik WHERE tahun_ajaran_id=$taid AND nilai_akhir IS NOT NULL");
}
$pct_rapor = $target_nilai > 0 ? min(100, round($sudah_nilai / $target_nilai * 100)) : 0;

// foto profil: potret 3:4 hasil pemotongan otomatis (sama seperti di beranda)
$foto_potret = null;
$pid = (int)($_SESSION['pegawai_id'] ?? 0);
if ($pid > 0) {
    $rf = mysqli_query($conn, "SELECT foto FROM pegawai WHERE id=$pid LIMIT 1");
    $df = $rf ? mysqli_fetch_assoc($rf) : null;
    if ($df && $df['foto']) $foto_potret = foto_potret($df['foto']);
}
$inisial = mb_strtoupper(mb_substr(trim($pf['nama']) ?: '?', 0, 1));
$tahun_ta = $ta_aktif ? ($ta_aktif['tahun'] . ' · Semester ' . $ta_aktif['semester']) : 'Belum ada tahun ajaran aktif';
$hari = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][(int)date('w')];

$menu = [
  [
    'href' => 'manajemen/dashboard.php', 'ikon' => 'school', 'warna' => 'navy',
    'judul' => 'Manajemen Sekolah',
    'desk'  => 'Data siswa, guru &amp; staf, kelas, tahun ajaran, kenaikan kelas, akun pengguna, pengumuman &amp; pengaturan.',
  ],
  [
    'href' => 'absensi/beranda.php', 'ikon' => 'qr', 'warna' => 'green',
    'judul' => 'Absensi Sekolah',
    'desk'  => 'Scan QR Code kehadiran guru, staf &amp; siswa, rekap harian/bulanan, dan status kehadiran real-time.',
  ],
  [
    'href' => 'keuangan/dashboard.php', 'ikon' => 'wallet', 'warna' => 'gold',
    'judul' => 'Keuangan Sekolah &amp; Komite',
    'desk'  => 'Buku kas, SPP &amp; iuran komite, gaji guru honorer (per jam), kategori anggaran, dan laporan keuangan bulanan.',
  ],
  [
    'href' => 'erapor/dashboard.php', 'ikon' => 'book', 'warna' => 'blue',
    'judul' => 'E-Rapor (Akademik)',
    'desk'  => 'Nilai per mata pelajaran, sikap &amp; catatan wali kelas, penugasan guru mapel, dan cetak rapor siswa.',
  ],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Menu Utama - <?php echo bersihkan($nama_sekolah); ?></title>
<link rel="stylesheet" href="<?php echo aset('assets/css/style.css'); ?>">
<script>window.SMS = { base: <?php echo json_encode(BASE_URL); ?>, bell: true };</script>
<script src="<?php echo aset('assets/js/notify.js'); ?>" defer></script>
<style>
/* ===== MENU UTAMA KEPALA SEKOLAH (portal) — gaya khusus halaman ini, awalan .pm- ===== */
.pm{ --a1:var(--navy); --a2:#2E7AAE; min-height:100vh; background:#EEF2F6; position:relative; padding-bottom:40px; }
.pm *{ box-sizing:border-box; }
.pm-top{ position:relative; overflow:hidden; color:#fff; padding:22px 0 150px;
  background:
    radial-gradient(900px 380px at 85% -10%, rgba(201,162,75,.30), transparent 60%),
    radial-gradient(700px 360px at -5% 110%, rgba(46,122,174,.45), transparent 60%),
    linear-gradient(135deg, var(--navy-darker) 0%, var(--navy-dark) 45%, var(--navy) 100%); }
.pm-top:before{ content:""; position:absolute; inset:0; opacity:.07;
  background-image:radial-gradient(circle at 20% 30%, #fff 2px, transparent 3px), radial-gradient(circle at 70% 65%, #E6C877 2px, transparent 3px);
  background-size:120px 120px; }
.pm-wrap{ position:relative; width:min(1120px, 92%); margin:0 auto; }
.pm-nav{ display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap; }
.pm-brand{ display:flex; align-items:center; gap:14px; min-width:0; }
.pm-brand img{ width:48px; height:48px; border-radius:50%; object-fit:contain; background:rgba(255,255,255,.1); padding:2px; filter:drop-shadow(0 3px 8px rgba(0,0,0,.35)); }
.pm-brand b{ display:block; font:700 18px/1.2 'Playfair Display',serif; letter-spacing:.2px; }
.pm-brand span{ display:block; font-size:12px; color:#B9CBD8; letter-spacing:.06em; text-transform:uppercase; margin-top:2px; }
.pm-tools{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
.pm-chip{ display:inline-flex; align-items:center; gap:8px; padding:8px 14px; border-radius:99px; font-size:12.5px; font-weight:500; color:#E4EDF3;
  background:rgba(255,255,255,.09); border:1px solid rgba(255,255,255,.16); backdrop-filter:blur(6px); font-variant-numeric:tabular-nums; }
.pm-chip svg{ opacity:.85 }
a.pm-chip{ text-decoration:none; transition:background .25s,border-color .25s; }
a.pm-chip:hover{ background:rgba(255,255,255,.18); border-color:var(--gold2,#E6C877); color:#fff; }

/* kartu profil yang menumpuk di atas banner */
.pm-hero{ position:relative; margin-top:-110px; display:grid; grid-template-columns:auto 1fr minmax(260px,340px); gap:30px; align-items:center;
  background:#fff; border-radius:26px; padding:28px 32px; border:1px solid rgba(255,255,255,.6); box-shadow:0 24px 60px rgba(8,30,48,.18), 0 2px 6px rgba(8,30,48,.06); }
.pm-hero:before{ content:""; position:absolute; left:32px; right:32px; top:0; height:4px; border-radius:0 0 6px 6px; background:linear-gradient(90deg,var(--gold),#E6C877,var(--gold)); }
.pm-photo{ width:120px; aspect-ratio:3/4; border-radius:20px; padding:3px; background:linear-gradient(135deg,#E6C877,var(--gold)); box-shadow:0 10px 24px rgba(201,162,75,.35); }
.pm-photo>*{ width:100%; height:100%; border-radius:17px; border:3px solid #fff; object-fit:cover; object-position:center top; display:flex; align-items:center; justify-content:center; background:var(--navy); color:#E6C877; font:700 42px 'Playfair Display',serif; }
.pm-hi{ font-size:12.5px; font-weight:600; letter-spacing:.12em; text-transform:uppercase; color:var(--gold-dark); }
.pm-name{ font:700 clamp(24px,3vw,32px)/1.2 'Playfair Display',serif; color:var(--navy); margin:4px 0 12px; }
.pm-meta{ display:flex; flex-wrap:wrap; gap:8px; }
.pm-tag{ display:inline-flex; align-items:center; gap:7px; padding:6px 12px; border-radius:99px; font-size:12.5px; font-weight:600; background:var(--bg); border:1px solid var(--border); color:var(--text-soft); font-variant-numeric:tabular-nums; }
.pm-tag.role{ background:var(--gold-tint); border-color:#EBD9A8; color:#8A6514; }
.pm-tag svg{ color:var(--text-muted) }
.pm-today{ display:grid; gap:14px; padding-left:30px; border-left:1px solid var(--border); }
.pm-today h4{ margin:0; font:600 11.5px Inter,sans-serif; letter-spacing:.12em; text-transform:uppercase; color:var(--text-muted); }
.pm-bar{ height:8px; border-radius:99px; background:#E5EBF1; overflow:hidden; margin-top:7px; }
.pm-bar i{ display:block; height:100%; border-radius:99px; background:linear-gradient(90deg,#1C8C4C,#34B36B); width:0; transition:width 1.1s var(--ease) .3s; }
.pm-bar i.gold{ background:linear-gradient(90deg,#C98A0E,#E6C877); }
.pm-bar i.blue{ background:linear-gradient(90deg,#2672A3,#4C9AD0); }
.pm-row{ display:flex; align-items:baseline; justify-content:space-between; gap:10px; font-size:13px; color:var(--text-soft); font-weight:500; }
.pm-row b{ font:700 20px 'Playfair Display',serif; color:var(--navy); font-variant-numeric:tabular-nums; }
.pm-row small{ font:500 12px Inter,sans-serif; color:var(--text-muted); }

/* judul bagian */
.pm-sec{ display:flex; align-items:flex-end; justify-content:space-between; gap:12px; margin:44px 0 18px; }
.pm-sec h2{ margin:0; font:700 22px 'Playfair Display',serif; color:var(--navy); }
.pm-sec p{ margin:4px 0 0; font-size:13.5px; color:var(--text-muted); }
.pm-sec:after{ content:""; flex:1; height:1px; margin:0 0 9px 18px; background:linear-gradient(90deg,var(--border),transparent); order:2; }
.pm-sec>div{ order:1; }

/* kartu modul */
.pm-grid{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:22px; }
.pm-card{ --c1:#0B3C5D; --c2:#2E7AAE; --tint:#EAF1F6;
  position:relative; display:flex; flex-direction:column; text-decoration:none; color:inherit; padding:26px 26px 22px; border-radius:22px; background:#fff;
  border:1px solid var(--border); box-shadow:0 2px 10px rgba(11,60,93,.05); overflow:hidden; isolation:isolate;
  transition:transform .35s var(--ease), box-shadow .35s var(--ease), border-color .35s; }
.pm-card:before{ content:""; position:absolute; z-index:-1; right:-70px; top:-70px; width:210px; height:210px; border-radius:50%; background:radial-gradient(circle,var(--tint),transparent 70%); transition:transform .5s var(--ease); }
.pm-card:hover{ transform:translateY(-6px); border-color:var(--c2); box-shadow:0 24px 48px rgba(11,60,93,.15); text-decoration:none; }
.pm-card:hover:before{ transform:scale(1.35); }
.pm-card:focus-visible{ outline:3px solid var(--gold); outline-offset:3px; }
.pm-card.navy { --c1:#0B3C5D; --c2:#2E7AAE; --tint:#E3EEF6; }
.pm-card.green{ --c1:#157A40; --c2:#34B36B; --tint:#E3F5EA; }
.pm-card.gold { --c1:#A9832F; --c2:#E0B84F; --tint:#FBF1D8; }
.pm-card.blue { --c1:#205E85; --c2:#4C9AD0; --tint:#E3F0FA; }
.pm-head{ display:flex; align-items:center; justify-content:space-between; margin-bottom:18px; }
.pm-ic{ width:58px; height:58px; border-radius:17px; display:grid; place-items:center; color:#fff; background:linear-gradient(140deg,var(--c1),var(--c2)); box-shadow:0 10px 22px -6px var(--c1); }
.pm-go{ width:38px; height:38px; border-radius:50%; display:grid; place-items:center; color:var(--c1); background:var(--tint); transition:transform .35s var(--ease), background .3s, color .3s; }
.pm-card:hover .pm-go{ background:var(--c1); color:#fff; transform:translateX(4px); }
.pm-card h3{ margin:0 0 8px; font:700 20px 'Playfair Display',serif; color:var(--navy); }
.pm-card p{ margin:0; font-size:13.5px; line-height:1.65; color:var(--text-muted); flex:1; }
.pm-stat{ margin-top:20px; padding-top:16px; border-top:1px dashed var(--border); }
.pm-stat .big{ font:700 26px 'Playfair Display',serif; color:var(--navy); font-variant-numeric:tabular-nums; line-height:1.1; }
.pm-stat .big.neg{ color:var(--alpa); }
.pm-stat .lbl{ font-size:11.5px; font-weight:600; letter-spacing:.08em; text-transform:uppercase; color:var(--text-muted); margin-bottom:4px; }
.pm-stat .sub{ font-size:12.5px; color:var(--text-muted); margin-top:6px; font-variant-numeric:tabular-nums; }
.pm-stat .sub .up{ color:var(--hadir); font-weight:600 } .pm-stat .sub .dn{ color:var(--alpa); font-weight:600 }
.pm-trio{ display:grid; grid-template-columns:repeat(3,1fr); gap:10px; }
.pm-trio div{ text-align:center; padding:10px 6px; border-radius:12px; background:var(--bg); }
.pm-trio b{ display:block; font:700 20px 'Playfair Display',serif; color:var(--navy); font-variant-numeric:tabular-nums; }
.pm-trio span{ font-size:11px; color:var(--text-muted); font-weight:600; }
.pm-duo{ display:grid; gap:12px; }

.pm-foot{ display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-top:40px; padding-top:22px; border-top:1px solid var(--border); font-size:12.5px; color:var(--text-muted); }
.pm-out{ display:inline-flex; align-items:center; gap:8px; padding:9px 16px; border-radius:99px; font-weight:600; color:var(--alpa-soft-fg); background:#fff; border:1px solid var(--border); text-decoration:none; transition:all .25s; }
.pm-out:hover{ background:var(--alpa-soft-bg); border-color:#F0C4C4; text-decoration:none; }

/* animasi masuk (aman: tanpa JS tetap tampil) */
.js .pm-in{ opacity:0; transform:translateY(22px); transition:opacity .7s var(--ease), transform .7s var(--ease); transition-delay:var(--d,0ms); }
.js .pm-in.on{ opacity:1; transform:none; }
.js .pm-card.pm-in.on:hover{ transform:translateY(-6px); transition-delay:0ms; }

@media (max-width:980px){
  .pm-hero{ grid-template-columns:auto 1fr; }
  .pm-today{ grid-column:1 / -1; padding:20px 0 0; border-left:0; border-top:1px solid var(--border); grid-template-columns:1fr 1fr; }
  .pm-today h4{ grid-column:1 / -1; }
}
@media (max-width:720px){
  .pm-grid{ grid-template-columns:1fr; }
  .pm-top{ padding-bottom:130px; }
  .pm-hero{ padding:22px 20px; gap:18px; grid-template-columns:1fr; justify-items:center; text-align:center; }
  .pm-meta{ justify-content:center; }
  .pm-today{ grid-template-columns:1fr; width:100%; text-align:left; }
  .pm-tools .pm-chip.hide-sm{ display:none; }
}
@media (prefers-reduced-motion:reduce){ .js .pm-in{ opacity:1; transform:none; transition:none; } .pm-bar i{ transition:none; } .pm-card,.pm-go{ transition:none; } }
</style>
</head>
<body>
<script>document.documentElement.classList.add('js')</script>
<div class="pm">
  <header class="pm-top">
    <div class="pm-wrap pm-nav">
      <div class="pm-brand">
        <?php if ($logo_url): ?><img src="<?php echo $logo_url; ?>" alt="Logo <?php echo bersihkan($nama_sekolah); ?>"><?php endif; ?>
        <div><b><?php echo bersihkan($nama_sekolah); ?></b><span>Sistem Informasi Manajemen Sekolah</span></div>
      </div>
      <div class="pm-tools">
        <span class="pm-chip hide-sm"><?php echo ikon('calendar', 15); ?> <?php echo $hari . ', ' . format_tanggal_indo($tgl); ?></span>
        <span class="pm-chip"><?php echo ikon('clock', 15); ?> <span id="pmClock">--:--:--</span></span>
        <span data-nt-slot="dark" style="display:inline-flex"></span>
        <a class="pm-chip" href="<?php echo BASE_URL; ?>index.php" target="_blank" rel="noopener"><?php echo ikon('globe', 15); ?> Beranda Publik</a>
      </div>
    </div>
  </header>

  <main class="pm-wrap">
    <section class="pm-hero pm-in">
      <div class="pm-photo">
        <?php if ($foto_potret): ?><img src="<?php echo bersihkan($foto_potret); ?>" alt="Foto <?php echo bersihkan($pf['nama']); ?>">
        <?php elseif (!empty($pf['foto_url'])): ?><img src="<?php echo bersihkan($pf['foto_url']); ?>" alt="Foto <?php echo bersihkan($pf['nama']); ?>">
        <?php else: ?><span><?php echo bersihkan($inisial); ?></span><?php endif; ?>
      </div>
      <div>
        <div class="pm-hi"><?php echo salam_waktu(); ?>, selamat datang kembali</div>
        <h1 class="pm-name"><?php echo bersihkan($pf['nama']); ?></h1>
        <div class="pm-meta">
          <span class="pm-tag role"><?php echo ikon('key', 14); ?> <?php echo bersihkan($pf['peran']); ?></span>
          <span class="pm-tag"><?php echo ikon('clipboard', 14); ?> <?php echo bersihkan($pf['label_nomor']); ?>: <?php echo $pf['nomor'] !== '' ? bersihkan($pf['nomor']) : 'belum diisi'; ?></span>
          <span class="pm-tag"><?php echo ikon('calendar', 14); ?> <?php echo bersihkan($tahun_ta); ?></span>
        </div>
      </div>
      <div class="pm-today">
        <h4>Kehadiran hari ini</h4>
        <div>
          <div class="pm-row"><span>Siswa</span><span><b><?php echo $hadir_siswa; ?></b> <small>/ <?php echo $jml_siswa; ?> &middot; <?php echo $pct_siswa; ?>%</small></span></div>
          <div class="pm-bar"><i data-w="<?php echo $pct_siswa; ?>"></i></div>
        </div>
        <div>
          <div class="pm-row"><span>Guru &amp; staf</span><span><b><?php echo $hadir_pegawai; ?></b> <small>/ <?php echo $jml_pegawai; ?> &middot; <?php echo $pct_pegawai; ?>%</small></span></div>
          <div class="pm-bar"><i class="gold" data-w="<?php echo $pct_pegawai; ?>"></i></div>
        </div>
      </div>
    </section>

    <div class="pm-sec pm-in" style="--d:80ms"><div><h2>Menu Utama</h2><p>Pilih modul yang ingin Anda kelola.</p></div></div>

    <nav class="pm-grid" aria-label="Menu modul">
      <?php foreach ($menu as $i => $m): ?>
      <a class="pm-card <?php echo $m['warna']; ?> pm-in" style="--d:<?php echo 120 + $i * 90; ?>ms" href="<?php echo BASE_URL . $m['href']; ?>">
        <div class="pm-head">
          <span class="pm-ic"><?php echo ikon($m['ikon'], 28); ?></span>
          <span class="pm-go" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>
        </div>
        <h3><?php echo $m['judul']; ?></h3>
        <p><?php echo $m['desk']; ?></p>

        <div class="pm-stat">
        <?php if ($m['warna'] === 'navy'): ?>
          <div class="pm-trio">
            <div><b><?php echo $jml_siswa; ?></b><span>Siswa aktif</span></div>
            <div><b><?php echo $jml_pegawai; ?></b><span>Guru &amp; staf</span></div>
            <div><b><?php echo $jml_kelas; ?></b><span>Kelas</span></div>
          </div>
        <?php elseif ($m['warna'] === 'green'): ?>
          <div class="pm-duo">
            <div><div class="pm-row"><span>Siswa hadir</span><span><b style="font-size:17px"><?php echo $hadir_siswa; ?></b> <small>/ <?php echo $jml_siswa; ?></small></span></div><div class="pm-bar"><i data-w="<?php echo $pct_siswa; ?>"></i></div></div>
            <div><div class="pm-row"><span>Guru &amp; staf hadir</span><span><b style="font-size:17px"><?php echo $hadir_pegawai; ?></b> <small>/ <?php echo $jml_pegawai; ?></small></span></div><div class="pm-bar"><i data-w="<?php echo $pct_pegawai; ?>"></i></div></div>
          </div>
        <?php elseif ($m['warna'] === 'gold'): ?>
          <div class="lbl">Saldo kas saat ini</div>
          <div class="big <?php echo $saldo_kas < 0 ? 'neg' : ''; ?>"><?php echo rupiah($saldo_kas); ?></div>
          <div class="sub">Bulan ini: <span class="up">+<?php echo rupiah($masuk_bln); ?></span> &nbsp;·&nbsp; <span class="dn">&minus;<?php echo rupiah($keluar_bln); ?></span></div>
        <?php else: ?>
          <div class="pm-row"><span>Progres input nilai <?php echo bersihkan($ta_aktif['tahun'] ?? ''); ?></span><span><b style="font-size:17px"><?php echo $pct_rapor; ?>%</b></span></div>
          <div class="pm-bar"><i class="blue" data-w="<?php echo $pct_rapor; ?>"></i></div>
          <div class="sub"><?php echo (int)$sudah_nilai; ?> dari <?php echo (int)$target_nilai; ?> nilai sudah diinput</div>
        <?php endif; ?>
        </div>
      </a>
      <?php endforeach; ?>
    </nav>

    <footer class="pm-foot">
      <span>&copy; <?php echo date('Y'); ?> <?php echo bersihkan($nama_sekolah); ?> &middot; Yayasan Pendidikan Kristen (YPK) di Tanah Papua</span>
      <a href="<?php echo BASE_URL; ?>logout.php" class="pm-out"><?php echo ikon('exit', 16); ?> Keluar dari sistem</a>
    </footer>
  </main>
</div>
<script src="<?php echo aset('assets/js/lightbox.js'); ?>"></script>
<script>
(function(){
  /* jam langsung */
  var c=document.getElementById('pmClock');
  function tick(){var d=new Date(),p=function(n){return(n<10?'0':'')+n};c.textContent=p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds())}
  tick();setInterval(tick,1000);
  /* animasi masuk + batang progres */
  var els=[].slice.call(document.querySelectorAll('.pm-in')),bars=[].slice.call(document.querySelectorAll('.pm-bar i'));
  function fill(){bars.forEach(function(b){b.style.width=(b.getAttribute('data-w')||0)+'%'})}
  if(!('IntersectionObserver' in window)){els.forEach(function(e){e.classList.add('on')});fill();return}
  var io=new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting){x.target.classList.add('on');io.unobserve(x.target)}})},{threshold:.1});
  els.forEach(function(e){io.observe(e)});
  setTimeout(fill,250);
})();
</script>
</body>
</html>
