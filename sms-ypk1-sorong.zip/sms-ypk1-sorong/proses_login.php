<?php
require_once __DIR__ . '/config/session.php';

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    header('Location: ' . BASE_URL . 'login.php?error=1');
    exit;
}

$stmt = mysqli_prepare($conn, "SELECT u.id, u.username, u.password, u.role, u.status_aktif, u.pegawai_id,
                                       p.nama AS nama_pegawai
                                FROM users u LEFT JOIN pegawai p ON p.id = u.pegawai_id
                                WHERE u.username = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 's', $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if (!$user || !password_verify($password, $user['password'])) {
    header('Location: ' . BASE_URL . 'login.php?error=1');
    exit;
}
if ((int)$user['status_aktif'] !== 1) {
    header('Location: ' . BASE_URL . 'login.php?error=2');
    exit;
}

$_SESSION['user_id']    = $user['id'];
$_SESSION['username']   = $user['username'];
$_SESSION['role']       = $user['role'];
$_SESSION['pegawai_id'] = $user['pegawai_id'];
$_SESSION['nama']       = $user['nama_pegawai'] ?: $user['username'];

// jika guru, ambil kelas yang diwalikan
if ($user['role'] === 'guru') {
    $res = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas WHERE wali_kelas_id = " . (int)$user['pegawai_id'] . " LIMIT 1");
    $kelas = mysqli_fetch_assoc($res);
    $_SESSION['kelas_id']   = $kelas['id'] ?? null;
    $_SESSION['nama_kelas'] = $kelas['nama_kelas'] ?? null;
}

mysqli_query($conn, "UPDATE users SET last_login = NOW() WHERE id = " . (int)$user['id']);

header('Location: ' . BASE_URL . 'home.php');
exit;
