<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Mata Pelajaran';
$modul_aktif = 'erapor';
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode = bersihkan($_POST['kode']);
    $nama = bersihkan($_POST['nama_mapel']);
    $kelompok = bersihkan($_POST['kelompok']);
    $kkm = (int) $_POST['kkm'];
    $urutan = (int) $_POST['urutan'];

    if (!empty($_POST['id'])) {
        $id = (int) $_POST['id'];
        $stmt = mysqli_prepare($conn, "UPDATE mata_pelajaran SET kode=?, nama_mapel=?, kelompok=?, kkm=?, urutan=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, 'sssiii', $kode, $nama, $kelompok, $kkm, $urutan, $id);
        mysqli_stmt_execute($stmt);
        $pesan = 'Mata pelajaran berhasil diperbarui.';
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO mata_pelajaran (kode, nama_mapel, kelompok, kkm, urutan) VALUES (?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'sssii', $kode, $nama, $kelompok, $kkm, $urutan);
        mysqli_stmt_execute($stmt);
        $pesan = 'Mata pelajaran baru berhasil ditambahkan.';
    }
}

if (isset($_GET['toggle'])) {
    mysqli_query($conn, "UPDATE mata_pelajaran SET status_aktif = 1 - status_aktif WHERE id=" . (int)$_GET['toggle']);
    $pesan = 'Status mata pelajaran diperbarui.';
}
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    $dipakai = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM pengajaran WHERE mapel_id=$id"))['c'];
    if ($dipakai > 0) {
        $pesan = 'Mata pelajaran tidak dapat dihapus karena sudah dipakai pada penugasan guru. Nonaktifkan saja jika sudah tidak dipakai.';
    } else {
        mysqli_query($conn, "DELETE FROM mata_pelajaran WHERE id=$id");
        $pesan = 'Mata pelajaran berhasil dihapus.';
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM mata_pelajaran WHERE id=" . (int)$_GET['edit']));
}

$list = mysqli_query($conn, "SELECT * FROM mata_pelajaran ORDER BY urutan, nama_mapel");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Mata Pelajaran</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3><?php echo $edit ? 'Edit Mata Pelajaran' : 'Tambah Mata Pelajaran Baru'; ?></h3>
      <form method="POST" class="grid grid-4" style="align-items:end;">
        <input type="hidden" name="id" value="<?php echo $edit['id'] ?? ''; ?>">
        <div class="form-group mb-0"><label>Kode</label><input type="text" name="kode" class="form-control" value="<?php echo bersihkan($edit['kode'] ?? ''); ?>" placeholder="contoh: MTK"></div>
        <div class="form-group mb-0"><label>Nama Mata Pelajaran</label><input type="text" name="nama_mapel" class="form-control" required value="<?php echo bersihkan($edit['nama_mapel'] ?? ''); ?>"></div>
        <div class="form-group mb-0">
          <label>Kelompok</label>
          <select name="kelompok" class="form-control">
            <?php foreach (['Umum','Pilihan','Muatan Lokal'] as $kl): ?>
              <option value="<?php echo $kl; ?>" <?php echo (($edit['kelompok'] ?? 'Umum') === $kl) ? 'selected' : ''; ?>><?php echo $kl; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group mb-0"><label>KKM</label><input type="number" name="kkm" class="form-control" value="<?php echo $edit['kkm'] ?? 75; ?>" min="0" max="100"></div>
        <div class="form-group mb-0"><label>Urutan Tampil</label><input type="number" name="urutan" class="form-control" value="<?php echo $edit['urutan'] ?? 0; ?>"></div>
        <div style="grid-column: 1 / -1;">
          <button type="submit" class="btn btn-primary"><?php echo $edit ? 'Simpan Perubahan' : '+ Tambah Mata Pelajaran'; ?></button>
          <?php if ($edit): ?><a href="mapel.php" class="btn btn-outline">Batal</a><?php endif; ?>
        </div>
      </form>
    </div>

    <div class="card">
      <h3>Daftar Mata Pelajaran</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Kode</th><th>Nama</th><th>Kelompok</th><th>KKM</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php while ($m = mysqli_fetch_assoc($list)): ?>
          <tr>
            <td><?php echo bersihkan($m['kode'] ?: '-'); ?></td>
            <td><strong><?php echo bersihkan($m['nama_mapel']); ?></strong></td>
            <td><span class="pill"><?php echo bersihkan($m['kelompok']); ?></span></td>
            <td><?php echo (int)$m['kkm']; ?></td>
            <td><?php echo $m['status_aktif'] ? '<span class="pill">Aktif</span>' : '<span class="pill" style="background:#fdecea;color:#b3261e;">Nonaktif</span>'; ?></td>
            <td>
              <a class="btn btn-outline btn-sm" href="?edit=<?php echo $m['id']; ?>">Edit</a>
              <a class="btn btn-outline btn-sm" href="?toggle=<?php echo $m['id']; ?>"><?php echo $m['status_aktif'] ? 'Nonaktifkan' : 'Aktifkan'; ?></a>
              <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $m['id']; ?>" onclick="return confirm('Hapus mata pelajaran ini?');">Hapus</a>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
