<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'guru']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Sikap & Catatan Wali Kelas';
$modul_aktif = 'erapor';
$role = $_SESSION['role'];
$pesan = '';
$ta_aktif = tahun_ajaran_aktif($conn);

if ($role === 'guru' && !is_wali_kelas()) {
    include __DIR__ . '/../includes/header.php';
    include __DIR__ . '/../includes/sidebar.php';
    echo '<main class="main-content"><div class="topbar"><h2>Sikap & Catatan Wali Kelas</h2></div><div class="content">
          <div class="alert alert-error">Menu ini khusus untuk wali kelas. Akun Anda belum ditetapkan sebagai wali kelas manapun.</div>
          </div></main>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}
if (!$ta_aktif) {
    include __DIR__ . '/../includes/header.php';
    include __DIR__ . '/../includes/sidebar.php';
    echo '<main class="main-content"><div class="topbar"><h2>Sikap & Catatan Wali Kelas</h2></div><div class="content">
          <div class="alert alert-error">Belum ada Tahun Ajaran aktif. Aktifkan dahulu di menu <a href="' . BASE_URL . 'manajemen/tahun_ajaran.php">Manajemen &gt; Tahun Ajaran</a>.</div>
          </div></main>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}
$ta_id = (int) $ta_aktif['id'];

// --- tentukan kelas yang boleh diakses ---
if ($role === 'guru') {
    $kelas_id = (int) $_SESSION['kelas_id'];
} else {
    $daftar_kelas = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas");
    $kelas_id = (int) ($_POST['kelas_id'] ?? $_GET['kelas_id'] ?? 0);
}

// --- simpan (batch) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan_sikap' && $kelas_id) {
    $stmt = mysqli_prepare($conn, "INSERT INTO nilai_sikap (siswa_id, tahun_ajaran_id, spiritual, sosial, ekstrakurikuler, catatan_wali, diinput_oleh)
                                    VALUES (?,?,?,?,?,?,?)
                                    ON DUPLICATE KEY UPDATE spiritual=VALUES(spiritual), sosial=VALUES(sosial), ekstrakurikuler=VALUES(ekstrakurikuler),
                                    catatan_wali=VALUES(catatan_wali), diinput_oleh=VALUES(diinput_oleh)");
    foreach (($_POST['siswa'] ?? []) as $siswa_id => $f) {
        $siswa_id = (int) $siswa_id;
        $spiritual = in_array($f['spiritual'], ['Sangat Baik','Baik','Cukup','Perlu Bimbingan'], true) ? $f['spiritual'] : 'Baik';
        $sosial    = in_array($f['sosial'], ['Sangat Baik','Baik','Cukup','Perlu Bimbingan'], true) ? $f['sosial'] : 'Baik';
        $ekskul    = bersihkan($f['ekstrakurikuler'] ?? '');
        $catatan   = bersihkan($f['catatan'] ?? '');
        mysqli_stmt_bind_param($stmt, 'iissssi', $siswa_id, $ta_id, $spiritual, $sosial, $ekskul, $catatan, $_SESSION['user_id']);
        mysqli_stmt_execute($stmt);
    }
    $pesan = 'Data sikap & catatan wali kelas berhasil disimpan.';
}

$nama_kelas_aktif = '';
$siswa_rows = [];
if ($kelas_id) {
    $kl = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama_kelas FROM kelas WHERE id=$kelas_id"));
    $nama_kelas_aktif = $kl['nama_kelas'] ?? '';
    $res = mysqli_query($conn, "SELECT s.id, s.nama, ns.spiritual, ns.sosial, ns.ekstrakurikuler, ns.catatan_wali
                                 FROM siswa s
                                 LEFT JOIN nilai_sikap ns ON ns.siswa_id=s.id AND ns.tahun_ajaran_id=$ta_id
                                 WHERE s.kelas_id=$kelas_id AND s.status='Aktif'
                                 ORDER BY s.nama");
    while ($r = mysqli_fetch_assoc($res)) $siswa_rows[] = $r;
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
$opsi_sikap = ['Sangat Baik','Baik','Cukup','Perlu Bimbingan'];
?>
<main class="main-content">
  <div class="topbar"><h2>Sikap &amp; Catatan Wali Kelas</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <?php if ($role === 'kepala_sekolah'): ?>
    <div class="card">
      <form method="GET" class="grid grid-3" style="align-items:end;">
        <div class="form-group mb-0">
          <label>Pilih Kelas</label>
          <select name="kelas_id" class="form-control" onchange="this.form.submit()">
            <option value="">— Pilih Kelas —</option>
            <?php mysqli_data_seek($daftar_kelas, 0); while ($k = mysqli_fetch_assoc($daftar_kelas)): ?>
              <option value="<?php echo $k['id']; ?>" <?php echo $k['id']==$kelas_id ? 'selected' : ''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
      </form>
    </div>
    <?php endif; ?>

    <?php if ($kelas_id && !empty($siswa_rows)): ?>
    <div class="card">
      <h3>Kelas <?php echo bersihkan($nama_kelas_aktif); ?> — <?php echo bersihkan($ta_aktif['tahun']); ?> (<?php echo bersihkan($ta_aktif['semester']); ?>)</h3>
      <form method="POST">
        <input type="hidden" name="aksi" value="simpan_sikap">
        <input type="hidden" name="kelas_id" value="<?php echo $kelas_id; ?>">
        <?php foreach ($siswa_rows as $s): ?>
          <div class="card" style="background:#FAFBFC; box-shadow:none; border:1px solid var(--border); margin-bottom:14px;">
            <div style="font-weight:700; color:var(--navy); margin-bottom:10px;"><?php echo bersihkan($s['nama']); ?></div>
            <div class="grid grid-3">
              <div class="form-group mb-0">
                <label>Sikap Spiritual</label>
                <select name="siswa[<?php echo $s['id']; ?>][spiritual]" class="form-control">
                  <?php foreach ($opsi_sikap as $op): ?><option value="<?php echo $op; ?>" <?php echo ($s['spiritual'] ?? 'Baik')===$op ? 'selected' : ''; ?>><?php echo $op; ?></option><?php endforeach; ?>
                </select>
              </div>
              <div class="form-group mb-0">
                <label>Sikap Sosial</label>
                <select name="siswa[<?php echo $s['id']; ?>][sosial]" class="form-control">
                  <?php foreach ($opsi_sikap as $op): ?><option value="<?php echo $op; ?>" <?php echo ($s['sosial'] ?? 'Baik')===$op ? 'selected' : ''; ?>><?php echo $op; ?></option><?php endforeach; ?>
                </select>
              </div>
              <div class="form-group mb-0">
                <label>Ekstrakurikuler</label>
                <input type="text" class="form-control" name="siswa[<?php echo $s['id']; ?>][ekstrakurikuler]" value="<?php echo bersihkan($s['ekstrakurikuler'] ?? ''); ?>" placeholder="contoh: Pramuka, Paduan Suara">
              </div>
            </div>
            <div class="form-group" style="margin-top:10px; margin-bottom:0;">
              <label>Catatan Wali Kelas</label>
              <textarea class="form-control" name="siswa[<?php echo $s['id']; ?>][catatan]" rows="2" placeholder="Catatan perkembangan siswa selama semester ini..."><?php echo bersihkan($s['catatan_wali'] ?? ''); ?></textarea>
            </div>
          </div>
        <?php endforeach; ?>
        <button type="submit" class="btn btn-primary">💾 Simpan Semua</button>
      </form>
    </div>
    <?php elseif ($kelas_id): ?>
      <div class="card"><p class="muted">Belum ada siswa aktif di kelas ini.</p></div>
    <?php endif; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
