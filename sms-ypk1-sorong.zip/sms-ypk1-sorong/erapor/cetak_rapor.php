<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'guru']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Cetak Rapor';
$modul_aktif = 'erapor';
$role = $_SESSION['role'];

if ($role === 'guru' && !is_wali_kelas()) {
    include __DIR__ . '/../includes/header.php';
    include __DIR__ . '/../includes/sidebar.php';
    echo '<main class="main-content"><div class="topbar"><h2>Cetak Rapor</h2></div><div class="content">
          <div class="alert alert-error">Menu ini khusus untuk wali kelas. Akun Anda belum ditetapkan sebagai wali kelas manapun.</div>
          </div></main>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}

$ta_aktif = tahun_ajaran_aktif($conn);
if (!$ta_aktif) {
    include __DIR__ . '/../includes/header.php';
    include __DIR__ . '/../includes/sidebar.php';
    echo '<main class="main-content"><div class="topbar"><h2>Cetak Rapor</h2></div><div class="content">
          <div class="alert alert-error">Belum ada Tahun Ajaran aktif.</div>
          </div></main>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}
$ta_id = (int) $ta_aktif['id'];

$kelas_id = $role === 'guru' ? (int) $_SESSION['kelas_id'] : (int) ($_GET['kelas_id'] ?? 0);
$siswa_id = (int) ($_GET['siswa_id'] ?? 0);

$daftar_kelas = $role === 'kepala_sekolah' ? mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas") : null;
$daftar_siswa = $kelas_id ? mysqli_query($conn, "SELECT id, nama FROM siswa WHERE kelas_id=$kelas_id AND status='Aktif' ORDER BY nama") : null;

$siswa = null; $nilai_list = []; $sikap = null; $rekap_absen = ['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0];
if ($siswa_id) {
    $siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT s.*, k.nama_kelas, k.tingkat, k.wali_kelas_id
                                                       FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id WHERE s.id=$siswa_id"));
    if ($siswa) {
        $res = mysqli_query($conn, "SELECT m.nama_mapel, m.kelompok, m.kkm, n.nilai_akhir, n.predikat, n.deskripsi
                                     FROM mata_pelajaran m
                                     LEFT JOIN nilai_akademik n ON n.mapel_id=m.id AND n.siswa_id=$siswa_id AND n.tahun_ajaran_id=$ta_id
                                     JOIN pengajaran p ON p.mapel_id=m.id AND p.kelas_id=" . (int)$siswa['kelas_id'] . " AND p.tahun_ajaran_id=$ta_id
                                     WHERE m.status_aktif=1 ORDER BY m.urutan, m.nama_mapel");
        while ($r = mysqli_fetch_assoc($res)) $nilai_list[] = $r;

        $sikap = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM nilai_sikap WHERE siswa_id=$siswa_id AND tahun_ajaran_id=$ta_id"));

        $mulai = $ta_aktif['tanggal_mulai'] ?: date('Y-01-01');
        $selesai = $ta_aktif['tanggal_selesai'] ?: date('Y-m-d');
        $res_absen = mysqli_query($conn, "SELECT status, COUNT(*) c FROM absensi_siswa WHERE siswa_id=$siswa_id AND tanggal BETWEEN '$mulai' AND '$selesai' GROUP BY status");
        while ($a = mysqli_fetch_assoc($res_absen)) {
            if (isset($rekap_absen[$a['status']])) $rekap_absen[$a['status']] = (int) $a['c'];
            elseif ($a['status'] === 'Terlambat') $rekap_absen['Hadir'] += (int) $a['c'];
        }
    }
}

$nama_kepsek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM pegawai WHERE jenis='Kepala Sekolah' AND status_aktif=1 LIMIT 1"))['nama'] ?? '(.....................)';
$nama_wali = $siswa && $siswa['wali_kelas_id'] ? (mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM pegawai WHERE id=" . (int)$siswa['wali_kelas_id']))['nama'] ?? '(.....................)') : '(.....................)';
$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$logo_url = url_logo_sekolah($conn);
$npsn = get_setting($conn, 'npsn') ?: '60403645';

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar no-print"><h2>Cetak Rapor Siswa</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">

    <div class="card no-print">
      <form method="GET" class="grid grid-3" style="align-items:end;">
        <?php if ($role === 'kepala_sekolah'): ?>
        <div class="form-group mb-0">
          <label>Kelas</label>
          <select name="kelas_id" class="form-control" onchange="this.form.submit()">
            <option value="">— Pilih Kelas —</option>
            <?php mysqli_data_seek($daftar_kelas, 0); while ($k = mysqli_fetch_assoc($daftar_kelas)): ?>
              <option value="<?php echo $k['id']; ?>" <?php echo $k['id']==$kelas_id ? 'selected' : ''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <?php endif; ?>
        <div class="form-group mb-0">
          <label>Siswa</label>
          <select name="siswa_id" class="form-control" required>
            <option value="">— Pilih Siswa —</option>
            <?php if ($daftar_siswa): mysqli_data_seek($daftar_siswa, 0); while ($s = mysqli_fetch_assoc($daftar_siswa)): ?>
              <option value="<?php echo $s['id']; ?>" <?php echo $s['id']==$siswa_id ? 'selected' : ''; ?>><?php echo bersihkan($s['nama']); ?></option>
            <?php endwhile; endif; ?>
          </select>
        </div>
        <div>
          <button type="submit" class="btn btn-outline">Tampilkan</button>
          <?php if ($siswa_id): ?><button type="button" class="btn btn-primary" onclick="window.print()">🖨️ Cetak / Simpan PDF</button><?php endif; ?>
        </div>
      </form>
    </div>

    <?php if ($siswa): ?>
    <div class="card" id="lembarRapor" style="max-width:820px; margin:0 auto;">
      <div style="text-align:center; border-bottom:2px solid var(--navy); padding-bottom:14px; margin-bottom:18px;">
        <?php if ($logo_url): ?><img src="<?php echo $logo_url; ?>" style="width:52px; height:52px; object-fit:contain; margin-bottom:6px;"><?php endif; ?>
        <div style="font-weight:800; color:var(--navy); font-size:16px;"><?php echo bersihkan($nama_sekolah); ?></div>
        <div style="font-size:12px; color:var(--text-muted);">NPSN <?php echo bersihkan($npsn); ?></div>
        <div style="font-size:14px; font-weight:700; margin-top:6px;">LAPORAN HASIL BELAJAR (RAPOR) SISWA</div>
        <div style="font-size:12.5px; margin-top:2px;">Tahun Ajaran <?php echo bersihkan($ta_aktif['tahun']); ?> — Semester <?php echo bersihkan($ta_aktif['semester']); ?></div>
      </div>

      <div class="grid grid-2" style="margin-bottom:18px; font-size:13.5px;">
        <div><b>Nama Siswa</b><br><?php echo bersihkan($siswa['nama']); ?></div>
        <div><b>Kelas</b><br><?php echo bersihkan($siswa['nama_kelas'] ?: '-'); ?></div>
        <div><b>NIS</b><br><?php echo bersihkan($siswa['nis'] ?: '-'); ?></div>
        <div><b>NISN</b><br><?php echo bersihkan($siswa['nisn'] ?: '-'); ?></div>
      </div>

      <h3 style="margin-bottom:8px;">A. Nilai Akademik</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Mata Pelajaran</th><th>KKM</th><th>Nilai Akhir</th><th>Predikat</th><th>Deskripsi Capaian Kompetensi</th></tr></thead>
        <tbody>
        <?php if (empty($nilai_list)): ?><tr><td colspan="5" class="muted">Belum ada nilai untuk siswa ini pada semester berjalan.</td></tr><?php endif; ?>
        <?php foreach ($nilai_list as $n): ?>
          <tr>
            <td><?php echo bersihkan($n['nama_mapel']); ?></td>
            <td><?php echo (int)$n['kkm']; ?></td>
            <td style="font-weight:700;"><?php echo $n['nilai_akhir'] !== null ? (float)$n['nilai_akhir'] : '-'; ?></td>
            <td><?php echo bersihkan($n['predikat'] ?: '-'); ?></td>
            <td><?php echo bersihkan($n['deskripsi'] ?: '-'); ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>

      <h3 style="margin:20px 0 8px;">B. Sikap</h3>
      <div class="grid grid-2" style="font-size:13.5px; margin-bottom:8px;">
        <div><b>Spiritual:</b> <?php echo bersihkan($sikap['spiritual'] ?? 'Belum diisi'); ?></div>
        <div><b>Sosial:</b> <?php echo bersihkan($sikap['sosial'] ?? 'Belum diisi'); ?></div>
      </div>
      <div style="font-size:13.5px; margin-bottom:8px;"><b>Ekstrakurikuler:</b> <?php echo bersihkan($sikap['ekstrakurikuler'] ?? '-'); ?></div>
      <div style="font-size:13.5px; margin-bottom:18px;"><b>Catatan Wali Kelas:</b><br><?php echo nl2br(bersihkan($sikap['catatan_wali'] ?? 'Belum ada catatan.')); ?></div>

      <h3 style="margin:0 0 8px;">C. Ketidakhadiran (selama semester berjalan)</h3>
      <div class="grid grid-4" style="margin-bottom:22px;">
        <div class="stat-card green"><div class="label">Hadir</div><div class="value" style="font-size:20px;"><?php echo $rekap_absen['Hadir']; ?></div></div>
        <div class="stat-card gold"><div class="label">Sakit</div><div class="value" style="font-size:20px;"><?php echo $rekap_absen['Sakit']; ?></div></div>
        <div class="stat-card blue"><div class="label">Izin</div><div class="value" style="font-size:20px;"><?php echo $rekap_absen['Izin']; ?></div></div>
        <div class="stat-card red"><div class="label">Alpa</div><div class="value" style="font-size:20px;"><?php echo $rekap_absen['Alpa']; ?></div></div>
      </div>

      <div class="grid grid-2" style="margin-top:30px; text-align:center;">
        <div>
          <div>Wali Kelas,</div>
          <div style="height:70px;"></div>
          <div style="font-weight:700; text-decoration:underline;"><?php echo bersihkan($nama_wali); ?></div>
        </div>
        <div>
          <div><?php echo bersihkan(get_setting($conn,'alamat_sekolah') ?: 'Kota Sorong'); ?>, <?php echo format_tanggal_indo(date('Y-m-d')); ?><br>Kepala Sekolah,</div>
          <div style="height:52px;"></div>
          <div style="font-weight:700; text-decoration:underline;"><?php echo bersihkan($nama_kepsek); ?></div>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
<style>
@media print {
  *{ -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; color-adjust:exact !important; }
  .sidebar, .mobile-toggle, .no-print { display:none !important; }
  .main-content { margin:0 !important; width:100% !important; }
  body { background:#fff; }
  #lembarRapor { box-shadow:none; border:none; }
}
</style>
