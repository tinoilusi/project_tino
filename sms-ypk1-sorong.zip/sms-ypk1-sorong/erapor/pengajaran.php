<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Penugasan Guru Mapel';
$modul_aktif = 'erapor';
$pesan = '';
$ta_aktif = tahun_ajaran_aktif($conn);

if ($ta_aktif) {
    $ta_id = (int) $ta_aktif['id'];

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'tambah') {
        $kelas_id = (int) $_POST['kelas_id'];
        $mapel_id = (int) $_POST['mapel_id'];
        $pegawai_id = (int) $_POST['pegawai_id'];
        $stmt = mysqli_prepare($conn, "INSERT INTO pengajaran (tahun_ajaran_id, kelas_id, mapel_id, pegawai_id) VALUES (?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'iiii', $ta_id, $kelas_id, $mapel_id, $pegawai_id);
        if (mysqli_stmt_execute($stmt)) {
            $pesan = 'Penugasan berhasil disimpan.';
        } else {
            $pesan = 'Kombinasi kelas & mata pelajaran ini sudah memiliki guru pengampu pada tahun ajaran ini.';
        }
    }
    if (isset($_GET['ganti_guru']) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pegawai_id_baru'])) {
        mysqli_query($conn, "UPDATE pengajaran SET pegawai_id=" . (int)$_POST['pegawai_id_baru'] . " WHERE id=" . (int)$_GET['ganti_guru']);
        $pesan = 'Guru pengampu berhasil diganti.';
    }
    if (isset($_GET['hapus'])) {
        $id = (int) $_GET['hapus'];
        $dipakai = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM nilai_akademik n JOIN pengajaran p ON p.kelas_id=n.kelas_id AND p.mapel_id=n.mapel_id AND p.tahun_ajaran_id=n.tahun_ajaran_id WHERE p.id=$id"))['c'];
        if ($dipakai > 0) {
            $pesan = 'Penugasan ini tidak dapat dihapus karena sudah ada nilai yang diinput untuk kombinasi kelas & mapel tersebut.';
        } else {
            mysqli_query($conn, "DELETE FROM pengajaran WHERE id=$id");
            $pesan = 'Penugasan berhasil dihapus.';
        }
    }

    $daftar_kelas = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas");
    $daftar_mapel = mysqli_query($conn, "SELECT id, nama_mapel FROM mata_pelajaran WHERE status_aktif=1 ORDER BY urutan, nama_mapel");
    $daftar_guru = mysqli_query($conn, "SELECT id, nama FROM pegawai WHERE jenis='Guru' AND status_aktif=1 ORDER BY nama");

    $list = mysqli_query($conn, "SELECT p.id, kl.nama_kelas, m.nama_mapel, pg.nama AS nama_guru, kl.tingkat
                                  FROM pengajaran p
                                  JOIN kelas kl ON kl.id = p.kelas_id
                                  JOIN mata_pelajaran m ON m.id = p.mapel_id
                                  JOIN pegawai pg ON pg.id = p.pegawai_id
                                  WHERE p.tahun_ajaran_id = $ta_id
                                  ORDER BY kl.tingkat, kl.nama_kelas, m.nama_mapel");
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Penugasan Guru Mata Pelajaran</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <?php if (!$ta_aktif): ?>
      <div class="alert alert-error">Belum ada Tahun Ajaran aktif. Aktifkan dahulu di menu <a href="<?php echo BASE_URL; ?>manajemen/tahun_ajaran.php">Manajemen &gt; Tahun Ajaran</a>.</div>
    <?php else: ?>

    <div class="card">
      <h3>Tugaskan Guru Baru</h3>
      <p class="muted">Menentukan guru mana yang berhak mengisi nilai untuk kombinasi Kelas + Mata Pelajaran tertentu pada tahun ajaran <b><?php echo bersihkan($ta_aktif['tahun']); ?> — <?php echo bersihkan($ta_aktif['semester']); ?></b>.</p>
      <form method="POST" class="grid grid-4" style="align-items:end;">
        <input type="hidden" name="aksi" value="tambah">
        <div class="form-group mb-0">
          <label>Kelas</label>
          <select name="kelas_id" class="form-control" required>
            <option value="">— Pilih Kelas —</option>
            <?php mysqli_data_seek($daftar_kelas, 0); while ($k = mysqli_fetch_assoc($daftar_kelas)): ?>
              <option value="<?php echo $k['id']; ?>"><?php echo bersihkan($k['nama_kelas']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group mb-0">
          <label>Mata Pelajaran</label>
          <select name="mapel_id" class="form-control" required>
            <option value="">— Pilih Mapel —</option>
            <?php mysqli_data_seek($daftar_mapel, 0); while ($m = mysqli_fetch_assoc($daftar_mapel)): ?>
              <option value="<?php echo $m['id']; ?>"><?php echo bersihkan($m['nama_mapel']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group mb-0">
          <label>Guru Pengampu</label>
          <select name="pegawai_id" class="form-control" required>
            <option value="">— Pilih Guru —</option>
            <?php mysqli_data_seek($daftar_guru, 0); while ($g = mysqli_fetch_assoc($daftar_guru)): ?>
              <option value="<?php echo $g['id']; ?>"><?php echo bersihkan($g['nama']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">+ Tugaskan</button>
      </form>
    </div>

    <div class="card">
      <h3>Daftar Penugasan — <?php echo bersihkan($ta_aktif['tahun']); ?> (<?php echo bersihkan($ta_aktif['semester']); ?>)</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Kelas</th><th>Mata Pelajaran</th><th>Guru Pengampu</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php if (mysqli_num_rows($list) === 0): ?>
          <tr><td colspan="4" class="muted" style="text-align:center; padding:20px;">Belum ada penugasan pada tahun ajaran ini.</td></tr>
        <?php endif; ?>
        <?php while ($r = mysqli_fetch_assoc($list)): ?>
          <tr>
            <td><strong><?php echo bersihkan($r['nama_kelas']); ?></strong></td>
            <td><?php echo bersihkan($r['nama_mapel']); ?></td>
            <td><?php echo bersihkan($r['nama_guru']); ?></td>
            <td>
              <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('ganti-<?php echo $r['id']; ?>').style.display='flex'">Ganti Guru</button>
              <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $r['id']; ?>" onclick="return confirm('Hapus penugasan ini?');">Hapus</a>
              <form id="ganti-<?php echo $r['id']; ?>" method="POST" action="?ganti_guru=<?php echo $r['id']; ?>" style="display:none; gap:6px; margin-top:8px;">
                <select name="pegawai_id_baru" class="form-control" style="width:200px; display:inline-block;" required>
                  <option value="">— Pilih Guru Baru —</option>
                  <?php mysqli_data_seek($daftar_guru, 0); while ($g = mysqli_fetch_assoc($daftar_guru)): ?>
                    <option value="<?php echo $g['id']; ?>"><?php echo bersihkan($g['nama']); ?></option>
                  <?php endwhile; ?>
                </select>
                <button type="submit" class="btn btn-gold btn-sm">Simpan</button>
              </form>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
    <?php endif; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
