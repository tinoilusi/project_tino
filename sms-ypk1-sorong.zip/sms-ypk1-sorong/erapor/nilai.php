<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'guru']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Input Nilai';
$modul_aktif = 'erapor';
$role = $_SESSION['role'];
$pesan = '';
$ta_aktif = tahun_ajaran_aktif($conn);

if (!$ta_aktif) {
    include __DIR__ . '/../includes/header.php';
    include __DIR__ . '/../includes/sidebar.php';
    echo '<main class="main-content"><div class="topbar"><h2>Input Nilai</h2></div><div class="content">
          <div class="alert alert-error">Belum ada Tahun Ajaran aktif. Aktifkan dahulu di menu <a href="' . BASE_URL . 'manajemen/tahun_ajaran.php">Manajemen &gt; Tahun Ajaran</a>.</div>
          </div></main>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}
$ta_id = (int) $ta_aktif['id'];

// --- daftar penugasan yang boleh diakses akun ini ---
if ($role === 'guru') {
    $filter_guru = " AND p.pegawai_id=" . (int) $_SESSION['pegawai_id'];
} else {
    $filter_guru = '';
}
$opsi_pengajaran = mysqli_query($conn, "SELECT p.id, kl.nama_kelas, m.nama_mapel
                                         FROM pengajaran p
                                         JOIN kelas kl ON kl.id=p.kelas_id
                                         JOIN mata_pelajaran m ON m.id=p.mapel_id
                                         WHERE p.tahun_ajaran_id=$ta_id $filter_guru
                                         ORDER BY kl.tingkat, m.nama_mapel");
$opsi_list = [];
while ($o = mysqli_fetch_assoc($opsi_pengajaran)) $opsi_list[$o['id']] = $o;

$pengajaran_id = (int) ($_POST['pengajaran_id'] ?? $_GET['pengajaran_id'] ?? 0);
if ($pengajaran_id && !isset($opsi_list[$pengajaran_id])) {
    $pengajaran_id = 0; // bukan penugasan milik akun ini — abaikan
}
if (!$pengajaran_id && count($opsi_list) === 1) {
    $pengajaran_id = array_key_first($opsi_list);
}

// --- simpan nilai (batch) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan_nilai' && $pengajaran_id) {
    $pg = mysqli_fetch_assoc(mysqli_query($conn, "SELECT p.kelas_id, p.mapel_id, m.kkm FROM pengajaran p JOIN mata_pelajaran m ON m.id=p.mapel_id WHERE p.id=" . (int)$pengajaran_id));
    if ($pg) {
        $stmt = mysqli_prepare($conn, "INSERT INTO nilai_akademik (siswa_id, mapel_id, kelas_id, tahun_ajaran_id, nilai_harian, nilai_uts, nilai_uas, nilai_akhir, predikat, deskripsi, diinput_oleh)
                                        VALUES (?,?,?,?,?,?,?,?,?,?,?)
                                        ON DUPLICATE KEY UPDATE nilai_harian=VALUES(nilai_harian), nilai_uts=VALUES(nilai_uts), nilai_uas=VALUES(nilai_uas),
                                        nilai_akhir=VALUES(nilai_akhir), predikat=VALUES(predikat), deskripsi=VALUES(deskripsi), diinput_oleh=VALUES(diinput_oleh)");
        foreach (($_POST['siswa'] ?? []) as $siswa_id => $f) {
            $siswa_id = (int) $siswa_id;
            $harian = $f['harian'] !== '' ? (float) str_replace(',', '.', $f['harian']) : null;
            $uts    = $f['uts'] !== ''    ? (float) str_replace(',', '.', $f['uts'])    : null;
            $uas    = $f['uas'] !== ''    ? (float) str_replace(',', '.', $f['uas'])    : null;
            $deskripsi = bersihkan($f['deskripsi'] ?? '');
            $akhir  = hitung_nilai_akhir($harian, $uts, $uas);
            $predikat = $akhir !== null ? predikat_nilai($akhir, (int)$pg['kkm']) : null;

            mysqli_stmt_bind_param($stmt, 'iiiiddddssi',
                $siswa_id, $pg['mapel_id'], $pg['kelas_id'], $ta_id, $harian, $uts, $uas, $akhir, $predikat, $deskripsi, $_SESSION['user_id']);
            mysqli_stmt_execute($stmt);
        }
        $pesan = 'Nilai berhasil disimpan.';
    }
}

// --- data untuk ditampilkan ---
$siswa_rows = [];
$mapel_info = null; $kelas_info = null;
if ($pengajaran_id) {
    $pg = mysqli_fetch_assoc(mysqli_query($conn, "SELECT p.kelas_id, p.mapel_id, kl.nama_kelas, m.nama_mapel, m.kkm
                                                   FROM pengajaran p JOIN kelas kl ON kl.id=p.kelas_id JOIN mata_pelajaran m ON m.id=p.mapel_id
                                                   WHERE p.id=" . (int)$pengajaran_id));
    if ($pg) {
        $mapel_info = $pg;
        $res = mysqli_query($conn, "SELECT s.id, s.nama, s.nis, n.nilai_harian, n.nilai_uts, n.nilai_uas, n.nilai_akhir, n.predikat, n.deskripsi
                                     FROM siswa s
                                     LEFT JOIN nilai_akademik n ON n.siswa_id=s.id AND n.mapel_id=" . (int)$pg['mapel_id'] . " AND n.tahun_ajaran_id=$ta_id
                                     WHERE s.kelas_id=" . (int)$pg['kelas_id'] . " AND s.status='Aktif'
                                     ORDER BY s.nama");
        while ($r = mysqli_fetch_assoc($res)) $siswa_rows[] = $r;
    }
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Input Nilai Akademik</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <form method="GET" class="grid grid-3" style="align-items:end;">
        <div class="form-group mb-0" style="grid-column: span 2;">
          <label>Pilih Kelas &amp; Mata Pelajaran</label>
          <select name="pengajaran_id" class="form-control" onchange="this.form.submit()">
            <option value="">— Pilih —</option>
            <?php foreach ($opsi_list as $id => $o): ?>
              <option value="<?php echo $id; ?>" <?php echo $id == $pengajaran_id ? 'selected' : ''; ?>><?php echo bersihkan($o['nama_kelas'] . ' — ' . $o['nama_mapel']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </form>
      <?php if (empty($opsi_list)): ?>
        <p class="muted" style="margin-top:10px;">
          <?php echo $role === 'guru' ? 'Anda belum ditugaskan mengampu mata pelajaran apapun pada tahun ajaran ini.' : 'Belum ada penugasan guru mapel. Buat dulu di menu Penugasan Guru Mapel.'; ?>
        </p>
      <?php endif; ?>
    </div>

    <?php if ($mapel_info && !empty($siswa_rows)): ?>
    <div class="card">
      <div class="flex-between" style="flex-wrap:wrap;">
        <h3 class="mb-0">Nilai — <?php echo bersihkan($mapel_info['nama_kelas'] . ' · ' . $mapel_info['nama_mapel']); ?></h3>
        <span class="pill">KKM <?php echo (int)$mapel_info['kkm']; ?></span>
      </div>
      <p class="muted">Bobot nilai akhir: Harian 30% · UTS 30% · UAS 40% (dihitung otomatis, bobot menyesuaikan bila ada komponen yang belum diisi). Predikat: A ≥ 90, B ≥ KKM, C ≥ KKM-10, D di bawahnya.</p>
      <form method="POST">
        <input type="hidden" name="aksi" value="simpan_nilai">
        <input type="hidden" name="pengajaran_id" value="<?php echo $pengajaran_id; ?>">
        <div class="table-wrap">
        <table>
          <thead><tr><th>Siswa</th><th>Harian</th><th>UTS</th><th>UAS</th><th>Nilai Akhir</th><th>Predikat</th><th>Deskripsi Capaian (opsional)</th></tr></thead>
          <tbody>
          <?php foreach ($siswa_rows as $s): ?>
            <tr>
              <td><?php echo bersihkan($s['nama']); ?></td>
              <td><input type="text" class="form-control nilai-input" name="siswa[<?php echo $s['id']; ?>][harian]" value="<?php echo $s['nilai_harian'] !== null ? rtrim(rtrim($s['nilai_harian'],'0'),'.') : ''; ?>"></td>
              <td><input type="text" class="form-control nilai-input" name="siswa[<?php echo $s['id']; ?>][uts]" value="<?php echo $s['nilai_uts'] !== null ? rtrim(rtrim($s['nilai_uts'],'0'),'.') : ''; ?>"></td>
              <td><input type="text" class="form-control nilai-input" name="siswa[<?php echo $s['id']; ?>][uas]" value="<?php echo $s['nilai_uas'] !== null ? rtrim(rtrim($s['nilai_uas'],'0'),'.') : ''; ?>"></td>
              <td style="font-weight:700;"><?php echo $s['nilai_akhir'] !== null ? (float)$s['nilai_akhir'] : '-'; ?></td>
              <td><?php echo $s['predikat'] ? '<span class="pill">' . bersihkan($s['predikat']) . '</span>' : '-'; ?></td>
              <td><input type="text" class="form-control" name="siswa[<?php echo $s['id']; ?>][deskripsi]" value="<?php echo bersihkan($s['deskripsi'] ?? ''); ?>" placeholder="contoh: Sudah mampu memahami konsep dasar"></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:14px;">💾 Simpan Semua Nilai</button>
      </form>
    </div>
    <?php elseif ($mapel_info): ?>
      <div class="card"><p class="muted">Belum ada siswa aktif di kelas ini.</p></div>
    <?php endif; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
