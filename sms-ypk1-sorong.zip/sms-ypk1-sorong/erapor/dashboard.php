<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'guru']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Dashboard E-Rapor';
$modul_aktif = 'erapor';
$role = $_SESSION['role'];
$ta_aktif = tahun_ajaran_aktif($conn);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Dashboard E-Rapor</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">

    <?php if (!$ta_aktif): ?>
      <div class="alert alert-error">Belum ada Tahun Ajaran aktif. Aktifkan tahun ajaran/semester terlebih dahulu di menu <a href="<?php echo BASE_URL; ?>manajemen/tahun_ajaran.php">Manajemen &gt; Tahun Ajaran</a> sebelum mengelola nilai.</div>
    <?php else: ?>
      <div class="card" style="background:linear-gradient(135deg,#0B3C5D,#082A42); color:#fff;">
        <div style="font-size:13px; opacity:.8;">Tahun Ajaran Aktif</div>
        <div style="font-size:20px; font-weight:700;"><?php echo bersihkan($ta_aktif['tahun']); ?> — Semester <?php echo bersihkan($ta_aktif['semester']); ?></div>
      </div>

      <?php if ($role === 'kepala_sekolah'):
        $rekap = mysqli_query($conn, "SELECT k.id, k.nama_kelas,
                    (SELECT COUNT(*) FROM siswa s WHERE s.kelas_id=k.id AND s.status='Aktif') AS jml_siswa,
                    (SELECT COUNT(*) FROM pengajaran p WHERE p.kelas_id=k.id AND p.tahun_ajaran_id=" . (int)$ta_aktif['id'] . ") AS jml_mapel,
                    (SELECT COUNT(*) FROM nilai_akademik n WHERE n.kelas_id=k.id AND n.tahun_ajaran_id=" . (int)$ta_aktif['id'] . " AND n.nilai_akhir IS NOT NULL) AS jml_terisi,
                    (SELECT COUNT(*) FROM nilai_sikap ns JOIN siswa s2 ON s2.id=ns.siswa_id WHERE s2.kelas_id=k.id AND ns.tahun_ajaran_id=" . (int)$ta_aktif['id'] . ") AS jml_sikap
                  FROM kelas k ORDER BY k.tingkat, k.nama_kelas");
      ?>
      <div class="card">
        <h3>Progres Penilaian per Kelas</h3>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Kelas</th><th>Siswa</th><th>Mapel Diampu</th><th>Target Nilai</th><th>Nilai Terisi</th><th>Progres</th><th>Sikap Terisi</th></tr></thead>
          <tbody>
          <?php while ($k = mysqli_fetch_assoc($rekap)):
            $target = $k['jml_siswa'] * $k['jml_mapel'];
            $pct = $target > 0 ? round($k['jml_terisi'] / $target * 100) : 0;
          ?>
            <tr>
              <td><strong><?php echo bersihkan($k['nama_kelas']); ?></strong></td>
              <td><?php echo $k['jml_siswa']; ?></td>
              <td><?php echo $k['jml_mapel']; ?></td>
              <td><?php echo $target; ?></td>
              <td><?php echo $k['jml_terisi']; ?></td>
              <td style="min-width:140px;">
                <div class="progress-track"><div class="progress-fill" style="width:<?php echo $pct; ?>%;"></div></div>
                <div class="muted" style="font-size:11px; margin-top:2px;"><?php echo $pct; ?>%</div>
              </td>
              <td><?php echo $k['jml_sikap']; ?> / <?php echo $k['jml_siswa']; ?> siswa</td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        </div>
      </div>

      <div class="card">
        <h3>Akses Cepat</h3>
        <div class="grid grid-4">
          <a class="btn btn-outline" href="<?php echo BASE_URL; ?>erapor/mapel.php">📚 Mata Pelajaran</a>
          <a class="btn btn-outline" href="<?php echo BASE_URL; ?>erapor/pengajaran.php">🧑‍🏫 Penugasan Guru</a>
          <a class="btn btn-outline" href="<?php echo BASE_URL; ?>erapor/nilai.php">✏️ Input / Koreksi Nilai</a>
          <a class="btn btn-outline" href="<?php echo BASE_URL; ?>erapor/cetak_rapor.php">🖨️ Cetak Rapor</a>
        </div>
      </div>

      <?php else: // GURU
        $pegawai_id = (int) $_SESSION['pegawai_id'];
        $tugas = mysqli_query($conn, "SELECT p.id, kl.nama_kelas, m.nama_mapel, kl.id AS kelas_id, m.id AS mapel_id,
                    (SELECT COUNT(*) FROM siswa s WHERE s.kelas_id=kl.id AND s.status='Aktif') AS jml_siswa,
                    (SELECT COUNT(*) FROM nilai_akademik n WHERE n.kelas_id=kl.id AND n.mapel_id=m.id AND n.tahun_ajaran_id=" . (int)$ta_aktif['id'] . " AND n.nilai_akhir IS NOT NULL) AS jml_terisi
                  FROM pengajaran p
                  JOIN kelas kl ON kl.id = p.kelas_id
                  JOIN mata_pelajaran m ON m.id = p.mapel_id
                  WHERE p.pegawai_id=$pegawai_id AND p.tahun_ajaran_id=" . (int)$ta_aktif['id'] . "
                  ORDER BY kl.tingkat, m.nama_mapel");
      ?>
      <div class="card">
        <h3>Mata Pelajaran yang Anda Ampu</h3>
        <?php if (mysqli_num_rows($tugas) === 0): ?>
          <p class="muted">Anda belum ditugaskan mengampu mata pelajaran apapun pada tahun ajaran ini. Hubungi Kepala Sekolah untuk penugasan melalui menu Penugasan Guru Mapel.</p>
        <?php else: ?>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Kelas</th><th>Mata Pelajaran</th><th>Siswa</th><th>Nilai Terisi</th><th>Progres</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php while ($t = mysqli_fetch_assoc($tugas)): $pct = $t['jml_siswa'] > 0 ? round($t['jml_terisi']/$t['jml_siswa']*100) : 0; ?>
            <tr>
              <td><strong><?php echo bersihkan($t['nama_kelas']); ?></strong></td>
              <td><?php echo bersihkan($t['nama_mapel']); ?></td>
              <td><?php echo $t['jml_siswa']; ?></td>
              <td><?php echo $t['jml_terisi']; ?></td>
              <td style="min-width:120px;">
                <div class="progress-track"><div class="progress-fill" style="width:<?php echo $pct; ?>%;"></div></div>
              </td>
              <td><a class="btn btn-outline btn-sm" href="<?php echo BASE_URL; ?>erapor/nilai.php?pengajaran_id=<?php echo $t['id']; ?>">Input Nilai</a></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        </div>
        <?php endif; ?>
      </div>

      <?php if (is_wali_kelas()): ?>
      <div class="card">
        <h3>Wali Kelas <?php echo bersihkan($_SESSION['nama_kelas']); ?></h3>
        <p class="muted">Sebagai wali kelas, Anda juga mengisi nilai sikap, ekstrakurikuler, dan catatan rapor untuk seluruh siswa di kelas ini, serta dapat mencetak rapor.</p>
        <a class="btn btn-outline" href="<?php echo BASE_URL; ?>erapor/sikap.php">🌱 Isi Sikap &amp; Catatan</a>
        <a class="btn btn-outline" href="<?php echo BASE_URL; ?>erapor/cetak_rapor.php">🖨️ Cetak Rapor Kelas</a>
      </div>
      <?php endif; ?>

      <?php endif; ?>
    <?php endif; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
