<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Permintaan Laporan Wali Kelas';
$modul_aktif = 'manajemen';
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'minta') {
    $kelas_id = (int) $_POST['kelas_id'];
    $bulan = bersihkan($_POST['bulan']);
    $catatan = bersihkan($_POST['catatan_kepsek'] ?? '');
    $stmt = mysqli_prepare($conn, "INSERT INTO laporan_bulanan (kelas_id, bulan, status, diminta_oleh, tanggal_diminta, catatan_kepsek)
                                    VALUES (?,?,'Diminta',?,NOW(),?)
                                    ON DUPLICATE KEY UPDATE status='Diminta', diminta_oleh=VALUES(diminta_oleh), tanggal_diminta=NOW(), catatan_kepsek=VALUES(catatan_kepsek)");
    mysqli_stmt_bind_param($stmt, 'iiis', $kelas_id, $bulan, $_SESSION['user_id'], $catatan);
    mysqli_stmt_execute($stmt);
    $pesan = 'Permintaan laporan berhasil dikirim ke wali kelas.';
}

if (isset($_GET['hapus'])) {
    mysqli_query($conn, "DELETE FROM laporan_bulanan WHERE id=" . (int) $_GET['hapus']);
    $pesan = 'Permintaan laporan dihapus.';
}

$kelas_opt = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat");
$list_result = mysqli_query($conn, "SELECT l.*, k.nama_kelas, w.nama AS nama_wali, dk.username AS username_pengirim
                              FROM laporan_bulanan l
                              LEFT JOIN kelas k ON k.id=l.kelas_id
                              LEFT JOIN pegawai w ON w.id=k.wali_kelas_id
                              LEFT JOIN users dk ON dk.id=l.dikirim_oleh
                              ORDER BY l.tanggal_diminta DESC");
$daftar_permintaan = [];
if ($list_result) { while ($row = mysqli_fetch_assoc($list_result)) { $daftar_permintaan[] = $row; } }

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Permintaan Laporan Wali Kelas</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3>📨 Minta Laporan Bulanan dari Wali Kelas</h3>
      <p class="muted">Wali kelas akan melihat permintaan ini di menu mereka dan bisa mengirimkan rekap kehadiran kelasnya langsung dari sistem.</p>
      <form method="POST" class="grid grid-3" style="align-items:end;">
        <input type="hidden" name="aksi" value="minta">
        <div class="form-group mb-0">
          <label>Kelas</label>
          <select name="kelas_id" class="form-control" required>
            <?php mysqli_data_seek($kelas_opt, 0); while ($k = mysqli_fetch_assoc($kelas_opt)): ?>
              <option value="<?php echo $k['id']; ?>"><?php echo bersihkan($k['nama_kelas']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group mb-0">
          <label>Bulan</label>
          <input type="month" name="bulan" class="form-control" value="<?php echo date('Y-m'); ?>" required>
        </div>
        <div class="form-group mb-0">
          <label>Catatan (opsional)</label>
          <input type="text" name="catatan_kepsek" class="form-control" placeholder="contoh: mohon dilengkapi sebelum akhir bulan">
        </div>
        <button type="submit" class="btn btn-primary" style="grid-column: span 3;">📨 Kirim Permintaan</button>
      </form>
    </div>

    <div class="card">
      <h3>Status Permintaan Laporan</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Kelas</th><th>Wali Kelas</th><th>Bulan</th><th>Status</th><th>Tanggal Diminta</th><th>Tanggal Dikirim</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php if (empty($daftar_permintaan)): ?><tr><td colspan="7" class="muted">Belum ada permintaan laporan.</td></tr><?php endif; ?>
        <?php foreach ($daftar_permintaan as $l): ?>
          <tr>
            <td><?php echo bersihkan($l['nama_kelas']); ?></td>
            <td><?php echo bersihkan($l['nama_wali'] ?: '-'); ?></td>
            <td><?php echo bersihkan($l['bulan']); ?></td>
            <td><?php echo $l['status']==='Sudah Dikirim' ? '<span class="badge-status badge-hadir">Sudah Dikirim</span>' : '<span class="badge-status badge-terlambat">Menunggu</span>'; ?></td>
            <td><?php echo $l['tanggal_diminta'] ? date('d/m/Y H:i', strtotime($l['tanggal_diminta'])) : '-'; ?></td>
            <td><?php echo $l['tanggal_dikirim'] ? date('d/m/Y H:i', strtotime($l['tanggal_dikirim'])) : '-'; ?></td>
            <td>
              <?php if ($l['status']==='Sudah Dikirim'): ?>
                <a class="btn btn-outline btn-sm" href="cetak_rekap_siswa.php?kelas_id=<?php echo $l['kelas_id']; ?>&bulan=<?php echo $l['bulan']; ?>" target="_blank">📄 Lihat Laporan</a>
              <?php endif; ?>
              <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $l['id']; ?>" onclick="return confirm('Hapus permintaan ini?');">Hapus</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
