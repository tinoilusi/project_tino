<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Tahun Ajaran & Semester';
$modul_aktif = 'manajemen';
$pesan = '';

// tambah tahun ajaran baru manual (jika belum lewat proses kenaikan kelas)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi']) && $_POST['aksi'] === 'tambah') {
    $tahun = bersihkan($_POST['tahun']);
    $semester = $_POST['semester'] === 'Genap' ? 'Genap' : 'Ganjil';
    mysqli_query($conn, "INSERT INTO tahun_ajaran (tahun, semester, status_aktif) VALUES ('" . mysqli_real_escape_string($conn,$tahun) . "', '$semester', 0)");
    $pesan = 'Tahun ajaran baru berhasil ditambahkan.';
}

// aktifkan tahun ajaran / semester tertentu
if (isset($_GET['aktifkan'])) {
    $id = (int) $_GET['aktifkan'];
    mysqli_query($conn, "UPDATE tahun_ajaran SET status_aktif = 0");
    mysqli_query($conn, "UPDATE tahun_ajaran SET status_aktif = 1 WHERE id = $id");
    $pesan = 'Tahun ajaran / semester aktif berhasil diperbarui.';
}

$list = mysqli_query($conn, "SELECT * FROM tahun_ajaran ORDER BY id DESC");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Tahun Ajaran &amp; Semester</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3>Ganti Semester Cepat</h3>
      <p class="muted">Untuk berpindah dari semester Ganjil ke Genap (dalam tahun ajaran yang sama) tanpa proses kenaikan kelas, tambahkan baris baru lalu klik "Jadikan Aktif". Untuk pergantian <b>tahun ajaran baru sekaligus kenaikan kelas otomatis</b>, gunakan menu <a href="<?php echo BASE_URL; ?>manajemen/kenaikan_kelas.php">Kenaikan Kelas</a>.</p>
      <form method="POST" class="grid grid-3" style="align-items:end;">
        <input type="hidden" name="aksi" value="tambah">
        <div class="form-group mb-0">
          <label>Tahun Ajaran</label>
          <input type="text" name="tahun" class="form-control" placeholder="contoh: 2026/2027" required>
        </div>
        <div class="form-group mb-0">
          <label>Semester</label>
          <select name="semester" class="form-control">
            <option value="Ganjil">Ganjil</option>
            <option value="Genap">Genap</option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">+ Tambah</button>
      </form>
    </div>

    <div class="card">
      <h3>Daftar Tahun Ajaran</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Tahun Ajaran</th><th>Semester</th><th>Status</th><th>Dibuat</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php while ($t = mysqli_fetch_assoc($list)): ?>
          <tr>
            <td><?php echo bersihkan($t['tahun']); ?></td>
            <td><?php echo bersihkan($t['semester']); ?></td>
            <td><?php echo $t['status_aktif'] ? '<span class="badge-status badge-hadir">Aktif</span>' : '<span class="pill">Nonaktif</span>'; ?></td>
            <td><?php echo format_tanggal_indo($t['created_at']); ?></td>
            <td><?php if (!$t['status_aktif']): ?><a class="btn btn-outline btn-sm" href="?aktifkan=<?php echo $t['id']; ?>" onclick="return confirm('Aktifkan tahun ajaran ini?');">Jadikan Aktif</a><?php else: ?>—<?php endif; ?></td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
