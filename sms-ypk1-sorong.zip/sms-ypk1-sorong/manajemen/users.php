<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Akun Pengguna';
$modul_aktif = 'manajemen';
$pesan = '';
$pesan_error = '';
$pola_username = '/^[A-Za-z0-9._-]{3,50}$/';
$info_username = 'Username 3–50 karakter: huruf, angka, titik, garis bawah, atau tanda hubung (tanpa spasi).';

// pesan hasil pengeditan (setelah redirect, supaya refresh halaman tidak mengirim ulang form)
if (!empty($_SESSION['flash_users'])) {
    if ($_SESSION['flash_users']['ok']) $pesan = $_SESSION['flash_users']['teks'];
    else $pesan_error = $_SESSION['flash_users']['teks'];
    unset($_SESSION['flash_users']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi']) && $_POST['aksi'] === 'tambah') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = in_array($_POST['role'], ['kepala_sekolah', 'guru', 'bendahara'], true) ? $_POST['role'] : 'guru';
    $pegawai_id = (int) $_POST['pegawai_id'];

    if (!preg_match($pola_username, $username)) {
        $pesan_error = $info_username;
    } elseif (strlen($password) < 6) {
        $pesan_error = 'Password minimal 6 karakter.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO users (pegawai_id, username, password, role) VALUES (?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'isss', $pegawai_id, $username, $hash, $role);
        if (mysqli_stmt_execute($stmt)) {
            $pesan = 'Akun baru berhasil dibuat.';
        } else {
            $pesan_error = 'Gagal membuat akun. Username mungkin sudah digunakan.';
        }
    }
}

// --- Ubah username dan/atau password akun mana pun (khusus Kepala Sekolah) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'edit') {
    $id = (int) ($_POST['id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $pw_baru = $_POST['password_baru'] ?? '';
    $pw_ulang = $_POST['password_ulang'] ?? '';
    $ok = false;

    $akun = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id, pegawai_id FROM users WHERE id=$id"));
    if (!$akun) {
        $teks = 'Akun tidak ditemukan.';
    } elseif (!preg_match($pola_username, $username)) {
        $teks = $info_username;
    } elseif ($pw_baru !== '' && strlen($pw_baru) < 6) {
        $teks = 'Password baru minimal 6 karakter.';
    } elseif ($pw_baru !== $pw_ulang) {
        $teks = 'Konfirmasi password tidak sama dengan password baru.';
    } else {
        $cek = mysqli_prepare($conn, "SELECT id FROM users WHERE username=? AND id<>? LIMIT 1");
        mysqli_stmt_bind_param($cek, 'si', $username, $id);
        mysqli_stmt_execute($cek);
        if (mysqli_fetch_assoc(mysqli_stmt_get_result($cek))) {
            $teks = 'Username "' . htmlspecialchars($username) . '" sudah dipakai akun lain. Gunakan username yang berbeda.';
        } else {
            if ($pw_baru !== '') {
                $hash = password_hash($pw_baru, PASSWORD_DEFAULT);
                $stmt = mysqli_prepare($conn, "UPDATE users SET username=?, password=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, 'ssi', $username, $hash, $id);
            } else {
                $stmt = mysqli_prepare($conn, "UPDATE users SET username=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, 'si', $username, $id);
            }
            if (mysqli_stmt_execute($stmt)) {
                $ok = true;
                $teks = 'Akun "' . htmlspecialchars($username) . '" berhasil diperbarui' . ($pw_baru !== '' ? ' (username dan password).' : ' (username).');
                if ($id === (int) $_SESSION['user_id']) {
                    $_SESSION['username'] = $username;
                    if (empty($akun['pegawai_id'])) $_SESSION['nama'] = $username;
                }
            } else {
                $teks = 'Perubahan gagal disimpan. Coba lagi.';
            }
        }
    }
    $_SESSION['flash_users'] = ['ok' => $ok, 'teks' => $teks];
    header('Location: users.php' . ($ok ? '' : '?edit=' . $id));
    exit;
}

if (isset($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];
    if ($id === (int) $_SESSION['user_id']) {
        $pesan_error = 'Anda tidak dapat menonaktifkan akun Anda sendiri.';
    } else {
        mysqli_query($conn, "UPDATE users SET status_aktif = 1 - status_aktif WHERE id=$id");
        $pesan = 'Status akun diperbarui.';
    }
}
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    if ($id == $_SESSION['user_id']) {
        $pesan = 'Anda tidak dapat menghapus akun Anda sendiri.';
    } else {
        mysqli_query($conn, "DELETE FROM users WHERE id=$id");
        $pesan = 'Akun berhasil dihapus.';
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT u.id, u.username, u.role, p.nama AS nama_pegawai FROM users u LEFT JOIN pegawai p ON p.id=u.pegawai_id WHERE u.id=" . (int) $_GET['edit']));
}

$list = mysqli_query($conn, "SELECT u.*, p.nama AS nama_pegawai, p.jenis FROM users u LEFT JOIN pegawai p ON p.id=u.pegawai_id ORDER BY u.role, u.username");
$pegawai_opt = mysqli_query($conn, "SELECT id, nama, jenis FROM pegawai WHERE status_aktif=1 AND id NOT IN (SELECT pegawai_id FROM users WHERE pegawai_id IS NOT NULL) ORDER BY nama");

$tombol_lihat = '<button type="button" class="pw-toggle" aria-label="Tampilkan password" aria-pressed="false" title="Tampilkan password"><svg class="ic-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M1.5 12s3.8-7 10.5-7 10.5 7 10.5 7-3.8 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg><svg class="ic-off" viewBox="0 0 24 24" aria-hidden="true"><path d="M17.9 17.9A10.9 10.9 0 0 1 12 19c-6.7 0-10.5-7-10.5-7a19 19 0 0 1 4.6-5.4M9.9 5.2A10.4 10.4 0 0 1 12 5c6.7 0 10.5 7 10.5 7a19 19 0 0 1-2.2 3.1M14.1 14.1a3 3 0 1 1-4.2-4.2M2 2l20 20"/></svg></button>';

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Akun Pengguna</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>
    <?php if ($pesan_error): ?><div class="alert alert-error"><?php echo $pesan_error; ?></div><?php endif; ?>

    <?php if ($edit): ?>
    <div class="card" style="border-color:var(--gold);">
      <h3>Edit Akun — <?php echo bersihkan($edit['nama_pegawai'] ?: $edit['username']); ?> <span class="pill"><?php echo bersihkan(label_role($edit['role'])); ?></span></h3>
      <form method="POST" autocomplete="off">
        <input type="hidden" name="aksi" value="edit">
        <input type="hidden" name="id" value="<?php echo (int) $edit['id']; ?>">
        <div class="grid grid-3">
          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required minlength="3" maxlength="50" pattern="[A-Za-z0-9._-]{3,50}" value="<?php echo bersihkan($edit['username']); ?>" autocomplete="off">
          </div>
          <div class="form-group">
            <label>Password Baru</label>
            <div class="pw-field">
              <input type="password" name="password_baru" class="form-control" minlength="6" placeholder="Kosongkan bila tidak diganti" autocomplete="new-password">
              <?php echo $tombol_lihat; ?>
            </div>
          </div>
          <div class="form-group">
            <label>Ulangi Password Baru</label>
            <div class="pw-field">
              <input type="password" name="password_ulang" class="form-control" minlength="6" placeholder="Ketik ulang password baru" autocomplete="new-password">
              <?php echo $tombol_lihat; ?>
            </div>
          </div>
        </div>
        <p class="muted" style="margin-top:0;"><?php echo $info_username; ?> Password lama tersimpan dalam bentuk terenkripsi sehingga tidak dapat ditampilkan; isi kolom password hanya jika ingin menggantinya.</p>
        <button type="submit" class="btn btn-primary" style="width:auto;">Simpan Perubahan</button>
        <a href="users.php" class="btn btn-outline">Batal</a>
      </form>
    </div>
    <?php endif; ?>

    <div class="card">
      <h3>Buat Akun Login Baru</h3>
      <p class="muted">Setiap wali kelas perlu akun dengan role <b>Guru</b> untuk mengakses absensi kelasnya. Pastikan pegawai sudah ditetapkan sebagai wali kelas di menu Data Kelas. Untuk pengelola keuangan sekolah/komite, buat akun dengan role <b>Bendahara</b> — pegawai yang dipilih tetap tercatat dengan jenis kepegawaiannya semula (misalnya Guru), hanya hak akses sistemnya yang bertambah.</p>
      <form method="POST">
        <input type="hidden" name="aksi" value="tambah">
        <div class="grid grid-4">
          <div class="form-group">
            <label>Pegawai</label>
            <select name="pegawai_id" class="form-control" required>
              <option value="">— Pilih Pegawai —</option>
              <?php while ($p = mysqli_fetch_assoc($pegawai_opt)): ?>
                <option value="<?php echo $p['id']; ?>"><?php echo bersihkan($p['nama'] . ' (' . $p['jenis'] . ')'); ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="form-group"><label>Username</label><input type="text" name="username" class="form-control" required minlength="3" maxlength="50" pattern="[A-Za-z0-9._-]{3,50}" autocomplete="off"></div>
          <div class="form-group"><label>Password</label><div class="pw-field"><input type="password" name="password" class="form-control" required minlength="6" autocomplete="new-password"><?php echo $tombol_lihat; ?></div></div>
          <div class="form-group">
            <label>Role</label>
            <select name="role" class="form-control">
              <option value="guru">Guru / Wali Kelas</option>
              <option value="bendahara">Bendahara (Keuangan Sekolah &amp; Komite)</option>
              <option value="kepala_sekolah">Kepala Sekolah (Akses Penuh)</option>
            </select>
          </div>
        </div>
        <button type="submit" class="btn btn-primary">+ Buat Akun</button>
      </form>
    </div>

    <div class="card">
      <h3>Daftar Akun</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Username</th><th>Nama Pegawai</th><th>Role</th><th>Status</th><th>Login Terakhir</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php while ($u = mysqli_fetch_assoc($list)): ?>
          <tr>
            <td><?php echo bersihkan($u['username']); ?></td>
            <td><?php echo bersihkan($u['nama_pegawai'] ?: '-'); ?></td>
            <td><span class="pill"><?php echo bersihkan(label_role($u['role'])); ?></span></td>
            <td><?php echo $u['status_aktif'] ? '<span class="badge-status badge-hadir">Aktif</span>' : '<span class="badge-status badge-alpa">Nonaktif</span>'; ?></td>
            <td><?php echo $u['last_login'] ? date('d/m/Y H:i', strtotime($u['last_login'])) : 'Belum pernah'; ?></td>
            <td>
              <a class="btn btn-gold btn-sm" href="?edit=<?php echo $u['id']; ?>">Edit Username / Password</a>
              <a class="btn btn-outline btn-sm" href="?toggle=<?php echo $u['id']; ?>"><?php echo $u['status_aktif'] ? 'Nonaktifkan' : 'Aktifkan'; ?></a>
              <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $u['id']; ?>" onclick="return confirm('Hapus akun ini?');">Hapus</a>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
<script src="<?php echo aset('assets/js/password-toggle.js'); ?>"></script>
