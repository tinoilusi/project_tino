<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Dashboard Manajemen';
$modul_aktif = 'manajemen';
$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';

$jml_siswa   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM siswa WHERE status='Aktif'"))['c'];
$jml_kelas   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM kelas"))['c'];
$jml_guru    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM pegawai WHERE jenis='Guru' AND status_aktif=1"))['c'];
$jml_staf    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM pegawai WHERE jenis IN ('Tata Usaha','Penjaga Sekolah') AND status_aktif=1"))['c'];
$ta_aktif    = tahun_ajaran_aktif($conn);

$tgl = date('Y-m-d');
$res_kelas = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas");
$rekap_kelas = [];
while ($k = mysqli_fetch_assoc($res_kelas)) {
    $total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM siswa WHERE kelas_id={$k['id']} AND status='Aktif'"))['c'];
    $hadir = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM absensi_siswa a JOIN siswa s ON s.id=a.siswa_id WHERE s.kelas_id={$k['id']} AND a.tanggal='$tgl' AND a.status IN ('Hadir','Terlambat')"))['c'];
    $rekap_kelas[] = ['nama' => $k['nama_kelas'], 'total' => $total, 'hadir' => $hadir];
}

// Kehadiran guru & staf hari ini (satu query: pegawai aktif + catatan absensi hari ini bila ada)
$peg_hari = []; $sum_peg = ['Hadir'=>0,'Terlambat'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0,'Belum'=>0];
$per_jenis = [];
$stp = mysqli_prepare($conn, "SELECT p.id, p.nama, p.jenis, p.foto, a.status, a.jam_masuk, a.jam_pulang
    FROM pegawai p LEFT JOIN absensi_pegawai a ON a.pegawai_id = p.id AND a.tanggal = ?
    WHERE p.status_aktif = 1
    ORDER BY FIELD(p.jenis,'Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'), p.nama");
mysqli_stmt_bind_param($stp, 's', $tgl); mysqli_stmt_execute($stp);
$rp = mysqli_stmt_get_result($stp);
while ($p = mysqli_fetch_assoc($rp)) {
    $st = $p['status'] ?: 'Belum';
    $sum_peg[$st]++;
    $j = $p['jenis'];
    if (!isset($per_jenis[$j])) $per_jenis[$j] = ['total'=>0,'hadir'=>0];
    $per_jenis[$j]['total']++;
    if (in_array($st, ['Hadir','Terlambat'], true)) $per_jenis[$j]['hadir']++;
    $peg_hari[] = $p;
}
$tot_peg   = count($peg_hari);
$hadir_peg = $sum_peg['Hadir'] + $sum_peg['Terlambat'];
$pct_peg   = $tot_peg > 0 ? round($hadir_peg / $tot_peg * 100) : 0;

$res_p = mysqli_query($conn, "SELECT judul, isi, created_at FROM pengumuman ORDER BY created_at DESC LIMIT 4");
$tot_hadir = array_sum(array_column($rekap_kelas, 'hadir'));
$tot_siswa = array_sum(array_column($rekap_kelas, 'total'));
$pct_total = $tot_siswa > 0 ? round($tot_hadir / $tot_siswa * 100) : 0;
$bln = ['','JAN','FEB','MAR','APR','MEI','JUN','JUL','AGU','SEP','OKT','NOV','DES'];
$pf = profil_pengguna($conn);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar">
    <h2>Dashboard Manajemen Sekolah</h2>
    <div class="clock" id="liveClock"></div>
  </div>
  <div class="content">

    <section class="hero-banner">
      <div>
        <div class="sapa"><?php echo salam_waktu(); ?>, <?php echo bersihkan($pf['nama']); ?></div>
        <h1>Tahun Ajaran <?php echo bersihkan($ta_aktif['tahun'] ?? '-'); ?> &middot; Semester <?php echo bersihkan($ta_aktif['semester'] ?? '-'); ?></h1>
        <div class="meta">
          <span class="chip"><?php echo ikon('school', 15); ?> <?php echo bersihkan($nama_sekolah); ?></span>
          <span class="chip"><?php echo ikon('calendar', 15); ?> <?php echo format_tanggal_indo(date('Y-m-d')); ?></span>
        </div>
      </div>
      <a href="<?php echo BASE_URL; ?>manajemen/tahun_ajaran.php" class="btn btn-gold btn-sm"><?php echo ikon('calendar', 16); ?> Kelola Tahun Ajaran</a>
    </section>

    <div class="grid grid-4 dash-stats">
      <div class="stat-card"><div class="stat-ic"><?php echo ikon('student', 24); ?></div><div class="stat-tx"><div class="label">Total Siswa Aktif</div><div class="value"><?php echo (int)$jml_siswa; ?></div></div></div>
      <div class="stat-card blue"><div class="stat-ic"><?php echo ikon('school', 24); ?></div><div class="stat-tx"><div class="label">Jumlah Kelas</div><div class="value"><?php echo (int)$jml_kelas; ?></div></div></div>
      <div class="stat-card gold"><div class="stat-ic"><?php echo ikon('staff', 24); ?></div><div class="stat-tx"><div class="label">Guru Aktif</div><div class="value"><?php echo (int)$jml_guru; ?></div></div></div>
      <div class="stat-card dark"><div class="stat-ic"><?php echo ikon('key', 24); ?></div><div class="stat-tx"><div class="label">Tata Usaha &amp; Penjaga</div><div class="value"><?php echo (int)$jml_staf; ?></div></div></div>
    </div>

    <div class="dash-grid">
      <div class="dash-col">
      <div class="card">
        <div class="card-head"><h3>Kehadiran Siswa Hari Ini</h3><span class="sub">Per kelas</span></div>

        <div class="att-sum">
          <div class="ring" style="--p:<?php echo $pct_total; ?>"><b><?php echo $pct_total; ?>%</b></div>
          <div class="att-nums">
            <div><span>Hadir</span><b class="g"><?php echo $tot_hadir; ?></b></div>
            <div><span>Total siswa</span><b><?php echo $tot_siswa; ?></b></div>
            <div><span>Belum hadir</span><b><?php echo max(0, $tot_siswa - $tot_hadir); ?></b></div>
          </div>
        </div>

        <?php if (!$rekap_kelas): ?><div class="empty">Belum ada data kelas.</div><?php endif; ?>
        <?php foreach ($rekap_kelas as $r): $pct = $r['total'] > 0 ? round($r['hadir']/$r['total']*100) : 0; $kls = $pct >= 85 ? '' : ($pct >= 60 ? 'mid' : 'low'); ?>
          <div class="cls-row">
            <div class="nm"><?php echo bersihkan($r['nama']); ?></div>
            <div class="bar" title="<?php echo $pct; ?>%"><i class="<?php echo $kls; ?>" style="width:<?php echo $pct; ?>%"></i></div>
            <div class="ct"><b><?php echo (int)$r['hadir']; ?></b> / <?php echo (int)$r['total']; ?> &middot; <?php echo $pct; ?>%</div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="card" id="kehadiran-guru">
        <div class="card-head"><h3>Kehadiran Guru &amp; Staf Hari Ini</h3>
          <a href="<?php echo BASE_URL; ?>absensi/rekap_pegawai.php" class="btn btn-outline btn-sm">Rekap Bulanan</a></div>

        <div class="att-sum">
          <div class="ring" style="--p:<?php echo $pct_peg; ?>"><b><?php echo $pct_peg; ?>%</b></div>
          <div class="att-nums">
            <div><span>Hadir</span><b class="g"><?php echo $hadir_peg; ?></b></div>
            <div><span>Total guru &amp; staf</span><b><?php echo $tot_peg; ?></b></div>
            <div><span>Belum hadir</span><b><?php echo max(0, $tot_peg - $hadir_peg); ?></b></div>
          </div>
        </div>

        <div class="peg-pills">
          <?php foreach (['Hadir','Terlambat','Sakit','Izin','Alpa'] as $stt): ?>
            <span class="peg-pill"><?php echo badge_status($stt); ?><b><?php echo (int)$sum_peg[$stt]; ?></b></span>
          <?php endforeach; ?>
          <span class="peg-pill"><span class="badge-status badge-belum">Belum absen</span><b><?php echo (int)$sum_peg['Belum']; ?></b></span>
        </div>

        <?php if (!$tot_peg): ?><div class="empty">Belum ada data guru &amp; staf.</div><?php endif; ?>
        <?php foreach ($per_jenis as $nm => $r): $pct = $r['total'] > 0 ? round($r['hadir']/$r['total']*100) : 0; $kls = $pct >= 85 ? '' : ($pct >= 60 ? 'mid' : 'low'); ?>
          <div class="cls-row">
            <div class="nm"><?php echo bersihkan($nm); ?></div>
            <div class="bar" title="<?php echo $pct; ?>%"><i class="<?php echo $kls; ?>" style="width:<?php echo $pct; ?>%"></i></div>
            <div class="ct"><b><?php echo (int)$r['hadir']; ?></b> / <?php echo (int)$r['total']; ?> &middot; <?php echo $pct; ?>%</div>
          </div>
        <?php endforeach; ?>

        <?php if ($tot_peg): ?>
        <details class="peg-detail" open>
          <summary>Rincian per orang <span class="muted">(<?php echo $tot_peg; ?>)</span></summary>
          <div class="peg-list">
            <?php foreach ($peg_hari as $p): $st = $p['status'] ?: 'Belum'; ?>
              <div class="peg-row">
                <?php echo render_avatar($p['nama'], $p['foto']); ?>
                <div class="who"><b><?php echo bersihkan($p['nama']); ?></b><span><?php echo bersihkan($p['jenis']); ?></span></div>
                <div class="st">
                  <?php echo $st === 'Belum' ? '<span class="badge-status badge-belum">Belum absen</span>' : badge_status($st); ?>
                  <span class="jam"><?php echo $p['jam_masuk'] ? 'Masuk ' . substr($p['jam_masuk'],0,5) : '&nbsp;'; ?><?php echo $p['jam_pulang'] ? ' · Pulang ' . substr($p['jam_pulang'],0,5) : ''; ?></span>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </details>
        <?php endif; ?>
      </div>
      </div>

      <div class="dash-col">
        <div class="card">
          <div class="card-head"><h3>Pengumuman Terbaru</h3><a href="<?php echo BASE_URL; ?>manajemen/pengumuman.php" class="btn btn-outline btn-sm">Kelola</a></div>
          <?php if (mysqli_num_rows($res_p) === 0): ?>
            <div class="empty">Belum ada pengumuman.</div>
          <?php else: while ($p = mysqli_fetch_assoc($res_p)): $ts = strtotime($p['created_at']); ?>
            <div class="ann-item">
              <div class="ann-date"><b><?php echo date('j', $ts); ?></b><span><?php echo $bln[(int)date('n', $ts)]; ?></span></div>
              <div class="ann-body"><strong><?php echo bersihkan($p['judul']); ?></strong><p><?php echo bersihkan(mb_strimwidth($p['isi'],0,110,'...')); ?></p></div>
            </div>
          <?php endwhile; endif; ?>
        </div>

        <div class="card">
          <div class="card-head"><h3>Akses Cepat</h3></div>
          <div class="quick-grid">
            <a class="quick-tile" href="<?php echo BASE_URL; ?>manajemen/siswa.php"><span class="qi"><?php echo ikon('student'); ?></span>Data Siswa</a>
            <a class="quick-tile" href="<?php echo BASE_URL; ?>manajemen/pegawai.php"><span class="qi"><?php echo ikon('staff'); ?></span>Guru &amp; Staf</a>
            <a class="quick-tile" href="<?php echo BASE_URL; ?>manajemen/kenaikan_kelas.php"><span class="qi"><?php echo ikon('promote'); ?></span>Kenaikan Kelas</a>
            <a class="quick-tile" href="<?php echo BASE_URL; ?>absensi/rekap_pegawai.php"><span class="qi"><?php echo ikon('staff'); ?></span>Rekap Guru &amp; Staf</a>
            <a class="quick-tile" href="<?php echo BASE_URL; ?>absensi/beranda.php"><span class="qi"><?php echo ikon('qr'); ?></span>Buka Absensi</a>
          </div>
        </div>
      </div>
    </div>

  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
