<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Kenaikan Kelas & Semester';
$modul_aktif = 'manajemen';
$pesan = '';
$ta_aktif = tahun_ajaran_aktif($conn);

// -----------------------------------------------------------------
// AKSI 1: Ganti semester Ganjil -> Genap (tahun ajaran sama, TANPA naik kelas)
// -----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'ganti_semester') {
    if ($ta_aktif && $ta_aktif['semester'] === 'Ganjil') {
        mysqli_query($conn, "UPDATE tahun_ajaran SET status_aktif=0 WHERE id=" . $ta_aktif['id']);
        $tahun = mysqli_real_escape_string($conn, $ta_aktif['tahun']);
        mysqli_query($conn, "INSERT INTO tahun_ajaran (tahun, semester, status_aktif) VALUES ('$tahun','Genap',1)");
        $pesan = "Semester berhasil diganti ke Genap untuk tahun ajaran {$ta_aktif['tahun']}.";
        $ta_aktif = tahun_ajaran_aktif($conn);
    } else {
        $pesan = 'Semester aktif saat ini bukan Ganjil, atau tidak ada tahun ajaran aktif.';
    }
}

// -----------------------------------------------------------------
// AKSI 2: Proses kenaikan kelas & buka tahun ajaran baru (final commit)
// -----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'proses_kenaikan') {
    $tahun_baru = bersihkan($_POST['tahun_baru']);
    $target = $_POST['target'] ?? []; // [siswa_id => kelas_tujuan_id atau 'lulus']

    mysqli_query($conn, "UPDATE tahun_ajaran SET status_aktif=0");
    mysqli_query($conn, "INSERT INTO tahun_ajaran (tahun, semester, status_aktif) VALUES ('" . mysqli_real_escape_string($conn,$tahun_baru) . "','Ganjil',1)");
    $tahun_ajaran_baru_id = mysqli_insert_id($conn);
    $tahun_ajaran_lama_id = $ta_aktif['id'] ?? null;

    foreach ($target as $siswa_id => $tujuan) {
        $siswa_id = (int) $siswa_id;
        $dari = mysqli_fetch_assoc(mysqli_query($conn, "SELECT kelas_id FROM siswa WHERE id=$siswa_id"))['kelas_id'] ?? null;

        if ($tujuan === 'lulus') {
            mysqli_query($conn, "UPDATE siswa SET status='Lulus' WHERE id=$siswa_id");
            $status_riwayat = 'Lulus';
            $ke_kelas_id = 'NULL';
        } elseif ($tujuan === 'tinggal') {
            $status_riwayat = 'Tinggal Kelas';
            $ke_kelas_id = (int) $dari;
        } else {
            $tujuan_id = (int) $tujuan;
            mysqli_query($conn, "UPDATE siswa SET kelas_id=$tujuan_id WHERE id=$siswa_id");
            $status_riwayat = 'Naik Kelas';
            $ke_kelas_id = $tujuan_id;
        }

        $dari_val = $dari !== null ? (int)$dari : 'NULL';
        mysqli_query($conn, "INSERT INTO riwayat_kenaikan_kelas (siswa_id, dari_kelas_id, ke_kelas_id, tahun_ajaran_asal_id, tahun_ajaran_tujuan_id, status, diproses_oleh)
                              VALUES ($siswa_id, $dari_val, $ke_kelas_id, " . ($tahun_ajaran_lama_id ?: 'NULL') . ", $tahun_ajaran_baru_id, '$status_riwayat', {$_SESSION['user_id']})");
    }

    $pesan = 'Kenaikan kelas berhasil diproses! Tahun ajaran baru "' . bersihkan($tahun_baru) . '" (Ganjil) kini aktif.';
    $ta_aktif = tahun_ajaran_aktif($conn);
}

// -----------------------------------------------------------------
// Data untuk PREVIEW kenaikan kelas
// -----------------------------------------------------------------
$siswa_preview = mysqli_query($conn, "SELECT s.id, s.nis, s.nama, s.kelas_id, k.nama_kelas, k.kelas_lanjutan_id, kl.nama_kelas AS nama_lanjutan
                                       FROM siswa s
                                       LEFT JOIN kelas k ON k.id = s.kelas_id
                                       LEFT JOIN kelas kl ON kl.id = k.kelas_lanjutan_id
                                       WHERE s.status='Aktif'
                                       ORDER BY k.tingkat, k.nama_kelas, s.nama");
$semua_kelas = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas");
$kelas_arr = [];
while ($k = mysqli_fetch_assoc($semua_kelas)) $kelas_arr[] = $k;

$riwayat = mysqli_query($conn, "SELECT r.*, s.nama AS nama_siswa, dk.nama_kelas AS dari_nama, kk.nama_kelas AS ke_nama, ta.tahun AS tahun_tujuan
                                 FROM riwayat_kenaikan_kelas r
                                 LEFT JOIN siswa s ON s.id=r.siswa_id
                                 LEFT JOIN kelas dk ON dk.id=r.dari_kelas_id
                                 LEFT JOIN kelas kk ON kk.id=r.ke_kelas_id
                                 LEFT JOIN tahun_ajaran ta ON ta.id=r.tahun_ajaran_tujuan_id
                                 ORDER BY r.tanggal_proses DESC LIMIT 100");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Kenaikan Kelas &amp; Pergantian Semester</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card" style="background:linear-gradient(135deg,#0B3C5D,#082A42); color:#fff;">
      <div style="font-size:13px; opacity:.8;">Status Saat Ini</div>
      <div style="font-size:20px; font-weight:700;">Tahun Ajaran <?php echo bersihkan($ta_aktif['tahun'] ?? '-'); ?> — Semester <?php echo bersihkan($ta_aktif['semester'] ?? '-'); ?></div>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>1️⃣ Ganti Semester (Ganjil → Genap)</h3>
        <p class="muted">Gunakan ini di pertengahan tahun ajaran. Siswa <b>tidak</b> berpindah kelas, hanya semester yang berganti.</p>
        <form method="POST" onsubmit="return confirm('Ganti ke semester Genap sekarang?');">
          <input type="hidden" name="aksi" value="ganti_semester">
          <button type="submit" class="btn btn-primary" <?php echo (!$ta_aktif || $ta_aktif['semester'] !== 'Ganjil') ? 'disabled' : ''; ?>>🔁 Ganti ke Semester Genap</button>
        </form>
      </div>
      <div class="card">
        <h3>2️⃣ Tahun Ajaran Baru + Kenaikan Kelas Otomatis</h3>
        <p class="muted">Gunakan ini di akhir tahun ajaran (akhir semester Genap). Sistem akan menaikkan seluruh siswa secara otomatis sesuai pengaturan "Kelas Lanjutan", dan meluluskan siswa kelas XII. Tinjau &amp; sesuaikan dahulu di tabel bawah sebelum konfirmasi final.</p>
      </div>
    </div>

    <div class="card">
      <h3>📋 Tinjau &amp; Proses Kenaikan Kelas</h3>
      <form method="POST" onsubmit="return confirm('PERHATIAN: proses ini akan memindahkan seluruh siswa ke kelas baru / meluluskan siswa kelas akhir, dan membuka tahun ajaran baru. Tindakan ini tidak dapat dibatalkan langsung. Lanjutkan?');">
        <input type="hidden" name="aksi" value="proses_kenaikan">
        <div class="form-group" style="max-width:280px;">
          <label>Tahun Ajaran Baru</label>
          <input type="text" name="tahun_baru" class="form-control" placeholder="contoh: 2027/2028" required>
        </div>
        <div class="table-wrap">
        <table>
          <thead><tr><th>NIS</th><th>Nama</th><th>Kelas Saat Ini</th><th>Diarahkan Ke</th></tr></thead>
          <tbody>
          <?php while ($s = mysqli_fetch_assoc($siswa_preview)): ?>
            <tr>
              <td><?php echo bersihkan($s['nis']); ?></td>
              <td><?php echo bersihkan($s['nama']); ?></td>
              <td><?php echo bersihkan($s['nama_kelas'] ?: '-'); ?></td>
              <td>
                <select name="target[<?php echo $s['id']; ?>]" class="form-control">
                  <?php foreach ($kelas_arr as $k): ?>
                    <option value="<?php echo $k['id']; ?>" <?php echo ($s['kelas_lanjutan_id'] == $k['id']) ? 'selected' : ''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option>
                  <?php endforeach; ?>
                  <option value="tinggal" <?php echo (!$s['kelas_lanjutan_id'] && $s['nama_lanjutan']===null && $s['kelas_id']) ? '' : ''; ?>>Tinggal di Kelas yang Sama</option>
                  <option value="lulus" <?php echo (!$s['kelas_lanjutan_id']) ? 'selected' : ''; ?>>Lulus</option>
                </select>
              </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        </div>
        <button type="submit" class="btn btn-gold" style="margin-top:14px;">🎓 Konfirmasi &amp; Proses Kenaikan Kelas</button>
      </form>
    </div>

    <div class="card">
      <h3>Riwayat Kenaikan Kelas / Kelulusan</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal Proses</th><th>Nama Siswa</th><th>Dari</th><th>Ke</th><th>Status</th><th>Tahun Ajaran Tujuan</th></tr></thead>
        <tbody>
        <?php if (mysqli_num_rows($riwayat) === 0): ?><tr><td colspan="6" class="muted">Belum ada riwayat.</td></tr><?php endif; ?>
        <?php while ($r = mysqli_fetch_assoc($riwayat)): ?>
          <tr>
            <td><?php echo date('d/m/Y H:i', strtotime($r['tanggal_proses'])); ?></td>
            <td><?php echo bersihkan($r['nama_siswa']); ?></td>
            <td><?php echo bersihkan($r['dari_nama'] ?: '-'); ?></td>
            <td><?php echo bersihkan($r['ke_nama'] ?: '-'); ?></td>
            <td><span class="pill"><?php echo $r['status']; ?></span></td>
            <td><?php echo bersihkan($r['tahun_tujuan'] ?: '-'); ?></td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
