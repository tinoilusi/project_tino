<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Data Siswa';
$modul_aktif = 'manajemen';
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nis = bersihkan($_POST['nis']);
    $nisn = bersihkan($_POST['nisn']);
    $nik = bersihkan($_POST['nik'] ?? '');
    $nama = bersihkan($_POST['nama']);
    $jk = $_POST['jenis_kelamin'] === 'P' ? 'P' : 'L';
    $ttl = bersihkan($_POST['tempat_lahir']);
    $tgl_lahir = $_POST['tanggal_lahir'] ?: null;
    $alamat = bersihkan($_POST['alamat']);
    $nama_ortu = bersihkan($_POST['nama_ortu']);
    $hp_ortu = bersihkan($_POST['no_hp_ortu']);
    $kelas_id = (int) $_POST['kelas_id'];

    // foto profil (opsional, diperkecil otomatis maks 500x600)
    $foto_baru = proses_upload_gambar('foto_siswa', 'siswa_foto', 500, 600);
    if ($foto_baru === false) {
        $pesan = 'Gagal mengunggah foto. Pastikan file adalah gambar (JPG/PNG/WEBP) dan ukuran maksimal 8MB.';
    }

    if (!empty($_POST['id'])) {
        $id = (int) $_POST['id'];
        if ($foto_baru) {
            $foto_lama = mysqli_fetch_assoc(mysqli_query($conn, "SELECT foto FROM siswa WHERE id=$id"))['foto'] ?? null;
            if ($foto_lama && file_exists(path_upload_dir() . $foto_lama)) @unlink(path_upload_dir() . $foto_lama);
            $stmt = mysqli_prepare($conn, "UPDATE siswa SET nis=?, nisn=?, nik=?, nama=?, jenis_kelamin=?, tempat_lahir=?, tanggal_lahir=?, alamat=?, nama_ortu=?, no_hp_ortu=?, kelas_id=?, foto=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'ssssssssssisi', $nis, $nisn, $nik, $nama, $jk, $ttl, $tgl_lahir, $alamat, $nama_ortu, $hp_ortu, $kelas_id, $foto_baru, $id);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE siswa SET nis=?, nisn=?, nik=?, nama=?, jenis_kelamin=?, tempat_lahir=?, tanggal_lahir=?, alamat=?, nama_ortu=?, no_hp_ortu=?, kelas_id=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'ssssssssssii', $nis, $nisn, $nik, $nama, $jk, $ttl, $tgl_lahir, $alamat, $nama_ortu, $hp_ortu, $kelas_id, $id);
        }
        mysqli_stmt_execute($stmt);
        if (!$pesan) $pesan = 'Data siswa berhasil diperbarui.';
    } else {
        $token = generate_token('SIS', 6);
        $stmt = mysqli_prepare($conn, "INSERT INTO siswa (nis, nisn, nik, nama, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, nama_ortu, no_hp_ortu, kelas_id, foto, qr_token) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'ssssssssssiss', $nis, $nisn, $nik, $nama, $jk, $ttl, $tgl_lahir, $alamat, $nama_ortu, $hp_ortu, $kelas_id, $foto_baru, $token);
        if (mysqli_stmt_execute($stmt)) {
            if (!$pesan) $pesan = 'Siswa baru berhasil ditambahkan. Kode QR otomatis dibuat.';
        } else {
            $pesan = 'Gagal menambahkan siswa. NIS mungkin sudah digunakan.';
        }
    }
}

if (isset($_GET['ubah_status'])) {
    $id = (int) $_GET['ubah_status'];
    $status = in_array($_GET['status'] ?? '', ['Aktif','Lulus','Pindah','Keluar']) ? $_GET['status'] : 'Aktif';
    mysqli_query($conn, "UPDATE siswa SET status='$status' WHERE id=$id");
    $pesan = "Status siswa diubah menjadi $status.";
}
if (isset($_GET['hapus'])) {
    mysqli_query($conn, "DELETE FROM siswa WHERE id=" . (int)$_GET['hapus']);
    $pesan = 'Data siswa berhasil dihapus permanen.';
}

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM siswa WHERE id=" . (int)$_GET['edit']));
}

$filter_kelas = $_GET['kelas'] ?? '';
$where = $filter_kelas ? "WHERE s.kelas_id=" . (int)$filter_kelas : "WHERE s.status='Aktif'";
if ($filter_kelas === 'semua') $where = '1=1';

$list = mysqli_query($conn, "SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id $where ORDER BY k.tingkat, k.nama_kelas, s.nama");
$kelas_opt = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas");
$kelas_filter_opt = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Data Siswa</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3><?php echo $edit ? 'Edit Data Siswa' : 'Tambah Siswa Baru'; ?></h3>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $edit['id'] ?? ''; ?>">
        <div class="grid grid-3">
          <div class="form-group"><label>NIS</label><input type="text" name="nis" class="form-control" required value="<?php echo bersihkan($edit['nis'] ?? ''); ?>"></div>
          <div class="form-group"><label>NISN</label><input type="text" name="nisn" class="form-control" value="<?php echo bersihkan($edit['nisn'] ?? ''); ?>"></div>
          <div class="form-group"><label>NIK (Kependudukan)</label><input type="text" name="nik" class="form-control" value="<?php echo bersihkan($edit['nik'] ?? ''); ?>"></div>
          <div class="form-group"><label>Nama Lengkap</label><input type="text" name="nama" class="form-control" required value="<?php echo bersihkan($edit['nama'] ?? ''); ?>"></div>
          <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control">
              <option value="L" <?php echo (($edit['jenis_kelamin'] ?? '') == 'L') ? 'selected' : ''; ?>>Laki-laki</option>
              <option value="P" <?php echo (($edit['jenis_kelamin'] ?? '') == 'P') ? 'selected' : ''; ?>>Perempuan</option>
            </select>
          </div>
          <div class="form-group"><label>Tempat Lahir</label><input type="text" name="tempat_lahir" class="form-control" value="<?php echo bersihkan($edit['tempat_lahir'] ?? ''); ?>"></div>
          <div class="form-group"><label>Tanggal Lahir</label><input type="date" name="tanggal_lahir" class="form-control" value="<?php echo $edit['tanggal_lahir'] ?? ''; ?>"></div>
          <div class="form-group">
            <label>Kelas</label>
            <select name="kelas_id" class="form-control" required>
              <?php mysqli_data_seek($kelas_opt, 0); while ($k = mysqli_fetch_assoc($kelas_opt)): ?>
                <option value="<?php echo $k['id']; ?>" <?php echo (($edit['kelas_id'] ?? '') == $k['id']) ? 'selected' : ''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="form-group"><label>Nama Orang Tua/Wali</label><input type="text" name="nama_ortu" class="form-control" value="<?php echo bersihkan($edit['nama_ortu'] ?? ''); ?>"></div>
          <div class="form-group"><label>No. HP Orang Tua/Wali</label><input type="text" name="no_hp_ortu" class="form-control" value="<?php echo bersihkan($edit['no_hp_ortu'] ?? ''); ?>"></div>
          <div class="form-group" style="grid-column: span 3;">
            <label>Foto Profil (untuk kartu identitas)</label>
            <div style="display:flex; gap:14px; align-items:center; flex-wrap:wrap;">
              <div class="avatar-upload-preview"><?php $fu = url_foto_profil($edit['foto'] ?? null); echo $fu ? '<img src="'.$fu.'" alt="Foto">' : '<span class="upload-placeholder">Belum ada foto</span>'; ?></div>
              <div><input type="file" name="foto_siswa" accept="image/png,image/jpeg,image/webp" class="form-control"><div class="muted" style="margin-top:6px;">JPG/PNG/WEBP, otomatis diperkecil. Disarankan foto formal (portrait) latar polos.</div></div>
            </div>
          </div>
          <div class="form-group" style="grid-column: span 3;"><label>Alamat</label><input type="text" name="alamat" class="form-control" value="<?php echo bersihkan($edit['alamat'] ?? ''); ?>"></div>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $edit ? 'Simpan Perubahan' : '+ Tambah Siswa'; ?></button>
        <?php if ($edit): ?><a href="siswa.php" class="btn btn-outline">Batal</a><?php endif; ?>
      </form>
    </div>

    <div class="card">
      <div class="flex-between">
        <h3 class="mb-0">Daftar Siswa</h3>
        <form method="GET" style="display:flex; gap:8px;">
          <select name="kelas" class="form-control" onchange="this.form.submit()">
            <option value="">Semua Kelas Aktif</option>
            <option value="semua" <?php echo $filter_kelas==='semua'?'selected':''; ?>>Semua (termasuk Lulus/Pindah)</option>
            <?php mysqli_data_seek($kelas_filter_opt, 0); while ($k = mysqli_fetch_assoc($kelas_filter_opt)): ?>
              <option value="<?php echo $k['id']; ?>" <?php echo ($filter_kelas == $k['id']) ? 'selected' : ''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option>
            <?php endwhile; ?>
          </select>
        </form>
      </div>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Foto</th><th>NIS</th><th>Nama</th><th>L/P</th><th>Kelas</th><th>Orang Tua</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php while ($s = mysqli_fetch_assoc($list)): ?>
          <tr>
            <td><?php echo render_avatar($s['nama'], $s['foto'] ?? null); ?></td>
            <td><?php echo bersihkan($s['nis']); ?></td>
            <td><?php echo bersihkan($s['nama']); ?></td>
            <td><?php echo $s['jenis_kelamin']; ?></td>
            <td><?php echo bersihkan($s['nama_kelas'] ?: '-'); ?></td>
            <td><?php echo bersihkan($s['nama_ortu'] ?: '-'); ?></td>
            <td>
              <?php if ($s['status']==='Aktif'): ?><span class="badge-status badge-hadir">Aktif</span>
              <?php elseif($s['status']==='Lulus'): ?><span class="pill">Lulus</span>
              <?php else: ?><span class="badge-status badge-alpa"><?php echo $s['status']; ?></span><?php endif; ?>
            </td>
            <td>
              <a class="btn btn-outline btn-sm" href="?edit=<?php echo $s['id']; ?>">Edit</a>
              <a class="btn btn-outline btn-sm" href="cetak_kartu.php?siswa_id=<?php echo $s['id']; ?>" target="_blank">Kartu QR</a>
              <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $s['id']; ?>" onclick="return confirm('Hapus data siswa ini secara permanen? Semua riwayat absensi juga akan terhapus.');">Hapus</a>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
