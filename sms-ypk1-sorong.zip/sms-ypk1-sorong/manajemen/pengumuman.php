<?php
require_once __DIR__ . '/../config/session.php';
cek_login();
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Pengumuman';
$modul_aktif = 'manajemen';
$pesan = '';
$bisa_kelola = is_kepsek();

if ($bisa_kelola && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = bersihkan($_POST['judul']);
    $isi = bersihkan($_POST['isi']);
    $stmt = mysqli_prepare($conn, "INSERT INTO pengumuman (judul, isi, dibuat_oleh) VALUES (?,?,?)");
    mysqli_stmt_bind_param($stmt, 'ssi', $judul, $isi, $_SESSION['user_id']);
    mysqli_stmt_execute($stmt);
    $pesan = 'Pengumuman berhasil dipublikasikan.';
}
if ($bisa_kelola && isset($_GET['hapus'])) {
    mysqli_query($conn, "DELETE FROM pengumuman WHERE id=" . (int) $_GET['hapus']);
    $pesan = 'Pengumuman berhasil dihapus.';
}

$list = mysqli_query($conn, "SELECT * FROM pengumuman ORDER BY created_at DESC");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Pengumuman Sekolah</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <?php if ($bisa_kelola): ?>
    <div class="card">
      <h3>Buat Pengumuman Baru</h3>
      <form method="POST">
        <div class="form-group"><label>Judul</label><input type="text" name="judul" class="form-control" required></div>
        <div class="form-group"><label>Isi Pengumuman</label><textarea name="isi" class="form-control" rows="4" required></textarea></div>
        <button type="submit" class="btn btn-primary">📢 Publikasikan</button>
      </form>
    </div>
    <?php endif; ?>

    <div class="card">
      <h3>Semua Pengumuman</h3>
      <?php if (mysqli_num_rows($list) === 0): ?><p class="muted">Belum ada pengumuman.</p><?php endif; ?>
      <?php while ($p = mysqli_fetch_assoc($list)): ?>
        <div style="padding:14px 0; border-bottom:1px solid var(--border);">
          <div class="flex-between">
            <div style="font-weight:700; color:var(--navy);"><?php echo bersihkan($p['judul']); ?></div>
            <?php if ($bisa_kelola): ?><a class="btn btn-danger btn-sm" href="?hapus=<?php echo $p['id']; ?>" onclick="return confirm('Hapus pengumuman ini?');">Hapus</a><?php endif; ?>
          </div>
          <div style="margin:6px 0; white-space:pre-line;"><?php echo bersihkan($p['isi']); ?></div>
          <div class="muted" style="font-size:11.5px;"><?php echo format_tanggal_indo($p['created_at']); ?></div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
