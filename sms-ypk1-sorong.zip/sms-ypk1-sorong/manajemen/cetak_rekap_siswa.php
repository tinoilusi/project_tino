<?php
require_once __DIR__ . '/../config/session.php';
cek_login();
require_once __DIR__ . '/../includes/functions.php';

$role = $_SESSION['role'];
$kelas_id = (int) ($_GET['kelas_id'] ?? 0);
$bulan = $_GET['bulan'] ?? date('Y-m');

if ($role === 'guru') {
    $kelas_id = $_SESSION['kelas_id'] ?? 0; // wali kelas hanya boleh cetak kelasnya sendiri
}

if (!$kelas_id) { die('Kelas tidak ditemukan.'); }

$kelas = mysqli_fetch_assoc(mysqli_query($conn, "SELECT k.*, p.nama AS nama_wali FROM kelas k LEFT JOIN pegawai p ON p.id=k.wali_kelas_id WHERE k.id=$kelas_id"));
if (!$kelas) { die('Data kelas tidak ditemukan.'); }

$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$npsn = get_setting($conn, 'npsn') ?: '-';
$alamat = get_setting($conn, 'alamat_sekolah') ?: '-';
$logo_url = url_logo_sekolah($conn);
$kepsek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM pegawai WHERE jenis='Kepala Sekolah' LIMIT 1"));
$ta_aktif = tahun_ajaran_aktif($conn);

$bulan_nama_map = [1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'];
// jaga-jaga bila parameter bulan datang tidak lengkap/rusak (mis. hanya "2026" tanpa bulan)
if (!preg_match('/^\d{4}-\d{1,2}$/', (string) $bulan)) {
    $bulan = date('Y-m');
}
[$thn_f, $bln_f] = explode('-', $bulan);
$label_bulan = ($bulan_nama_map[(int)$bln_f] ?? '-') . ' ' . $thn_f;

$siswa_res = mysqli_query($conn, "SELECT id, nis, nama FROM siswa WHERE kelas_id=$kelas_id AND status='Aktif' ORDER BY nama");
$rekap = [];
$total_hadir=$total_terlambat=$total_sakit=$total_izin=$total_alpa=0;
while ($s = mysqli_fetch_assoc($siswa_res)) {
    $stat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT
        SUM(status='Hadir') AS hadir, SUM(status='Terlambat') AS terlambat,
        SUM(status='Sakit') AS sakit, SUM(status='Izin') AS izin, SUM(status='Alpa') AS alpa,
        COUNT(*) AS total
        FROM absensi_siswa WHERE siswa_id={$s['id']} AND DATE_FORMAT(tanggal,'%Y-%m')='" . mysqli_real_escape_string($conn,$bulan) . "'"));
    $r = array_merge($s, $stat);
    $rekap[] = $r;
    $total_hadir += (int)$r['hadir']; $total_terlambat += (int)$r['terlambat'];
    $total_sakit += (int)$r['sakit']; $total_izin += (int)$r['izin']; $total_alpa += (int)$r['alpa'];
}

// ambil catatan wali kelas jika laporan ini pernah dikirim resmi
$laporan_result = mysqli_query($conn, "SELECT * FROM laporan_bulanan WHERE kelas_id=$kelas_id AND bulan='" . mysqli_real_escape_string($conn,$bulan) . "'");
$laporan = $laporan_result ? mysqli_fetch_assoc($laporan_result) : null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rekap Absensi Siswa <?php echo bersihkan($kelas['nama_kelas']); ?> - <?php echo bersihkan($label_bulan); ?></title>
<style>
  @page{ size:A4; margin:18mm 16mm; }
  *{ box-sizing:border-box; }
  body{ font-family:'Segoe UI', Arial, sans-serif; color:#1a1a1a; font-size:12.5px; margin:0; padding:26px; background:#f2f3f5; }
  .sheet{ background:#fff; max-width:800px; margin:0 auto; padding:34px 40px; box-shadow:0 4px 22px rgba(0,0,0,0.12); }
  .kop{ display:flex; align-items:center; gap:16px; border-bottom:3px solid #0B3C5D; padding-bottom:14px; margin-bottom:6px; }
  .kop img{ width:64px; height:64px; object-fit:contain; }
  .kop .teks-kop{ flex:1; }
  .kop .nama-sekolah{ font-size:19px; font-weight:800; color:#0B3C5D; margin:0; letter-spacing:.2px; }
  .kop .sub{ font-size:11.5px; color:#444; margin:2px 0 0; line-height:1.5; }
  .garis-bawah{ border-bottom:1px solid #0B3C5D; margin-bottom:20px; }
  .judul-dokumen{ text-align:center; margin: 18px 0 22px; }
  .judul-dokumen h2{ margin:0; font-size:15.5px; text-transform:uppercase; letter-spacing:.4px; color:#0B3C5D; }
  .judul-dokumen .periode{ font-size:12.5px; color:#444; margin-top:4px; }
  .info-grid{ display:grid; grid-template-columns: 1fr 1fr; gap:4px 24px; margin-bottom:18px; font-size:12.5px; }
  .info-grid div span.label{ display:inline-block; width:110px; color:#555; }
  table{ width:100%; border-collapse:collapse; font-size:11.8px; margin-top:6px; }
  thead th{ background:#0B3C5D; color:#fff; padding:8px 6px; text-align:center; border:1px solid #0B3C5D; }
  tbody td{ padding:6px; border:1px solid #cfd6dc; text-align:center; }
  tbody td.nama-siswa{ text-align:left; }
  tfoot td{ padding:7px 6px; border:1px solid #cfd6dc; text-align:center; font-weight:700; background:#F3F5F7; }
  .catatan-box{ margin-top:20px; padding:12px 14px; background:#FFF9EC; border:1px solid #F0DFA6; border-radius:6px; font-size:12px; }
  .ttd-wrap{ display:flex; justify-content:space-between; margin-top:56px; font-size:12.5px; }
  .ttd-blok{ text-align:center; width:230px; }
  .ttd-blok .ruang-ttd{ height:64px; }
  .ttd-blok .nama-ttd{ font-weight:700; text-decoration:underline; }
  .tanggal-cetak{ text-align:right; font-size:12px; margin-top:8px; }
  .no-print{ margin-bottom:16px; text-align:center; }
  @media print{
    *{ -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; color-adjust:exact !important; }
    body{ background:#fff; padding:0; } .sheet{ box-shadow:none; max-width:100%; padding:0; } .no-print{ display:none; }
  }
</style>
</head>
<body>
<div class="no-print">
  <button onclick="window.print()" style="padding:10px 20px; background:#0B3C5D; color:#fff; border:none; border-radius:8px; font-weight:600; cursor:pointer;">🖨️ Cetak / Simpan sebagai PDF</button>
</div>

<div class="sheet">
  <div class="kop">
    <?php if ($logo_url): ?><img src="<?php echo $logo_url; ?>" alt="Logo"><?php endif; ?>
    <div class="teks-kop">
      <p class="nama-sekolah"><?php echo strtoupper(bersihkan($nama_sekolah)); ?></p>
      <p class="sub">NPSN: <?php echo bersihkan($npsn); ?> &nbsp;·&nbsp; <?php echo bersihkan($alamat); ?></p>
    </div>
  </div>
  <div class="garis-bawah"></div>

  <div class="judul-dokumen">
    <h2>Rekapitulasi Absensi Siswa</h2>
    <div class="periode">Kelas <?php echo bersihkan($kelas['nama_kelas']); ?> &nbsp;—&nbsp; Bulan <?php echo bersihkan($label_bulan); ?></div>
  </div>

  <div class="info-grid">
    <div><span class="label">Kelas</span>: <?php echo bersihkan($kelas['nama_kelas']); ?></div>
    <div><span class="label">Wali Kelas</span>: <?php echo bersihkan($kelas['nama_wali'] ?: '-'); ?></div>
    <div><span class="label">Tahun Ajaran</span>: <?php echo bersihkan(($ta_aktif['tahun'] ?? '-') . ' / ' . ($ta_aktif['semester'] ?? '-')); ?></div>
    <div><span class="label">Jumlah Siswa</span>: <?php echo count($rekap); ?> siswa</div>
  </div>

  <table>
    <thead>
      <tr><th style="width:32px;">No</th><th style="width:90px;">NIS</th><th>Nama Siswa</th><th style="width:52px;">Hadir</th><th style="width:58px;">Terlambat</th><th style="width:52px;">Sakit</th><th style="width:48px;">Izin</th><th style="width:48px;">Alpa</th><th style="width:60px;">% Hadir</th></tr>
    </thead>
    <tbody>
      <?php $no=1; foreach ($rekap as $r):
        $total = (int)$r['total']; $hadir_total = (int)$r['hadir'] + (int)$r['terlambat'];
        $pct = $total > 0 ? round($hadir_total/$total*100) : 0;
      ?>
      <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo bersihkan($r['nis']); ?></td>
        <td class="nama-siswa"><?php echo bersihkan($r['nama']); ?></td>
        <td><?php echo (int)$r['hadir']; ?></td>
        <td><?php echo (int)$r['terlambat']; ?></td>
        <td><?php echo (int)$r['sakit']; ?></td>
        <td><?php echo (int)$r['izin']; ?></td>
        <td><?php echo (int)$r['alpa']; ?></td>
        <td><?php echo $pct; ?>%</td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($rekap)): ?><tr><td colspan="9">Tidak ada data siswa aktif di kelas ini.</td></tr><?php endif; ?>
    </tbody>
    <tfoot>
      <tr><td colspan="3">JUMLAH TOTAL</td><td><?php echo $total_hadir; ?></td><td><?php echo $total_terlambat; ?></td><td><?php echo $total_sakit; ?></td><td><?php echo $total_izin; ?></td><td><?php echo $total_alpa; ?></td><td>-</td></tr>
    </tfoot>
  </table>

  <?php if ($laporan && $laporan['status'] === 'Sudah Dikirim' && $laporan['catatan_wali_kelas']): ?>
  <div class="catatan-box">
    <strong>Catatan Wali Kelas:</strong><br><?php echo nl2br(bersihkan($laporan['catatan_wali_kelas'])); ?>
  </div>
  <?php endif; ?>

  <div class="tanggal-cetak">Sorong, <?php echo format_tanggal_indo(date('Y-m-d')); ?></div>
  <div class="ttd-wrap">
    <div class="ttd-blok">
      <div>Wali Kelas <?php echo bersihkan($kelas['nama_kelas']); ?></div>
      <div class="ruang-ttd"></div>
      <div class="nama-ttd"><?php echo bersihkan($kelas['nama_wali'] ?: '(...........................)'); ?></div>
    </div>
    <div class="ttd-blok">
      <div>Mengetahui,<br>Kepala Sekolah</div>
      <div class="ruang-ttd"></div>
      <div class="nama-ttd"><?php echo bersihkan($kepsek['nama'] ?? '(...........................)'); ?></div>
    </div>
  </div>
</div>
</body>
</html>
