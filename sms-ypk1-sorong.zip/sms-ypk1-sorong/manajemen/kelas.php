<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Data Kelas';
$modul_aktif = 'manajemen';
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = bersihkan($_POST['nama_kelas']);
    $tingkat = (int) $_POST['tingkat'];
    $jurusan = bersihkan($_POST['jurusan']);
    $wali = $_POST['wali_kelas_id'] !== '' ? (int) $_POST['wali_kelas_id'] : null;
    $lanjut = $_POST['kelas_lanjutan_id'] !== '' ? (int) $_POST['kelas_lanjutan_id'] : null;

    if (!empty($_POST['id'])) {
        $id = (int) $_POST['id'];
        $stmt = mysqli_prepare($conn, "UPDATE kelas SET nama_kelas=?, tingkat=?, jurusan=?, wali_kelas_id=?, kelas_lanjutan_id=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, 'siiiii', $nama, $tingkat, $jurusan, $wali, $lanjut, $id);
        mysqli_stmt_execute($stmt);
        $pesan = 'Data kelas berhasil diperbarui.';
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO kelas (nama_kelas, tingkat, jurusan, wali_kelas_id, kelas_lanjutan_id) VALUES (?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'siiii', $nama, $tingkat, $jurusan, $wali, $lanjut);
        mysqli_stmt_execute($stmt);
        $pesan = 'Kelas baru berhasil ditambahkan.';
    }
}

if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    $jml = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM siswa WHERE kelas_id=$id"))['c'];
    if ($jml > 0) {
        $pesan = 'Kelas tidak dapat dihapus karena masih memiliki siswa aktif.';
    } else {
        mysqli_query($conn, "DELETE FROM kelas WHERE id=$id");
        $pesan = 'Kelas berhasil dihapus.';
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM kelas WHERE id=" . (int)$_GET['edit']));
}

$daftar_kelas = mysqli_query($conn, "SELECT k.*, w.nama AS nama_wali,
                                      (SELECT COUNT(*) FROM siswa s WHERE s.kelas_id=k.id AND s.status='Aktif') AS jml_siswa,
                                      kl.nama_kelas AS nama_lanjutan
                                      FROM kelas k
                                      LEFT JOIN pegawai w ON w.id = k.wali_kelas_id
                                      LEFT JOIN kelas kl ON kl.id = k.kelas_lanjutan_id
                                      ORDER BY k.tingkat, k.nama_kelas");
$daftar_guru = mysqli_query($conn, "SELECT id, nama FROM pegawai WHERE jenis='Guru' AND status_aktif=1 ORDER BY nama");
$semua_kelas = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Data Kelas</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3><?php echo $edit ? 'Edit Kelas' : 'Tambah Kelas Baru'; ?></h3>
      <form method="POST">
        <input type="hidden" name="id" value="<?php echo $edit['id'] ?? ''; ?>">
        <div class="grid grid-3">
          <div class="form-group">
            <label>Nama Kelas</label>
            <input type="text" name="nama_kelas" class="form-control" required value="<?php echo bersihkan($edit['nama_kelas'] ?? ''); ?>" placeholder="contoh: X, XI Sosial">
          </div>
          <div class="form-group">
            <label>Tingkat</label>
            <select name="tingkat" class="form-control" required>
              <?php foreach ([10,11,12] as $t): ?>
                <option value="<?php echo $t; ?>" <?php echo (($edit['tingkat'] ?? '') == $t) ? 'selected' : ''; ?>>Kelas <?php echo $t; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Jurusan (opsional)</label>
            <input type="text" name="jurusan" class="form-control" value="<?php echo bersihkan($edit['jurusan'] ?? ''); ?>" placeholder="contoh: Sosial, Kesehatan, IPA">
          </div>
          <div class="form-group">
            <label>Wali Kelas</label>
            <select name="wali_kelas_id" class="form-control">
              <option value="">— Pilih Wali Kelas —</option>
              <?php mysqli_data_seek($daftar_guru, 0); while ($g = mysqli_fetch_assoc($daftar_guru)): ?>
                <option value="<?php echo $g['id']; ?>" <?php echo (($edit['wali_kelas_id'] ?? '') == $g['id']) ? 'selected' : ''; ?>><?php echo bersihkan($g['nama']); ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Kelas Lanjutan (saat naik kelas)</label>
            <select name="kelas_lanjutan_id" class="form-control">
              <option value="">— Lulus / Tidak Ada —</option>
              <?php mysqli_data_seek($semua_kelas, 0); while ($kk = mysqli_fetch_assoc($semua_kelas)): if (($edit['id'] ?? 0) == $kk['id']) continue; ?>
                <option value="<?php echo $kk['id']; ?>" <?php echo (($edit['kelas_lanjutan_id'] ?? '') == $kk['id']) ? 'selected' : ''; ?>><?php echo bersihkan($kk['nama_kelas']); ?></option>
              <?php endwhile; ?>
            </select>
          </div>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $edit ? 'Simpan Perubahan' : '+ Tambah Kelas'; ?></button>
        <?php if ($edit): ?><a href="kelas.php" class="btn btn-outline">Batal</a><?php endif; ?>
      </form>
    </div>

    <div class="card">
      <h3>Daftar Kelas</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Nama Kelas</th><th>Tingkat</th><th>Jurusan</th><th>Wali Kelas</th><th>Jumlah Siswa</th><th>Naik ke</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php while ($k = mysqli_fetch_assoc($daftar_kelas)): ?>
          <tr>
            <td><strong><?php echo bersihkan($k['nama_kelas']); ?></strong></td>
            <td><?php echo $k['tingkat']; ?></td>
            <td><?php echo bersihkan($k['jurusan'] ?: '-'); ?></td>
            <td><?php echo bersihkan($k['nama_wali'] ?: '-'); ?></td>
            <td><?php echo $k['jml_siswa']; ?> siswa</td>
            <td><?php echo $k['nama_lanjutan'] ? bersihkan($k['nama_lanjutan']) : '<span class="pill">Lulus</span>'; ?></td>
            <td>
              <a class="btn btn-outline btn-sm" href="?edit=<?php echo $k['id']; ?>">Edit</a>
              <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $k['id']; ?>" onclick="return confirm('Hapus kelas ini?');">Hapus</a>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
