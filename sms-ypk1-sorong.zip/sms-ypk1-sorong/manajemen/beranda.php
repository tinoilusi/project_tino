<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/beranda_db.php';

$judul_halaman = 'Kelola Beranda';
$modul_aktif = 'manajemen';
$tab = [
  'hero'=>'Banner Utama','statistik'=>'Angka Statistik','tentang'=>'Tentang Sekolah','identitas'=>'Identitas Sekolah','visi'=>'Visi','misi'=>'Misi',
  'sejarah'=>'Sejarah','struktur'=>'Struktur Kabinet','info'=>'Informasi','kontak'=>'Kontak'
];
$seksi = $_GET['seksi'] ?? 'hero';
if (!isset($tab[$seksi])) $seksi = 'hero';
$pesan = ''; $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    if ($aksi === 'hapus') {
        $id = (int)$_POST['id'];
        $r = mysqli_fetch_assoc(mysqli_query($conn, "SELECT gambar FROM beranda_konten WHERE id=$id"));
        if ($r && $r['gambar'] && file_exists(path_upload_dir().$r['gambar'])) @unlink(path_upload_dir().$r['gambar']);
        mysqli_query($conn, "DELETE FROM beranda_konten WHERE id=$id");
        $pesan = 'Data berhasil dihapus.';
    } elseif ($aksi === 'simpan') {
        $id = (int)($_POST['id'] ?? 0);
        $judul = trim($_POST['judul'] ?? ''); $sub = trim($_POST['subjudul'] ?? '');
        $isi = trim($_POST['isi'] ?? ''); $level = max(1, min(9, (int)($_POST['level'] ?? 1)));
        $urutan = (int)($_POST['urutan'] ?? 0);
        $kel = ($seksi === 'struktur' && in_array($_POST['kelompok'] ?? '', ['guru','wali_kelas'], true)) ? $_POST['kelompok'] : null;
        $pegId = ($seksi === 'struktur' && !$kel && (int)($_POST['pegawai_id'] ?? 0) > 0) ? (int)$_POST['pegawai_id'] : null;
        $gbr = proses_upload_gambar('gambar', 'beranda', 1400, 1000);
        if ($judul === '') { $err = 'Judul wajib diisi.'; }
        elseif ($gbr === false) { $err = 'Gagal mengunggah gambar (JPG/PNG/WEBP, maks 8MB).'; }
        else {
            if ($id) {
                if ($gbr) {
                    $r = mysqli_fetch_assoc(mysqli_query($conn, "SELECT gambar FROM beranda_konten WHERE id=$id"));
                    if ($r && $r['gambar'] && file_exists(path_upload_dir().$r['gambar'])) @unlink(path_upload_dir().$r['gambar']);
                    $st = mysqli_prepare($conn, "UPDATE beranda_konten SET judul=?,subjudul=?,isi=?,level=?,urutan=?,gambar=?,pegawai_id=?,kelompok=? WHERE id=? AND seksi=?");
                    mysqli_stmt_bind_param($st, 'sssiisisis', $judul, $sub, $isi, $level, $urutan, $gbr, $pegId, $kel, $id, $seksi);
                } else {
                    $st = mysqli_prepare($conn, "UPDATE beranda_konten SET judul=?,subjudul=?,isi=?,level=?,urutan=?,pegawai_id=?,kelompok=? WHERE id=? AND seksi=?");
                    mysqli_stmt_bind_param($st, 'sssiiisis', $judul, $sub, $isi, $level, $urutan, $pegId, $kel, $id, $seksi);
                }
            } else {
                $g = $gbr ?: null;
                $st = mysqli_prepare($conn, "INSERT INTO beranda_konten (seksi,judul,subjudul,isi,level,urutan,gambar,pegawai_id,kelompok) VALUES (?,?,?,?,?,?,?,?,?)");
                mysqli_stmt_bind_param($st, 'ssssiisis', $seksi, $judul, $sub, $isi, $level, $urutan, $g, $pegId, $kel);
            }
            mysqli_stmt_execute($st);
            $pesan = 'Perubahan berhasil disimpan dan langsung tampil di beranda.';
        }
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM beranda_konten WHERE id=".(int)$_GET['edit']." AND seksi='".mysqli_real_escape_string($conn,$seksi)."'"));
}
$list = mysqli_query($conn, "SELECT * FROM beranda_konten WHERE seksi='".mysqli_real_escape_string($conn,$seksi)."' ORDER BY urutan, id");

$daftarPeg = ($seksi === 'struktur') ? mysqli_query($conn, "SELECT id,nama,jenis,nip_nuptk FROM pegawai WHERE status_aktif=1 ORDER BY FIELD(jenis,'Kepala Sekolah','Tata Usaha','Guru','Penjaga Sekolah'), nama") : null;

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Kelola Beranda Publik</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>
    <?php if ($err): ?><div class="alert alert-error"><?php echo bersihkan($err); ?></div><?php endif; ?>

    <div class="card">
      <div class="flex-between" style="flex-wrap:wrap;gap:8px;">
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
          <?php foreach ($tab as $k => $v): ?>
            <a class="btn btn-sm <?php echo $k === $seksi ? 'btn-primary' : 'btn-secondary'; ?>" href="?seksi=<?php echo $k; ?>"><?php echo $v; ?></a>
          <?php endforeach; ?>
        </div>
        <a class="btn btn-sm btn-primary" href="<?php echo BASE_URL; ?>index.php" target="_blank">👁 Lihat Beranda</a>
      </div>
    </div>

    <?php if ($seksi === 'hero'): ?>
    <div class="card" style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;">
      <?php if ($lb = url_logo_beranda($conn)): ?><img src="<?php echo $lb; ?>" alt="" style="width:64px;height:64px;object-fit:contain;border-radius:50%;"><?php endif; ?>
      <div style="flex:1;min-width:220px;"><b>Logo di jendela banner</b><div class="muted" style="font-size:12.5px;">Diganti dari Pengaturan Sekolah, dan tidak mengubah logo di navbar maupun sidebar.</div></div>
      <a class="btn btn-sm btn-primary" href="<?php echo BASE_URL; ?>manajemen/pengaturan.php">Ganti Logo Jendela</a>
    </div>
    <?php endif; ?>

    <div class="card">
      <p class="muted" style="margin-bottom:10px">Tips: tulis <code>{siswa}</code> <code>{guru}</code> <code>{pegawai}</code> <code>{kelas}</code> <code>{tahun}</code> <code>{npsn}</code> <code>{email}</code> <code>{alamat}</code> agar angka otomatis mengikuti basis data.</p>
      <h3><?php echo $edit ? 'Ubah' : 'Tambah'; ?> — <?php echo $tab[$seksi]; ?></h3>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="aksi" value="simpan">
        <input type="hidden" name="id" value="<?php echo $edit['id'] ?? 0; ?>">
        <div class="form-group"><label>Judul / Jabatan</label><input type="text" name="judul" class="form-control" required value="<?php echo bersihkan($edit['judul'] ?? ''); ?>"></div>
        <div class="form-group"><label>Sub judul / Nama pejabat / Tahun / Angka</label><input type="text" name="subjudul" class="form-control" value="<?php echo bersihkan($edit['subjudul'] ?? ''); ?>"></div>
        <div class="form-group"><label>Isi / Deskripsi</label><textarea name="isi" class="form-control" rows="4"><?php echo bersihkan($edit['isi'] ?? ''); ?></textarea></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;">
          <?php if ($seksi === 'struktur'): ?>
          <div class="form-group" style="grid-column:1/-1;"><label>Isi otomatis dari Data Guru &amp; Staf</label>
            <select name="kelompok" class="form-control">
              <?php $kv = $edit['kelompok'] ?? ''; ?>
              <option value="" <?php echo $kv==='' ? 'selected' : ''; ?>>Kartu tunggal (pilih pegawai di bawah, atau kartu lembaga)</option>
              <option value="guru" <?php echo $kv==='guru' ? 'selected' : ''; ?>>Tampilkan SEMUA guru (dengan foto &amp; NIP/NUPTK)</option>
              <option value="wali_kelas" <?php echo $kv==='wali_kelas' ? 'selected' : ''; ?>>Tampilkan semua wali kelas (dari menu Data Kelas)</option>
            </select>
            <div class="muted" style="font-size:12px;margin-top:4px;">Judul dipakai sebagai nama kelompok. Guru baru / perubahan foto &amp; NIP di menu Data Guru &amp; Staf otomatis ikut tampil.</div>
          </div>
          <div class="form-group" style="grid-column:1/-1;"><label>Tautkan ke satu pegawai (foto, nama &amp; NIP/NUPTK otomatis)</label>
            <select name="pegawai_id" class="form-control">
              <option value="0">— Tidak ditautkan (kartu lembaga) —</option>
              <?php while ($pg = mysqli_fetch_assoc($daftarPeg)): ?>
              <option value="<?php echo (int)$pg['id']; ?>" <?php echo ((int)($edit['pegawai_id'] ?? 0) === (int)$pg['id']) ? 'selected' : ''; ?>><?php echo bersihkan($pg['nama'].' — '.$pg['jenis'].($pg['nip_nuptk'] ? ' · '.$pg['nip_nuptk'] : '')); ?></option>
              <?php endwhile; ?>
            </select>
            <div class="muted" style="font-size:12px;margin-top:4px;">Judul = jabatan. Bila ditautkan, nama diambil dari data pegawai (Sub judul diabaikan). Foto diubah di menu Data Guru &amp; Staf.</div>
          </div>
          <div class="form-group"><label>Tingkat (1 = paling atas)</label><input type="number" min="1" max="9" name="level" class="form-control" value="<?php echo (int)($edit['level'] ?? 1); ?>"></div>
          <?php endif; ?>
          <div class="form-group"><label>Urutan tampil</label><input type="number" name="urutan" class="form-control" value="<?php echo (int)($edit['urutan'] ?? 100); ?>"></div>
          <div class="form-group"><label>Foto (opsional)</label><input type="file" name="gambar" accept="image/*" class="form-control"></div>
        </div>
        <button type="submit" class="btn btn-primary">💾 Simpan</button>
        <?php if ($edit): ?><a class="btn btn-secondary" href="?seksi=<?php echo $seksi; ?>">Batal</a><?php endif; ?>
      </form>
    </div>

    <div class="card">
      <h3>Daftar Data</h3>
      <?php if (mysqli_num_rows($list) === 0): ?><p class="muted">Belum ada data.</p><?php endif; ?>
      <?php while ($r = mysqli_fetch_assoc($list)): ?>
        <div style="padding:12px 0;border-bottom:1px solid var(--border);">
          <div class="flex-between" style="gap:10px;">
            <div>
              <div style="font-weight:700;color:var(--navy);"><?php echo bersihkan($r['judul']); ?><?php if ($seksi === 'struktur'): ?> <span class="muted">· Tingkat <?php echo (int)$r['level']; ?><?php echo !empty($r['kelompok']) ? ' · otomatis: '.($r['kelompok']==='guru' ? 'semua guru' : 'wali kelas') : (!empty($r['pegawai_id']) ? ' · tertaut ke data pegawai' : ''); ?></span><?php endif; ?></div>
              <?php if ($r['subjudul']): ?><div class="muted" style="font-size:12.5px;"><?php echo bersihkan($r['subjudul']); ?></div><?php endif; ?>
              <?php if ($r['isi']): ?><div style="font-size:13px;margin-top:4px;"><?php echo bersihkan(mb_strimwidth($r['isi'], 0, 140, '…')); ?></div><?php endif; ?>
            </div>
            <div style="white-space:nowrap;display:flex;gap:6px;">
              <a class="btn btn-sm btn-secondary" href="?seksi=<?php echo $seksi; ?>&edit=<?php echo $r['id']; ?>">Ubah</a>
              <form method="POST" onsubmit="return confirm('Hapus data ini dari beranda?');" style="display:inline;">
                <input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?php echo $r['id']; ?>">
                <button class="btn btn-danger btn-sm">Hapus</button>
              </form>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
