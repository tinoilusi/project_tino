<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Pengaturan Sekolah';
$modul_aktif = 'manajemen';
$pesan = '';
$pesan_error = '';

$keys = ['nama_sekolah','npsn','alamat_sekolah','email_sekolah','naungan_yayasan','jam_masuk','jam_pulang','toleransi_terlambat_menit','pulang_buka_menit_sebelum','jam_batas_alpa'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($keys as $k) {
        if (isset($_POST[$k])) {
            set_setting($conn, $k, bersihkan($_POST[$k]));
        }
    }

    // upload logo (diperkecil otomatis maks 500x500 agar rapi di sidebar/kartu)
    $logo_baru = proses_upload_gambar('logo_sekolah', 'logo', 500, 500);
    if ($logo_baru === false) {
        $pesan_error = 'Gagal mengunggah logo. Pastikan file adalah gambar (JPG/PNG/WEBP) dan ukuran maksimal 8MB.';
    } elseif ($logo_baru) {
        $lama = get_setting($conn, 'logo_sekolah');
        hapus_logo_bulat($lama);
        if ($lama && file_exists(path_upload_dir() . $lama)) @unlink(path_upload_dir() . $lama);
        set_setting($conn, 'logo_sekolah', $logo_baru);
    }

    // upload logo KHUSUS jendela beranda publik (tidak mengubah logo navbar/sidebar/login)
    $lb_baru = proses_upload_gambar('logo_beranda', 'logo_beranda', 800, 800);
    if ($lb_baru === false) {
        $pesan_error = trim(($pesan_error ? $pesan_error . ' ' : '') . 'Gagal mengunggah logo beranda. Pastikan file adalah gambar (JPG/PNG/WEBP) dan ukuran maksimal 8MB.');
    } elseif ($lb_baru) {
        $lama = get_setting($conn, 'logo_beranda');
        hapus_logo_bulat($lama);
        if ($lama && file_exists(path_upload_dir() . $lama)) @unlink(path_upload_dir() . $lama);
        set_setting($conn, 'logo_beranda', $lb_baru);
    }

    // upload background (diperkecil otomatis maks 1920x1080 agar tidak berat & tetap rapi)
    $bg_baru = proses_upload_gambar('background_sekolah', 'bg', 1920, 1080);
    if ($bg_baru === false) {
        $pesan_error = trim(($pesan_error ? $pesan_error . ' ' : '') . 'Gagal mengunggah gambar latar belakang. Pastikan file adalah gambar (JPG/PNG/WEBP) dan ukuran maksimal 8MB.');
    } elseif ($bg_baru) {
        $lama = get_setting($conn, 'background_sekolah');
        if ($lama && file_exists(path_upload_dir() . $lama)) @unlink(path_upload_dir() . $lama);
        set_setting($conn, 'background_sekolah', $bg_baru);
    }

    if (!$pesan_error) $pesan = 'Pengaturan berhasil disimpan.';
}

if (isset($_GET['hapus_logo'])) {
    $lama = get_setting($conn, 'logo_sekolah');
    hapus_logo_bulat($lama);
    if ($lama && file_exists(path_upload_dir() . $lama)) @unlink(path_upload_dir() . $lama);
    set_setting($conn, 'logo_sekolah', '');
    $pesan = 'Logo sekolah dihapus, kembali ke tampilan default.';
}
if (isset($_GET['hapus_logo_beranda'])) {
    $lama = get_setting($conn, 'logo_beranda');
    hapus_logo_bulat($lama);
    if ($lama && file_exists(path_upload_dir() . $lama)) @unlink(path_upload_dir() . $lama);
    set_setting($conn, 'logo_beranda', '');
    $pesan = 'Logo jendela beranda dihapus. Jendela kembali memakai logo sekolah.';
}
if (isset($_GET['hapus_bg'])) {
    $lama = get_setting($conn, 'background_sekolah');
    if ($lama && file_exists(path_upload_dir() . $lama)) @unlink(path_upload_dir() . $lama);
    set_setting($conn, 'background_sekolah', '');
    $pesan = 'Gambar latar belakang dihapus, kembali ke tampilan default.';
}

$val = [];
foreach ($keys as $k) $val[$k] = get_setting($conn, $k);
$logo_url = url_logo_sekolah($conn);
$bg_url = url_background_sekolah($conn);
$lb_url = url_logo_beranda($conn);
$lb_khusus = logo_beranda_khusus_ada($conn);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Pengaturan Sekolah</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>
    <?php if ($pesan_error): ?><div class="alert alert-error"><?php echo $pesan_error; ?></div><?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <div class="card">
        <h3>🖼️ Identitas Visual Sekolah</h3>
        <p class="muted">Unggah logo dan gambar latar belakang agar tampilan sistem lebih profesional dan estetik. Logo ini tampil di bagian atas beranda (navbar), sidebar, halaman login, kartu QR, dan lembar cetak resmi. Latar belakang akan tampil di halaman login &amp; menu utama.</p>
        <div class="grid grid-2">
          <div>
            <label style="font-weight:600; font-size:13px; display:block; margin-bottom:8px;">Logo Sekolah</label>
            <div class="upload-preview">
              <?php if ($logo_url): ?>
                <img src="<?php echo $logo_url; ?>" alt="Logo Sekolah">
              <?php else: ?>
                <div class="upload-placeholder">Belum ada logo</div>
              <?php endif; ?>
            </div>
            <input type="file" name="logo_sekolah" accept="image/png,image/jpeg,image/webp" class="form-control" style="margin-top:10px;">
            <div class="muted" style="margin-top:6px;">Disarankan gambar persegi, latar transparan (PNG). Otomatis diperkecil ke maks 500x500px. Ukuran file maks 8MB.</div>
            <?php if ($logo_url): ?><a href="?hapus_logo=1" class="btn btn-outline btn-sm" style="margin-top:8px;" onclick="return confirm('Hapus logo sekolah?');">🗑️ Hapus Logo</a><?php endif; ?>
          </div>
          <div>
            <label style="font-weight:600; font-size:13px; display:block; margin-bottom:8px;">Gambar Latar Belakang (Login &amp; Menu Utama)</label>
            <div class="upload-preview upload-preview-wide">
              <?php if ($bg_url): ?>
                <img src="<?php echo $bg_url; ?>" alt="Latar Belakang Sekolah">
              <?php else: ?>
                <div class="upload-placeholder">Belum ada gambar latar</div>
              <?php endif; ?>
            </div>
            <input type="file" name="background_sekolah" accept="image/png,image/jpeg,image/webp" class="form-control" style="margin-top:10px;">
            <div class="muted" style="margin-top:6px;">Disarankan foto gedung/lingkungan sekolah, orientasi landscape. Otomatis diperkecil ke maks 1920x1080px. Ukuran file maks 8MB.</div>
            <?php if ($bg_url): ?><a href="?hapus_bg=1" class="btn btn-outline btn-sm" style="margin-top:8px;" onclick="return confirm('Hapus gambar latar belakang?');">🗑️ Hapus Latar Belakang</a><?php endif; ?>
          </div>
        </div>
      </div>

      <div class="card">
        <h3>🪟 Logo Jendela Beranda Publik</h3>
        <p class="muted">Logo besar di kartu/jendela pada banner beranda publik. Diatur <b>terpisah</b>: mengganti logo ini <b>tidak</b> mengubah logo sekolah di bagian atas beranda, sidebar, halaman login, maupun kartu QR. Jika belum diunggah, jendela memakai logo sekolah.</p>
        <div class="grid grid-2">
          <div>
            <div class="upload-preview">
              <?php if ($lb_url): ?><img src="<?php echo $lb_url; ?>" alt="Logo Jendela Beranda"><?php else: ?><div class="upload-placeholder">Belum ada logo</div><?php endif; ?>
            </div>
            <div class="muted" style="margin-top:6px;"><?php echo $lb_khusus ? 'Memakai logo khusus jendela.' : ($lb_url ? 'Sementara memakai logo sekolah.' : ''); ?></div>
          </div>
          <div>
            <label style="font-weight:600; font-size:13px; display:block; margin-bottom:8px;">Ganti Logo Jendela</label>
            <input type="file" name="logo_beranda" accept="image/png,image/jpeg,image/webp" class="form-control">
            <div class="muted" style="margin-top:6px;">Disarankan gambar persegi (PNG). Otomatis diperkecil ke maks 800x800px. Ukuran file maks 8MB. Klik <b>Simpan Semua Pengaturan</b> di bawah setelah memilih file.</div>
            <?php if ($lb_khusus): ?><a href="?hapus_logo_beranda=1" class="btn btn-outline btn-sm" style="margin-top:8px;" onclick="return confirm('Hapus logo jendela? Jendela akan memakai logo sekolah.');">🗑️ Hapus Logo Jendela</a><?php endif; ?>
            <a href="<?php echo BASE_URL; ?>index.php" target="_blank" class="btn btn-secondary btn-sm" style="margin-top:8px;">👁 Lihat Beranda</a>
          </div>
        </div>
      </div>

      <div class="card">
        <h3>Identitas Sekolah</h3>
        <div class="grid grid-2">
          <div class="form-group"><label>Nama Sekolah</label><input type="text" name="nama_sekolah" class="form-control" value="<?php echo bersihkan($val['nama_sekolah']); ?>"></div>
          <div class="form-group"><label>NPSN</label><input type="text" name="npsn" class="form-control" value="<?php echo bersihkan($val['npsn']); ?>"></div>
          <div class="form-group" style="grid-column: span 2;"><label>Alamat Sekolah</label><input type="text" name="alamat_sekolah" class="form-control" value="<?php echo bersihkan($val['alamat_sekolah']); ?>"></div>
          <div class="form-group"><label>Email Sekolah</label><input type="email" name="email_sekolah" class="form-control" value="<?php echo bersihkan($val['email_sekolah']); ?>"></div>
          <div class="form-group"><label>Naungan Yayasan</label><input type="text" name="naungan_yayasan" class="form-control" value="<?php echo bersihkan($val['naungan_yayasan']); ?>"></div>
        </div>
      </div>

      <div class="card">
        <h3>Pengaturan Jam Absensi (WIT)</h3>
        <p class="muted">Jam ini digunakan otomatis oleh sistem untuk menentukan status <b>Hadir</b> atau <b>Terlambat</b> saat scan QR Code masuk sekolah.</p>
        <div class="grid grid-2">
          <div class="form-group"><label>Jam Masuk Sekolah</label><input type="time" name="jam_masuk" class="form-control" value="<?php echo substr($val['jam_masuk'],0,5); ?>" required></div>
          <div class="form-group"><label>Jam Pulang Sekolah</label><input type="time" name="jam_pulang" class="form-control" value="<?php echo substr($val['jam_pulang'],0,5); ?>" required></div>
          <div class="form-group"><label>Toleransi Terlambat (menit)</label><input type="number" name="toleransi_terlambat_menit" class="form-control" value="<?php echo bersihkan($val['toleransi_terlambat_menit']); ?>" min="0" max="60"></div>
          <div class="form-group"><label>Absen pulang dibuka (menit sebelum jam pulang)</label><input type="number" name="pulang_buka_menit_sebelum" class="form-control" value="<?php echo bersihkan($val['pulang_buka_menit_sebelum'] ?? '0'); ?>" min="0" max="120"><div class="muted" style="margin-top:4px;">0 = baru bisa scan pulang tepat jam pulang. Scan sebelum itu ditolak (tidak dobel).</div></div>
          <div class="form-group">
            <label>Batas Otomatis Tandai Alpa</label>
            <input type="time" name="jam_batas_alpa" class="form-control" value="<?php echo substr($val['jam_batas_alpa'] ?: '14:00:00',0,5); ?>" required>
            <div class="muted" style="margin-top:4px;">Siswa/guru/staf yang sampai jam ini <b>sama sekali</b> belum ada catatan absensi (tidak scan QR, tidak diinput manual) akan otomatis ditandai <b>Alpa</b>. Kalau ternyata datang setelahnya, scan QR tetap bisa mengubahnya jadi Hadir/Terlambat.</div>
          </div>
        </div>
      </div>

      <button type="submit" class="btn btn-primary">💾 Simpan Semua Pengaturan</button>
    </form>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
