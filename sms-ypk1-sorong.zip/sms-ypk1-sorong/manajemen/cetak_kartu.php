<?php
require_once __DIR__ . '/../config/session.php';
cek_login();
require_once __DIR__ . '/../includes/functions.php';

$role = $_SESSION['role'];
$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$npsn = get_setting($conn, 'npsn') ?: '-';
$logo_url = url_logo_sekolah($conn);
$ta = tahun_ajaran_aktif($conn);

$items = []; // nama, id_label, sub, token, foto, tipe

function tambah_siswa(&$items, $s) {
    $items[] = ['nama'=>$s['nama'], 'id_label'=>'NIS: '.$s['nis'], 'sub'=>'Kelas '.($s['nama_kelas'] ?? '-'), 'token'=>$s['qr_token'], 'foto'=>$s['foto'] ?? null, 'tipe'=>'SISWA'];
}
function tambah_pegawai(&$items, $p) {
    $id = $p['nip_nuptk'] ? 'NIP/NUPTK: '.$p['nip_nuptk'] : 'ID: PEG-'.str_pad($p['id'], 3, '0', STR_PAD_LEFT);
    $items[] = ['nama'=>$p['nama'], 'id_label'=>$id, 'sub'=>$p['jenis'], 'token'=>$p['qr_token'], 'foto'=>$p['foto'] ?? null, 'tipe'=>strtoupper($p['jenis'] === 'Guru' || $p['jenis']==='Kepala Sekolah' ? 'GURU / STAF' : 'STAF')];
}

if (isset($_GET['siswa_id']) && $role === 'kepala_sekolah') {
    $r = mysqli_query($conn, "SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id WHERE s.id=" . (int)$_GET['siswa_id']);
    if ($r && $s = mysqli_fetch_assoc($r)) tambah_siswa($items, $s);
} elseif (isset($_GET['pegawai_id']) && $role === 'kepala_sekolah') {
    $r = mysqli_query($conn, "SELECT * FROM pegawai WHERE id=" . (int)$_GET['pegawai_id']);
    if ($r && $p = mysqli_fetch_assoc($r)) tambah_pegawai($items, $p);
} elseif (($_GET['semua_pegawai'] ?? '') === '1' && $role === 'kepala_sekolah') {
    $r = mysqli_query($conn, "SELECT * FROM pegawai WHERE status_aktif=1 ORDER BY FIELD(jenis,'Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'), nama");
    while ($r && $p = mysqli_fetch_assoc($r)) tambah_pegawai($items, $p);
} elseif (isset($_GET['kelas_id'])) {
    $kelas_id = (int) $_GET['kelas_id'];
    if ($role === 'guru') $kelas_id = (int) ($_SESSION['kelas_id'] ?? 0);
    $r = mysqli_query($conn, "SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id WHERE s.kelas_id=$kelas_id AND s.status='Aktif' ORDER BY s.nama");
    while ($r && $s = mysqli_fetch_assoc($r)) tambah_siswa($items, $s);
}

$kelas_list = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas " . ($role === 'guru' ? "WHERE id=" . (int)($_SESSION['kelas_id'] ?? 0) : "") . " ORDER BY tingkat");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cetak Kartu Identitas QR</title>
<link rel="stylesheet" href="<?php echo aset('assets/css/style.css'); ?>">
<script src="<?php echo BASE_URL; ?>assets/js/qrcode.min.js"></script>
<style>
  @page{ size:A4; margin:10mm; }
  .kartu-area{ display:flex; flex-wrap:wrap; gap:6mm; justify-content:center; margin-top:18px; }
  .id-card{
    width:60mm; height:96mm; background:#fff; border:0.4mm solid #0B3C5D; border-radius:4mm;
    box-sizing:border-box; position:relative; overflow:hidden; page-break-inside:avoid; break-inside:avoid;
    display:flex; flex-direction:column; align-items:center; font-family:'Segoe UI',Arial,sans-serif;
  }
  .id-card .slot{ flex-shrink:0; width:14mm; height:2.4mm; border-radius:2mm; background:#e5e7eb; border:0.3mm solid #b8bec6; margin:1.8mm 0 1.3mm; }
  .id-card .head{ flex-shrink:0; width:100%; box-sizing:border-box; background:#0B3C5D; color:#fff; padding:1.6mm 2mm 1.8mm; display:flex; align-items:center; gap:2mm; }
  .id-card .head img{ width:9mm; height:9mm; object-fit:contain; background:none; border-radius:50%; padding:0; flex-shrink:0; }
  .id-card .head .t1{ font-size:2.5mm; font-weight:800; line-height:1.15; text-transform:uppercase; }
  .id-card .head .t2{ font-size:1.9mm; opacity:.85; margin-top:0.3mm; }
  .id-card .gold{ flex-shrink:0; width:100%; height:1mm; background:#C9A24B; }
  .id-card .tipe{ flex-shrink:0; margin-top:1.5mm; font-size:2.2mm; font-weight:800; letter-spacing:.4mm; color:#0B3C5D; }
  .id-card .foto{ flex-shrink:0; width:22mm; height:26mm; margin-top:1.3mm; border:0.5mm solid #0B3C5D; border-radius:2mm; overflow:hidden; background:#EEF2F6; display:flex; align-items:center; justify-content:center; }
  .id-card .foto img{ width:100%; height:100%; object-fit:cover; }
  .id-card .foto span{ font-size:8mm; font-weight:800; color:#0B3C5D; }
  .id-card .nama{ flex-shrink:0; margin-top:1.5mm; padding:0 3mm; text-align:center; font-size:3mm; font-weight:800; color:#111; line-height:1.15; max-height:7mm; overflow:hidden; }
  .id-card .idno{ flex-shrink:0; font-size:2.4mm; color:#333; margin-top:0.6mm; }
  .id-card .sub{ flex-shrink:0; font-size:2.4mm; color:#0B3C5D; font-weight:700; }
  .id-card .qr{
    flex-shrink:0; margin-top:1.3mm; width:19mm; height:19mm; padding:0.8mm; box-sizing:content-box;
    background:#fff; border-radius:1mm; display:flex; align-items:center; justify-content:center; overflow:hidden;
  }
  .id-card .qr canvas, .id-card .qr img{
    width:19mm !important; height:19mm !important; display:block;
    image-rendering:-webkit-optimize-contrast; image-rendering:crisp-edges;
  }
  .id-card .foot{ flex-shrink:0; margin-top:auto; width:100%; box-sizing:border-box; background:#0B3C5D; color:#fff; text-align:center; font-size:1.9mm; line-height:1.3; padding:1mm 1mm; }
  @media print{
    *{ -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; color-adjust:exact !important; }
    .no-print{ display:none !important; } body{ background:#fff; } .kartu-area{ margin-top:0; }
  }
</style>
</head>
<body>
<div style="padding:20px;">
  <div class="no-print card">
    <h3>🪪 Cetak Kartu Identitas QR (Kalung / Lanyard)</h3>
    <form method="GET" style="display:flex; gap:10px; align-items:end; flex-wrap:wrap;">
      <div class="form-group mb-0">
        <label>Cetak Siswa per Kelas</label>
        <select name="kelas_id" class="form-control">
          <option value="">— Pilih Kelas —</option>
          <?php while ($k = mysqli_fetch_assoc($kelas_list)): ?>
            <option value="<?php echo $k['id']; ?>" <?php echo (isset($_GET['kelas_id']) && $_GET['kelas_id']==$k['id']) ? 'selected':''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <button type="submit" class="btn btn-primary">Tampilkan</button>
      <?php if ($role === 'kepala_sekolah'): ?><a href="?semua_pegawai=1" class="btn btn-outline">Semua Guru &amp; Staf</a><?php endif; ?>
      <?php if (count($items) > 0): ?><button type="button" class="btn btn-gold" onclick="window.print()">🖨️ Cetak Semua (<?php echo count($items); ?> kartu)</button><?php endif; ?>
      <a href="<?php echo BASE_URL; ?>home.php" class="btn btn-outline">Kembali</a>
    </form>
    <p class="muted" style="margin:10px 0 0;">Tips cetak: pilih kertas A4, skala 100%, aktifkan "Background graphics". Ukuran kartu 60×96 mm (muat 6 kartu per lembar). Lubangi pada tanda slot di atas kartu untuk tali lanyard. Laminasi agar awet.</p>
  </div>

  <?php if (empty($items)): ?>
    <p class="muted no-print">Pilih kelas di atas, atau buka halaman ini lewat tombol "Kartu QR" pada Data Siswa / Data Guru &amp; Staf.</p>
  <?php else: ?>
  <div class="kartu-area">
    <?php foreach ($items as $i => $it): $foto = url_foto_profil($it['foto']); ?>
      <div class="id-card">
        <div class="slot"></div>
        <div class="head">
          <?php if ($logo_url): ?><img src="<?php echo $logo_url; ?>" alt=""><?php endif; ?>
          <div><div class="t1"><?php echo bersihkan($nama_sekolah); ?></div><div class="t2">NPSN <?php echo bersihkan($npsn); ?><?php echo $ta ? ' · TA '.bersihkan($ta['tahun']) : ''; ?></div></div>
        </div>
        <div class="gold"></div>
        <div class="tipe">KARTU <?php echo bersihkan($it['tipe']); ?></div>
        <div class="foto"><?php echo $foto ? '<img src="'.$foto.'" alt="">' : '<span>'.bersihkan(mb_strtoupper(mb_substr($it['nama'],0,1))).'</span>'; ?></div>
        <div class="nama"><?php echo bersihkan($it['nama']); ?></div>
        <div class="idno"><?php echo bersihkan($it['id_label']); ?></div>
        <div class="sub"><?php echo bersihkan($it['sub']); ?></div>
        <div class="qr" id="qr-<?php echo $i; ?>"></div>
        <div class="foot">Kartu absensi resmi · Scan QR saat masuk &amp; pulang</div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<script>
// Render tiap QR pada resolusi tinggi (360px) lalu ditampilkan pada ukuran cetak 19mm via CSS,
// supaya kotak-kotak QR tetap tajam (tidak buram/berantakan) saat di-scale untuk cetak.
<?php foreach ($items as $i => $it): ?>
new QRCode(document.getElementById('qr-<?php echo $i; ?>'), {
  text: <?php echo json_encode($it['token']); ?>,
  width: 360,
  height: 360,
  correctLevel: QRCode.CorrectLevel.H
});
<?php endforeach; ?>
</script>
</body>
</html>
