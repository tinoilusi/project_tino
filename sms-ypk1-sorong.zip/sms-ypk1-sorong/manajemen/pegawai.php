<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Data Guru & Staf';
$modul_aktif = 'manajemen';
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nip = bersihkan($_POST['nip_nuptk']);
    $nama = bersihkan($_POST['nama']);
    $jenis = $_POST['jenis'];
    $status_pegawai = $_POST['status_kepegawaian'] === 'PNS' ? 'PNS' : 'Honorer';
    $jk = $_POST['jenis_kelamin'] === 'P' ? 'P' : 'L';
    $hp = bersihkan($_POST['no_hp']);
    $alamat = bersihkan($_POST['alamat']);

    $foto_baru = proses_upload_gambar('foto_pegawai', 'pegawai_foto', 500, 600);
    if ($foto_baru === false) { $pesan = 'Gagal mengunggah foto. Pastikan file gambar (JPG/PNG/WEBP) maks 8MB.'; }

    if (!empty($_POST['id'])) {
        $id = (int) $_POST['id'];
        if ($foto_baru) {
            $lama = mysqli_fetch_assoc(mysqli_query($conn, "SELECT foto FROM pegawai WHERE id=$id"))['foto'] ?? null;
            if ($lama && file_exists(path_upload_dir() . $lama)) @unlink(path_upload_dir() . $lama);
            $stmt = mysqli_prepare($conn, "UPDATE pegawai SET nip_nuptk=?, nama=?, jenis=?, status_kepegawaian=?, jenis_kelamin=?, no_hp=?, alamat=?, foto=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'ssssssssi', $nip, $nama, $jenis, $status_pegawai, $jk, $hp, $alamat, $foto_baru, $id);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE pegawai SET nip_nuptk=?, nama=?, jenis=?, status_kepegawaian=?, jenis_kelamin=?, no_hp=?, alamat=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'sssssssi', $nip, $nama, $jenis, $status_pegawai, $jk, $hp, $alamat, $id);
        }
        mysqli_stmt_execute($stmt);
        if (!$pesan) $pesan = 'Data pegawai berhasil diperbarui.';
    } else {
        $token = generate_token('PEG', 6);
        $stmt = mysqli_prepare($conn, "INSERT INTO pegawai (nip_nuptk, nama, jenis, status_kepegawaian, jenis_kelamin, no_hp, alamat, foto, qr_token) VALUES (?,?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'sssssssss', $nip, $nama, $jenis, $status_pegawai, $jk, $hp, $alamat, $foto_baru, $token);
        mysqli_stmt_execute($stmt);
        if (!$pesan) $pesan = 'Pegawai baru berhasil ditambahkan. Kode QR otomatis dibuat.';
    }
}

if (isset($_GET['nonaktifkan'])) {
    $id = (int) $_GET['nonaktifkan'];
    mysqli_query($conn, "UPDATE pegawai SET status_aktif = 1 - status_aktif WHERE id=$id");
    $pesan = 'Status aktif pegawai diperbarui.';
}
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    $jenis_cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT jenis FROM pegawai WHERE id=$id"))['jenis'] ?? '';
    if ($jenis_cek === 'Kepala Sekolah') {
        $pesan = 'Data Kepala Sekolah tidak dapat dihapus.';
    } else {
        mysqli_query($conn, "DELETE FROM pegawai WHERE id=$id");
        $pesan = 'Data pegawai berhasil dihapus.';
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pegawai WHERE id=" . (int)$_GET['edit']));
}

$filter_jenis = $_GET['jenis'] ?? '';
$where = $filter_jenis ? "WHERE jenis='" . mysqli_real_escape_string($conn, $filter_jenis) . "'" : '';
$list = mysqli_query($conn, "SELECT * FROM pegawai $where ORDER BY FIELD(jenis,'Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'), nama");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Data Guru &amp; Staf</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3><?php echo $edit ? 'Edit Data Pegawai' : 'Tambah Pegawai Baru'; ?></h3>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $edit['id'] ?? ''; ?>">
        <div class="grid grid-3">
          <div class="form-group"><label>NIP / NUPTK</label><input type="text" name="nip_nuptk" class="form-control" value="<?php echo bersihkan($edit['nip_nuptk'] ?? ''); ?>"></div>
          <div class="form-group"><label>Nama Lengkap</label><input type="text" name="nama" class="form-control" required value="<?php echo bersihkan($edit['nama'] ?? ''); ?>"></div>
          <div class="form-group">
            <label>Jenis Pegawai</label>
            <select name="jenis" class="form-control" required <?php echo (($edit['jenis'] ?? '')==='Kepala Sekolah') ? 'disabled':''; ?>>
              <?php foreach (['Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'] as $j): ?>
                <option value="<?php echo $j; ?>" <?php echo (($edit['jenis'] ?? '') == $j) ? 'selected' : ''; ?>><?php echo $j; ?></option>
              <?php endforeach; ?>
            </select>
            <?php if (($edit['jenis'] ?? '')==='Kepala Sekolah'): ?><input type="hidden" name="jenis" value="Kepala Sekolah"><?php endif; ?>
          </div>
          <div class="form-group">
            <label>Status Kepegawaian</label>
            <select name="status_kepegawaian" class="form-control">
              <option value="PNS" <?php echo (($edit['status_kepegawaian'] ?? '') == 'PNS') ? 'selected' : ''; ?>>PNS</option>
              <option value="Honorer" <?php echo (($edit['status_kepegawaian'] ?? 'Honorer') == 'Honorer') ? 'selected' : ''; ?>>Honorer</option>
            </select>
          </div>
          <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control">
              <option value="L" <?php echo (($edit['jenis_kelamin'] ?? '') == 'L') ? 'selected' : ''; ?>>Laki-laki</option>
              <option value="P" <?php echo (($edit['jenis_kelamin'] ?? '') == 'P') ? 'selected' : ''; ?>>Perempuan</option>
            </select>
          </div>
          <div class="form-group"><label>No. HP</label><input type="text" name="no_hp" class="form-control" value="<?php echo bersihkan($edit['no_hp'] ?? ''); ?>"></div>
          <div class="form-group"><label>Alamat</label><input type="text" name="alamat" class="form-control" value="<?php echo bersihkan($edit['alamat'] ?? ''); ?>"></div>
          <div class="form-group" style="grid-column: span 3;">
            <label>Foto Profil (untuk kartu identitas)</label>
            <div style="display:flex; gap:14px; align-items:center; flex-wrap:wrap;">
              <div class="avatar-upload-preview"><?php $fu = url_foto_profil($edit['foto'] ?? null); echo $fu ? '<img src="'.$fu.'" alt="Foto">' : '<span class="upload-placeholder">Belum ada foto</span>'; ?></div>
              <div><input type="file" name="foto_pegawai" accept="image/png,image/jpeg,image/webp" class="form-control"><div class="muted" style="margin-top:6px;">JPG/PNG/WEBP, otomatis diperkecil. Disarankan foto formal (portrait).</div></div>
            </div>
          </div>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $edit ? 'Simpan Perubahan' : '+ Tambah Pegawai'; ?></button>
        <?php if ($edit): ?><a href="pegawai.php" class="btn btn-outline">Batal</a><?php endif; ?>
      </form>
    </div>

    <div class="card">
      <div class="flex-between">
        <h3 class="mb-0">Daftar Guru &amp; Staf (14 Pengurus Sekolah)</h3>
        <form method="GET">
          <select name="jenis" class="form-control" onchange="this.form.submit()">
            <option value="">Semua Jenis</option>
            <?php foreach (['Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'] as $j): ?>
              <option value="<?php echo $j; ?>" <?php echo $filter_jenis===$j?'selected':''; ?>><?php echo $j; ?></option>
            <?php endforeach; ?>
          </select>
        </form>
      </div>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Foto</th><th>Nama</th><th>NIP/NUPTK</th><th>Jenis</th><th>Status Kepegawaian</th><th>No HP</th><th>Aktif</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php while ($p = mysqli_fetch_assoc($list)): ?>
          <tr>
            <td><?php echo render_avatar($p['nama'], $p['foto'] ?? null); ?></td>
            <td><?php echo bersihkan($p['nama']); ?></td>
            <td><?php echo bersihkan($p['nip_nuptk'] ?: '-'); ?></td>
            <td><span class="pill"><?php echo $p['jenis']; ?></span></td>
            <td><?php echo $p['status_kepegawaian']; ?></td>
            <td><?php echo bersihkan($p['no_hp'] ?: '-'); ?></td>
            <td><?php echo $p['status_aktif'] ? '<span class="badge-status badge-hadir">Aktif</span>' : '<span class="badge-status badge-alpa">Nonaktif</span>'; ?></td>
            <td>
              <a class="btn btn-outline btn-sm" href="?edit=<?php echo $p['id']; ?>">Edit</a>
              <a class="btn btn-outline btn-sm" href="cetak_kartu.php?pegawai_id=<?php echo $p['id']; ?>" target="_blank">Kartu QR</a>
              <a class="btn btn-outline btn-sm" href="?nonaktifkan=<?php echo $p['id']; ?>"><?php echo $p['status_aktif'] ? 'Nonaktifkan' : 'Aktifkan'; ?></a>
              <?php if ($p['jenis'] !== 'Kepala Sekolah'): ?>
              <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $p['id']; ?>" onclick="return confirm('Hapus data pegawai ini?');">Hapus</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
