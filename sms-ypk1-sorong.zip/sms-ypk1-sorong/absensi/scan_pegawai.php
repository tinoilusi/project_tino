<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Scan Absen Guru & Staf';
$modul_aktif = 'absensi';

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Scan Absen Guru, Tata Usaha &amp; Penjaga Sekolah</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <div class="card">
      <p class="muted mb-0">Absensi guru, tata usaha, dan penjaga sekolah dipegang langsung oleh Kepala Sekolah. Arahkan kamera ke kartu QR pegawai.</p>
    </div>

    <div id="kontrolSuara"></div>

    <div class="scan-wrap">
      <div class="scan-camera">
        <div id="qr-reader"></div>
        <div class="card" style="margin-top:14px;">
          <label style="font-weight:600; font-size:13px;">Kamera tidak berfungsi? Ketik kode QR / token manual lalu tekan Enter:</label>
          <input type="text" id="input-manual" class="form-control" placeholder="Contoh: PEG-GURU-002" style="margin-top:8px;">
        </div>
      </div>
      <div class="scan-result" id="hasilScan">
        <div class="big-icon">📷</div>
        <div class="nama">Menunggu Scan...</div>
        <div class="info">Arahkan kartu QR ke kamera</div>
      </div>
    </div>

    <div class="card">
      <h3>Log Scan Sesi Ini</h3>
      <div class="scan-log" id="logScan"></div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>

<script src="<?php echo BASE_URL; ?>assets/js/html5-qrcode.min.js"></script>
<script src="<?php echo aset('assets/js/scanner.js'); ?>"></script>
<script>
  const BASE_URL_JS = <?php echo json_encode(BASE_URL); ?>;
  pasangKontrolSuara('kontrolSuara');
  mulaiScanner('qr-reader', 'pegawai', BASE_URL_JS, 'hasilScan', 'logScan');
  pasangInputManual('input-manual', 'pegawai', BASE_URL_JS, 'hasilScan', 'logScan');
</script>
