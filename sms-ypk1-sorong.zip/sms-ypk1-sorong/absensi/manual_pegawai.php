<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Input Manual Absensi Guru & Staf';
$modul_aktif = 'absensi';
$pesan = '';

$tanggal = $_GET['tanggal'] ?? $_POST['tanggal'] ?? date('Y-m-d');
$filter_jenis = $_GET['jenis'] ?? $_POST['jenis'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $tanggal_post = bersihkan($_POST['tanggal']);
    $status_arr = $_POST['status'] ?? [];
    $ket_arr = $_POST['keterangan'] ?? [];

    foreach ($status_arr as $pegawai_id => $status) {
        $pegawai_id = (int) $pegawai_id;
        if (!in_array($status, ['Hadir','Sakit','Izin','Alpa','Terlambat'])) continue;
        $ket = bersihkan($ket_arr[$pegawai_id] ?? '');

        // bukti surat sakit / surat tugas kegiatan (opsional, per pegawai) - gambar atau PDF
        $bukti_baru = proses_upload_dokumen('bukti_' . $pegawai_id, 'bukti_pegawai_' . $pegawai_id);

        $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id, bukti FROM absensi_pegawai WHERE pegawai_id=$pegawai_id AND tanggal='$tanggal_post'"));
        if ($cek) {
            if ($bukti_baru) {
                if ($cek['bukti'] && file_exists(path_upload_dir() . $cek['bukti'])) @unlink(path_upload_dir() . $cek['bukti']);
                $stmt = mysqli_prepare($conn, "UPDATE absensi_pegawai SET status=?, metode='Manual', keterangan=?, bukti=?, input_by=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, 'sssii', $status, $ket, $bukti_baru, $_SESSION['user_id'], $cek['id']);
            } else {
                $stmt = mysqli_prepare($conn, "UPDATE absensi_pegawai SET status=?, metode='Manual', keterangan=?, input_by=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, 'ssii', $status, $ket, $_SESSION['user_id'], $cek['id']);
            }
            mysqli_stmt_execute($stmt);
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO absensi_pegawai (pegawai_id, tanggal, status, metode, keterangan, bukti, input_by) VALUES (?,?,?,'Manual',?,?,?)");
            mysqli_stmt_bind_param($stmt, 'issssi', $pegawai_id, $tanggal_post, $status, $ket, $bukti_baru, $_SESSION['user_id']);
            mysqli_stmt_execute($stmt);
        }
    }
    $pesan = 'Absensi manual berhasil disimpan untuk tanggal ' . format_tanggal_indo($tanggal_post) . '.';
    $tanggal = $tanggal_post;
}

$where_jenis = $filter_jenis ? "AND jenis='" . mysqli_real_escape_string($conn, $filter_jenis) . "'" : '';
$peg_list = mysqli_query($conn, "SELECT p.*, a.status AS status_ada, a.keterangan AS ket_ada, a.bukti AS bukti_ada FROM pegawai p
                                  LEFT JOIN absensi_pegawai a ON a.pegawai_id=p.id AND a.tanggal='" . mysqli_real_escape_string($conn,$tanggal) . "'
                                  WHERE p.status_aktif=1 $where_jenis
                                  ORDER BY FIELD(p.jenis,'Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'), p.nama");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Input Manual Absensi Guru &amp; Staf</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <form method="GET" class="grid grid-3" style="align-items:end;">
        <div class="form-group mb-0">
          <label>Tanggal</label>
          <input type="date" name="tanggal" class="form-control" value="<?php echo bersihkan($tanggal); ?>" onchange="this.form.submit()">
        </div>
        <div class="form-group mb-0">
          <label>Jenis Pegawai</label>
          <select name="jenis" class="form-control" onchange="this.form.submit()">
            <option value="">Semua Jenis</option>
            <?php foreach (['Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'] as $j): ?>
              <option value="<?php echo $j; ?>" <?php echo $filter_jenis===$j?'selected':''; ?>><?php echo $j; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </form>
    </div>

    <div class="card">
      <h3>Daftar Guru &amp; Staf — <?php echo format_tanggal_indo($tanggal); ?></h3>
      <p class="muted">Dipakai untuk mencatat guru/staf yang <b>Sakit</b>, <b>Izin</b> (dinas, acara keluarga, dll), atau <b>Alpa</b> tanpa scan QR. Lampirkan bukti surat bila ada — opsional, format JPG/PNG/PDF maks 8MB.</p>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="tanggal" value="<?php echo bersihkan($tanggal); ?>">
        <input type="hidden" name="jenis" value="<?php echo bersihkan($filter_jenis); ?>">
        <div class="table-wrap">
        <table>
          <thead><tr><th>Nama</th><th>Jenis</th><th>Status</th><th>Keterangan</th><th>Bukti Surat</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($peg_list) === 0): ?><tr><td colspan="5" class="muted" style="text-align:center; padding:20px;">Tidak ada pegawai aktif untuk filter ini.</td></tr><?php endif; ?>
          <?php while ($p = mysqli_fetch_assoc($peg_list)): ?>
            <tr>
              <td><?php echo bersihkan($p['nama']); ?></td>
              <td><span class="pill"><?php echo bersihkan($p['jenis']); ?></span></td>
              <td>
                <select name="status[<?php echo $p['id']; ?>]" class="form-control">
                  <?php foreach (['Hadir','Terlambat','Sakit','Izin','Alpa'] as $st): ?>
                    <option value="<?php echo $st; ?>" <?php echo ($p['status_ada']===$st) ? 'selected' : ''; ?>><?php echo $st; ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td><input type="text" name="keterangan[<?php echo $p['id']; ?>]" class="form-control" value="<?php echo bersihkan($p['ket_ada'] ?? ''); ?>" placeholder="opsional"></td>
              <td>
                <input type="file" name="bukti_<?php echo $p['id']; ?>" class="form-control" accept="image/*,application/pdf" style="font-size:12px;">
                <?php if (!empty($p['bukti_ada'])): ?>
                  <a href="<?php echo BASE_URL . 'assets/img/uploads/' . $p['bukti_ada']; ?>" target="_blank" class="pill" style="margin-top:4px; display:inline-block;">📎 Lihat bukti saat ini</a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        </div>
        <button type="submit" name="simpan" value="1" class="btn btn-primary" style="margin-top:14px;">💾 Simpan Absensi</button>
      </form>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
