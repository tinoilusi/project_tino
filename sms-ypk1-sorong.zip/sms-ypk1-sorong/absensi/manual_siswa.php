<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['guru','kepala_sekolah']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Input Manual Absensi Siswa';
$modul_aktif = 'absensi';
$role = $_SESSION['role'];
$pesan = '';

if ($role === 'guru') {
    $kelas_id = $_SESSION['kelas_id'] ?? 0;
} else {
    $kelas_id = (int) ($_GET['kelas_id'] ?? $_POST['kelas_id'] ?? 0);
}

$tanggal = $_GET['tanggal'] ?? $_POST['tanggal'] ?? date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $tanggal_post = bersihkan($_POST['tanggal']);
    $status_arr = $_POST['status'] ?? [];
    $ket_arr = $_POST['keterangan'] ?? [];
    $ta = tahun_ajaran_aktif($conn);
    $ta_id = $ta['id'] ?? null;

    foreach ($status_arr as $siswa_id => $status) {
        $siswa_id = (int) $siswa_id;
        if (!in_array($status, ['Hadir','Sakit','Izin','Alpa','Terlambat'])) continue;
        $ket = bersihkan($ket_arr[$siswa_id] ?? '');

        // bukti surat sakit / surat izin kegiatan (opsional, per siswa) - gambar atau PDF
        $bukti_baru = proses_upload_dokumen('bukti_' . $siswa_id, 'bukti_siswa_' . $siswa_id);

        $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id, bukti FROM absensi_siswa WHERE siswa_id=$siswa_id AND tanggal='$tanggal_post'"));
        if ($cek) {
            if ($bukti_baru) { // ganti bukti lama kalau ada file baru diunggah
                if ($cek['bukti'] && file_exists(path_upload_dir() . $cek['bukti'])) @unlink(path_upload_dir() . $cek['bukti']);
                $stmt = mysqli_prepare($conn, "UPDATE absensi_siswa SET status=?, metode='Manual', keterangan=?, bukti=?, input_by=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, 'sssii', $status, $ket, $bukti_baru, $_SESSION['user_id'], $cek['id']);
            } else {
                $stmt = mysqli_prepare($conn, "UPDATE absensi_siswa SET status=?, metode='Manual', keterangan=?, input_by=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, 'ssii', $status, $ket, $_SESSION['user_id'], $cek['id']);
            }
            mysqli_stmt_execute($stmt);
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO absensi_siswa (siswa_id, tahun_ajaran_id, tanggal, status, metode, keterangan, bukti, input_by) VALUES (?,?,?,?,'Manual',?,?,?)");
            mysqli_stmt_bind_param($stmt, 'iissssi', $siswa_id, $ta_id, $tanggal_post, $status, $ket, $bukti_baru, $_SESSION['user_id']);
            mysqli_stmt_execute($stmt);
        }
    }
    $pesan = 'Absensi manual berhasil disimpan untuk tanggal ' . format_tanggal_indo($tanggal_post) . '.';
    $tanggal = $tanggal_post;
}

$kelas_list = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat");
$siswa_list = $kelas_id ? mysqli_query($conn, "SELECT s.*, a.status AS status_ada, a.keterangan AS ket_ada, a.bukti AS bukti_ada FROM siswa s
                                                LEFT JOIN absensi_siswa a ON a.siswa_id=s.id AND a.tanggal='" . mysqli_real_escape_string($conn,$tanggal) . "'
                                                WHERE s.kelas_id=$kelas_id AND s.status='Aktif' ORDER BY s.nama") : null;

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Input Manual Absensi Siswa</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <form method="GET" class="grid grid-3" style="align-items:end;">
        <?php if ($role === 'kepala_sekolah'): ?>
        <div class="form-group mb-0">
          <label>Kelas</label>
          <select name="kelas_id" class="form-control" onchange="this.form.submit()">
            <option value="">— Pilih Kelas —</option>
            <?php while ($k = mysqli_fetch_assoc($kelas_list)): ?>
              <option value="<?php echo $k['id']; ?>" <?php echo $kelas_id==$k['id']?'selected':''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <?php endif; ?>
        <div class="form-group mb-0">
          <label>Tanggal</label>
          <input type="date" name="tanggal" class="form-control" value="<?php echo bersihkan($tanggal); ?>" onchange="this.form.submit()">
        </div>
      </form>
    </div>

    <?php if ($kelas_id && $siswa_list): ?>
    <div class="card">
      <h3>Daftar Siswa — <?php echo format_tanggal_indo($tanggal); ?></h3>
      <p class="muted">Untuk status <b>Sakit</b> atau <b>Izin</b>, Anda bisa melampirkan bukti (foto surat sakit dari dokter, atau surat izin kegiatan) — opsional, format JPG/PNG/PDF maks 8MB.</p>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="kelas_id" value="<?php echo $kelas_id; ?>">
        <input type="hidden" name="tanggal" value="<?php echo bersihkan($tanggal); ?>">
        <div class="table-wrap">
        <table>
          <thead><tr><th>Nama</th><th>Status</th><th>Keterangan</th><th>Bukti Surat</th></tr></thead>
          <tbody>
          <?php while ($s = mysqli_fetch_assoc($siswa_list)): ?>
            <tr>
              <td><?php echo bersihkan($s['nama']); ?></td>
              <td>
                <select name="status[<?php echo $s['id']; ?>]" class="form-control">
                  <?php foreach (['Hadir','Terlambat','Sakit','Izin','Alpa'] as $st): ?>
                    <option value="<?php echo $st; ?>" <?php echo ($s['status_ada']===$st) ? 'selected' : ''; ?>><?php echo $st; ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td><input type="text" name="keterangan[<?php echo $s['id']; ?>]" class="form-control" value="<?php echo bersihkan($s['ket_ada'] ?? ''); ?>" placeholder="opsional"></td>
              <td>
                <input type="file" name="bukti_<?php echo $s['id']; ?>" class="form-control" accept="image/*,application/pdf" style="font-size:12px;">
                <?php if (!empty($s['bukti_ada'])): ?>
                  <a href="<?php echo BASE_URL . 'assets/img/uploads/' . $s['bukti_ada']; ?>" target="_blank" class="pill" style="margin-top:4px; display:inline-block;">📎 Lihat bukti saat ini</a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        </div>
        <button type="submit" name="simpan" value="1" class="btn btn-primary" style="margin-top:14px;">💾 Simpan Absensi</button>
      </form>
    </div>
    <?php elseif($kelas_id): ?>
      <p class="muted">Tidak ada siswa aktif di kelas ini.</p>
    <?php else: ?>
      <p class="muted">Silakan pilih kelas terlebih dahulu.</p>
    <?php endif; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
