<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'guru']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Pulang Awal & Sekolah Dipulangkan';
$modul_aktif = 'absensi';
$role = $_SESSION['role'];
$hari_ini = date('Y-m-d');
$sekarang = date('H:i:s');
$pesan = ''; $pesan_error = '';
$alasan_opsi = ['Sakit mendadak', 'Urusan keluarga', 'Dijemput orang tua/wali', 'Keperluan dinas/kegiatan', 'Lainnya'];

$kelas_id = $role === 'guru' ? (int)($_SESSION['kelas_id'] ?? 0) : (int)($_GET['kelas_id'] ?? $_POST['kelas_id'] ?? 0);

// ---------- (Kepsek) Sekolah dipulangkan mendadak ----------
if ($role === 'kepala_sekolah' && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'pulangkan_sekolah') {
    $jam = preg_match('/^\d{2}:\d{2}$/', $_POST['jam'] ?? '') ? $_POST['jam'] . ':00' : $sekarang;
    $alasan = trim($_POST['alasan'] ?? '');
    if ($alasan === '') {
        $pesan_error = 'Alasan wajib diisi (contoh: cuaca buruk, duka cita, rapat dinas mendadak).';
    } else {
        set_setting($conn, 'pulang_khusus_tanggal', $hari_ini);
        set_setting($conn, 'pulang_khusus_jam', $jam);
        set_setting($conn, 'pulang_khusus_alasan', $alasan);
        set_setting($conn, 'pulang_khusus_dibuat', date('Y-m-d H:i:s'));
        $n1 = $n2 = 0;
        if (!empty($_POST['tandai_otomatis'])) {
            $ket = 'Sekolah dipulangkan mendadak: ' . $alasan;
            $st = mysqli_prepare($conn, "UPDATE absensi_siswa SET jam_pulang=?, jenis_pulang='Dipulangkan Sekolah', keterangan=? WHERE tanggal=? AND jam_masuk IS NOT NULL AND jam_pulang IS NULL");
            mysqli_stmt_bind_param($st, 'sss', $jam, $ket, $hari_ini); mysqli_stmt_execute($st); $n1 = mysqli_stmt_affected_rows($st);
            $st = mysqli_prepare($conn, "UPDATE absensi_pegawai SET jam_pulang=?, jenis_pulang='Dipulangkan Sekolah', keterangan=? WHERE tanggal=? AND jam_masuk IS NOT NULL AND jam_pulang IS NULL");
            mysqli_stmt_bind_param($st, 'sss', $jam, $ket, $hari_ini); mysqli_stmt_execute($st); $n2 = mysqli_stmt_affected_rows($st);
        }
        $pesan = 'Pengumuman sekolah dipulangkan mendadak pukul ' . substr($jam, 0, 5) . ' aktif untuk hari ini.'
               . (!empty($_POST['tandai_otomatis']) ? " Otomatis ditandai pulang: $n1 siswa dan $n2 guru/staf." : ' Siswa & guru/staf bisa langsung scan QR pulang.');
    }
}
if ($role === 'kepala_sekolah' && isset($_GET['batalkan_pulang_mendadak'])) {
    set_setting($conn, 'pulang_khusus_tanggal', '');
    $pesan = 'Pengumuman pulang mendadak dibatalkan. Absen pulang kembali mengikuti jam normal.';
}

// ---------- Izin pulang awal (per orang) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['aksi'] ?? '', ['pulang_awal_siswa', 'pulang_awal_pegawai'], true)) {
    $ids = array_map('intval', $_POST['ids'] ?? []);
    $alasan = $_POST['alasan_opsi'] ?? 'Lainnya';
    if (!in_array($alasan, $alasan_opsi, true)) $alasan = 'Lainnya';
    $ket_tambahan = trim($_POST['keterangan'] ?? '');
    $ket = 'Izin pulang awal: ' . $alasan . ($ket_tambahan !== '' ? ' - ' . $ket_tambahan : '');
    $n = 0;
    if (!$ids) {
        $pesan_error = 'Pilih minimal satu orang.';
    } elseif ($_POST['aksi'] === 'pulang_awal_siswa') {
        foreach ($ids as $sid) {
            // guru hanya boleh untuk siswa kelasnya sendiri
            $cek = mysqli_query($conn, "SELECT a.id FROM absensi_siswa a JOIN siswa s ON s.id=a.siswa_id WHERE a.siswa_id=$sid AND a.tanggal='$hari_ini' AND a.jam_masuk IS NOT NULL AND a.jam_pulang IS NULL" . ($role === 'guru' ? " AND s.kelas_id=" . (int)$_SESSION['kelas_id'] : ''));
            if ($cek && $r = mysqli_fetch_assoc($cek)) {
                $st = mysqli_prepare($conn, "UPDATE absensi_siswa SET jam_pulang=?, jenis_pulang='Izin Pulang Awal', keterangan=?, input_by=? WHERE id=?");
                mysqli_stmt_bind_param($st, 'ssii', $sekarang, $ket, $_SESSION['user_id'], $r['id']); mysqli_stmt_execute($st); $n++;
            }
        }
        $pesan = "$n siswa dicatat izin pulang awal pukul " . substr($sekarang, 0, 5) . '.';
    } elseif ($role === 'kepala_sekolah') {
        foreach ($ids as $pid) {
            $cek = mysqli_query($conn, "SELECT id FROM absensi_pegawai WHERE pegawai_id=$pid AND tanggal='$hari_ini' AND jam_masuk IS NOT NULL AND jam_pulang IS NULL");
            if ($cek && $r = mysqli_fetch_assoc($cek)) {
                $st = mysqli_prepare($conn, "UPDATE absensi_pegawai SET jam_pulang=?, jenis_pulang='Izin Pulang Awal', keterangan=?, input_by=? WHERE id=?");
                mysqli_stmt_bind_param($st, 'ssii', $sekarang, $ket, $_SESSION['user_id'], $r['id']); mysqli_stmt_execute($st); $n++;
            }
        }
        $pesan = "$n guru/staf dicatat izin pulang awal pukul " . substr($sekarang, 0, 5) . '.';
    }
}

$khusus = pulang_khusus_hari_ini($conn);
$kelas_list = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat");

$siswa_belum = [];
if ($kelas_id) {
    $r = mysqli_query($conn, "SELECT s.id, s.nama, a.jam_masuk FROM absensi_siswa a JOIN siswa s ON s.id=a.siswa_id WHERE s.kelas_id=$kelas_id AND a.tanggal='$hari_ini' AND a.jam_masuk IS NOT NULL AND a.jam_pulang IS NULL ORDER BY s.nama");
    while ($r && $x = mysqli_fetch_assoc($r)) $siswa_belum[] = $x;
}
$pegawai_belum = [];
if ($role === 'kepala_sekolah') {
    $r = mysqli_query($conn, "SELECT p.id, p.nama, p.jenis, a.jam_masuk FROM absensi_pegawai a JOIN pegawai p ON p.id=a.pegawai_id WHERE a.tanggal='$hari_ini' AND a.jam_masuk IS NOT NULL AND a.jam_pulang IS NULL ORDER BY p.nama");
    while ($r && $x = mysqli_fetch_assoc($r)) $pegawai_belum[] = $x;
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';

function form_alasan($alasan_opsi) { ?>
  <div class="grid grid-2" style="margin:12px 0;">
    <div class="form-group mb-0"><label>Alasan</label>
      <select name="alasan_opsi" class="form-control"><?php foreach ($alasan_opsi as $a) echo '<option>' . htmlspecialchars($a) . '</option>'; ?></select></div>
    <div class="form-group mb-0"><label>Keterangan tambahan (opsional)</label>
      <input type="text" name="keterangan" class="form-control" placeholder="contoh: dijemput ayah pukul 10.00"></div>
  </div>
<?php } ?>
<main class="main-content">
  <div class="topbar"><h2>Pulang Awal &amp; Sekolah Dipulangkan</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo bersihkan($pesan); ?></div><?php endif; ?>
    <?php if ($pesan_error): ?><div class="alert alert-error"><?php echo bersihkan($pesan_error); ?></div><?php endif; ?>

    <div class="card">
      <h3>ℹ️ Cara kerja absen pulang</h3>
      <p class="muted mb-0">Scan pertama = <b>masuk</b>. Scan berikutnya sebelum pukul <b><?php echo substr(jam_buka_pulang($conn), 0, 5); ?></b> <b>tidak akan tercatat pulang</b> (tidak ada absen ganda) — sistem hanya memberi tahu kapan pulang dibuka. Jika ada yang perlu pulang lebih awal, catat di halaman ini agar keterangannya resmi tercatat; jika sekolah dipulangkan mendadak, Kepala Sekolah mengaktifkannya dan semua orang bisa langsung scan pulang.</p>
    </div>

    <?php if ($role === 'kepala_sekolah'): ?>
    <div class="card" style="border-left:5px solid var(--gold);">
      <h3>🏫 Sekolah Dipulangkan Mendadak</h3>
      <?php if ($khusus): ?>
        <div class="alert alert-success">📢 <b>Aktif hari ini:</b> sekolah dipulangkan mulai pukul <?php echo substr($khusus['jam'], 0, 5); ?> — <?php echo bersihkan($khusus['alasan']); ?>
          &nbsp;<a href="?batalkan_pulang_mendadak=1" class="btn btn-outline btn-sm" onclick="return confirm('Batalkan pengumuman pulang mendadak?');">Batalkan</a></div>
      <?php endif; ?>
      <form method="POST" onsubmit="return confirm('Umumkan sekolah dipulangkan mendadak sekarang?');">
        <input type="hidden" name="aksi" value="pulangkan_sekolah">
        <div class="grid grid-3" style="align-items:end;">
          <div class="form-group mb-0"><label>Jam pulang</label><input type="time" name="jam" class="form-control" value="<?php echo date('H:i'); ?>" required></div>
          <div class="form-group mb-0" style="grid-column: span 2;"><label>Alasan (wajib)</label><input type="text" name="alasan" class="form-control" placeholder="contoh: cuaca buruk / duka cita / rapat dinas mendadak" required></div>
        </div>
        <label style="display:flex;gap:8px;align-items:center;margin:12px 0;font-size:13.5px;"><input type="checkbox" name="tandai_otomatis" value="1" checked> Tandai otomatis pulang semua siswa &amp; guru/staf yang sudah hadir tetapi belum absen pulang</label>
        <button type="submit" class="btn btn-gold">📢 Umumkan Sekolah Dipulangkan</button>
      </form>
    </div>
    <?php endif; ?>

    <div class="card">
      <h3>🧑‍🎓 Izin Pulang Awal — Siswa</h3>
      <?php if ($role === 'kepala_sekolah'): ?>
      <form method="GET" style="margin-bottom:12px;max-width:280px;"><select name="kelas_id" class="form-control" onchange="this.form.submit()"><option value="">— Pilih Kelas —</option>
        <?php while ($k = mysqli_fetch_assoc($kelas_list)): ?><option value="<?php echo $k['id']; ?>" <?php echo $kelas_id == $k['id'] ? 'selected' : ''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option><?php endwhile; ?></select></form>
      <?php endif; ?>
      <?php if (!$kelas_id): ?><p class="muted">Pilih kelas terlebih dahulu.</p>
      <?php elseif (empty($siswa_belum)): ?><p class="muted">Tidak ada siswa yang sedang berada di sekolah (sudah masuk &amp; belum pulang).</p>
      <?php else: ?>
      <form method="POST"><input type="hidden" name="aksi" value="pulang_awal_siswa"><input type="hidden" name="kelas_id" value="<?php echo $kelas_id; ?>">
        <div class="table-wrap"><table><thead><tr><th style="width:40px;"></th><th>Nama</th><th>Masuk</th></tr></thead><tbody>
        <?php foreach ($siswa_belum as $s): ?><tr><td><input type="checkbox" name="ids[]" value="<?php echo $s['id']; ?>"></td><td><?php echo bersihkan($s['nama']); ?></td><td><?php echo substr($s['jam_masuk'], 0, 5); ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
        <?php form_alasan($alasan_opsi); ?>
        <button type="submit" class="btn btn-primary" onclick="return confirm('Catat pulang awal untuk siswa yang dicentang?');">🚪 Catat Pulang Awal</button>
      </form>
      <?php endif; ?>
    </div>

    <?php if ($role === 'kepala_sekolah'): ?>
    <div class="card">
      <h3>👩‍🏫 Izin Pulang Awal — Guru &amp; Staf</h3>
      <?php if (empty($pegawai_belum)): ?><p class="muted">Tidak ada guru/staf yang sedang berada di sekolah (sudah masuk &amp; belum pulang).</p>
      <?php else: ?>
      <form method="POST"><input type="hidden" name="aksi" value="pulang_awal_pegawai">
        <div class="table-wrap"><table><thead><tr><th style="width:40px;"></th><th>Nama</th><th>Jenis</th><th>Masuk</th></tr></thead><tbody>
        <?php foreach ($pegawai_belum as $p): ?><tr><td><input type="checkbox" name="ids[]" value="<?php echo $p['id']; ?>"></td><td><?php echo bersihkan($p['nama']); ?></td><td><span class="pill"><?php echo $p['jenis']; ?></span></td><td><?php echo substr($p['jam_masuk'], 0, 5); ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
        <?php form_alasan($alasan_opsi); ?>
        <button type="submit" class="btn btn-primary" onclick="return confirm('Catat pulang awal untuk yang dicentang?');">🚪 Catat Pulang Awal</button>
      </form>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
