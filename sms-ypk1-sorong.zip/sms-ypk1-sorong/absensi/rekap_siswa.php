<?php
require_once __DIR__ . '/../config/session.php';
cek_login();
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Rekap Absensi Siswa';
$modul_aktif = 'absensi';
$role = $_SESSION['role'];

$bulan = $_GET['bulan'] ?? date('Y-m');

if ($role === 'guru') {
    $kelas_id = $_SESSION['kelas_id'] ?? 0;
} else {
    $kelas_id = (int) ($_GET['kelas_id'] ?? 0);
}

$kelas_list = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat");

$rekap = [];
$tot = ['hadir'=>0,'terlambat'=>0,'sakit'=>0,'izin'=>0,'alpa'=>0];
if ($kelas_id) {
    $siswa_res = mysqli_query($conn, "SELECT id, nama, nis FROM siswa WHERE kelas_id=$kelas_id AND status='Aktif' ORDER BY nama");
    while ($s = mysqli_fetch_assoc($siswa_res)) {
        $stat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT
            SUM(status='Hadir') AS hadir, SUM(status='Terlambat') AS terlambat,
            SUM(status='Sakit') AS sakit, SUM(status='Izin') AS izin, SUM(status='Alpa') AS alpa,
            COUNT(*) AS total
            FROM absensi_siswa WHERE siswa_id={$s['id']} AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan'"));
        $rekap[] = array_merge($s, $stat);
        $tot['hadir'] += (int)$stat['hadir']; $tot['terlambat'] += (int)$stat['terlambat'];
        $tot['sakit'] += (int)$stat['sakit']; $tot['izin'] += (int)$stat['izin']; $tot['alpa'] += (int)$stat['alpa'];
    }
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Rekap Absensi Siswa</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <div class="card">
      <form method="GET" class="grid grid-3" style="align-items:end;">
        <?php if ($role === 'kepala_sekolah'): ?>
        <div class="form-group mb-0">
          <label>Kelas</label>
          <select name="kelas_id" class="form-control" onchange="this.form.submit()">
            <option value="">— Pilih Kelas —</option>
            <?php while ($k = mysqli_fetch_assoc($kelas_list)): ?>
              <option value="<?php echo $k['id']; ?>" <?php echo $kelas_id==$k['id']?'selected':''; ?>><?php echo bersihkan($k['nama_kelas']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <?php endif; ?>
        <div class="form-group mb-0">
          <label>Bulan</label>
          <input type="month" name="bulan" class="form-control" value="<?php echo bersihkan($bulan); ?>" onchange="this.form.submit()">
        </div>
      </form>
    </div>

    <?php if ($kelas_id): ?>
    <div class="grid grid-2">
      <div class="card">
        <h3>Grafik Distribusi Status — <?php echo bersihkan($bulan); ?></h3>
        <canvas id="chartStatus" height="220"></canvas>
      </div>
      <div class="card">
        <h3>Ringkasan Total Kelas</h3>
        <div class="grid grid-3">
          <div class="stat-card"><div class="label">Total Hadir</div><div class="value"><?php echo $tot['hadir']; ?></div></div>
          <div class="stat-card gold"><div class="label">Terlambat</div><div class="value"><?php echo $tot['terlambat']; ?></div></div>
          <div class="stat-card dark"><div class="label">Alpa</div><div class="value"><?php echo $tot['alpa']; ?></div></div>
          <div class="stat-card blue"><div class="label">Sakit</div><div class="value"><?php echo $tot['sakit']; ?></div></div>
          <div class="stat-card blue"><div class="label">Izin</div><div class="value"><?php echo $tot['izin']; ?></div></div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="flex-between">
        <h3 class="mb-0">Rekap Bulan <?php echo bersihkan($bulan); ?></h3>
        <a href="cetak_rekap_siswa.php?kelas_id=<?php echo $kelas_id; ?>&bulan=<?php echo bersihkan($bulan); ?>" target="_blank" class="btn btn-gold btn-sm no-print">🖨️ Cetak Lembar Resmi (Kop Surat)</a>
      </div>
      <div class="table-wrap">
      <table>
        <thead><tr><th>NIS</th><th>Nama</th><th>Hadir</th><th>Terlambat</th><th>Sakit</th><th>Izin</th><th>Alpa</th><th>Total Tercatat</th><th>Persentase Hadir</th></tr></thead>
        <tbody>
        <?php if (empty($rekap)): ?><tr><td colspan="9" class="muted">Tidak ada data untuk periode ini.</td></tr><?php endif; ?>
        <?php foreach ($rekap as $r):
          $total = (int)$r['total'];
          $hadir_total = (int)$r['hadir'] + (int)$r['terlambat'];
          $pct = $total > 0 ? round($hadir_total / $total * 100) : 0;
        ?>
          <tr>
            <td><?php echo bersihkan($r['nis']); ?></td>
            <td><?php echo bersihkan($r['nama']); ?></td>
            <td><?php echo (int)$r['hadir']; ?></td>
            <td><?php echo (int)$r['terlambat']; ?></td>
            <td><?php echo (int)$r['sakit']; ?></td>
            <td><?php echo (int)$r['izin']; ?></td>
            <td><?php echo (int)$r['alpa']; ?></td>
            <td><?php echo $total; ?></td>
            <td><strong><?php echo $pct; ?>%</strong></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
    <?php else: ?>
      <p class="muted">Silakan pilih kelas terlebih dahulu.</p>
    <?php endif; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php if ($kelas_id): ?>
<script src="<?php echo BASE_URL; ?>assets/js/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('chartStatus'), {
  type: 'doughnut',
  data: {
    labels: ['Hadir', 'Terlambat', 'Sakit', 'Izin', 'Alpa'],
    datasets: [{
      data: [<?php echo $tot['hadir']; ?>, <?php echo $tot['terlambat']; ?>, <?php echo $tot['sakit']; ?>, <?php echo $tot['izin']; ?>, <?php echo $tot['alpa']; ?>],
      backgroundColor: ['#1F9D55', '#E0A700', '#328CC1', '#0B3C5D', '#D64545']
    }]
  },
  options: { plugins: { legend: { position: 'bottom' } }, maintainAspectRatio: true }
});
</script>
<?php endif; ?>
