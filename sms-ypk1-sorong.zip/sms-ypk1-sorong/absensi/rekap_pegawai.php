<?php
require_once __DIR__ . '/../config/session.php';
cek_role('kepala_sekolah');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Rekap Absensi Guru & Staf';
$modul_aktif = 'absensi';

$bulan = $_GET['bulan'] ?? date('Y-m');
$filter_jenis = $_GET['jenis'] ?? '';

$where = $filter_jenis ? "AND p.jenis='" . mysqli_real_escape_string($conn, $filter_jenis) . "'" : '';
$peg_res = mysqli_query($conn, "SELECT id, nama, jenis FROM pegawai p WHERE status_aktif=1 $where ORDER BY FIELD(jenis,'Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'), nama");

$rekap = [];
$labels_grafik = []; $data_hadir_grafik = []; $data_telat_grafik = [];
$tot = ['hadir'=>0,'terlambat'=>0,'sakit'=>0,'izin'=>0,'alpa'=>0];
while ($p = mysqli_fetch_assoc($peg_res)) {
    $stat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT
        SUM(status='Hadir') AS hadir, SUM(status='Terlambat') AS terlambat,
        SUM(status='Sakit') AS sakit, SUM(status='Izin') AS izin, SUM(status='Alpa') AS alpa,
        COUNT(*) AS total
        FROM absensi_pegawai WHERE pegawai_id={$p['id']} AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan'"));
    $r = array_merge($p, $stat);
    $rekap[] = $r;
    $tot['hadir'] += (int)$r['hadir']; $tot['terlambat'] += (int)$r['terlambat'];
    $tot['sakit'] += (int)$r['sakit']; $tot['izin'] += (int)$r['izin']; $tot['alpa'] += (int)$r['alpa'];
    $labels_grafik[] = $p['nama'];
    $data_hadir_grafik[] = (int)$r['hadir'];
    $data_telat_grafik[] = (int)$r['terlambat'];
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Rekap Absensi Guru &amp; Staf</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <div class="card">
      <form method="GET" class="grid grid-3" style="align-items:end;">
        <div class="form-group mb-0">
          <label>Jenis Pegawai</label>
          <select name="jenis" class="form-control" onchange="this.form.submit()">
            <option value="">Semua Jenis</option>
            <?php foreach (['Kepala Sekolah','Guru','Tata Usaha','Penjaga Sekolah'] as $j): ?>
              <option value="<?php echo $j; ?>" <?php echo $filter_jenis===$j?'selected':''; ?>><?php echo $j; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group mb-0">
          <label>Bulan</label>
          <input type="month" name="bulan" class="form-control" value="<?php echo bersihkan($bulan); ?>" onchange="this.form.submit()">
        </div>
      </form>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>Grafik Distribusi Status — <?php echo bersihkan($bulan); ?></h3>
        <canvas id="chartStatusPegawai" height="220"></canvas>
      </div>
      <div class="card">
        <h3>Grafik Kehadiran per Pegawai</h3>
        <canvas id="chartPerPegawai" height="220"></canvas>
      </div>
    </div>

    <div class="card">
      <div class="flex-between">
        <h3 class="mb-0">Rekap Bulan <?php echo bersihkan($bulan); ?></h3>
        <a href="cetak_rekap_pegawai.php?bulan=<?php echo bersihkan($bulan); ?>&jenis=<?php echo urlencode($filter_jenis); ?>" target="_blank" class="btn btn-gold btn-sm no-print">🖨️ Cetak Lembar Resmi (Kop Surat)</a>
      </div>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Nama</th><th>Jenis</th><th>Hadir</th><th>Terlambat</th><th>Sakit</th><th>Izin</th><th>Alpa</th><th>Total</th><th>% Kehadiran</th></tr></thead>
        <tbody>
        <?php if (empty($rekap)): ?><tr><td colspan="9" class="muted">Tidak ada data untuk periode ini.</td></tr><?php endif; ?>
        <?php foreach ($rekap as $r):
          $total = (int)$r['total'];
          $hadir_total = (int)$r['hadir'] + (int)$r['terlambat'];
          $pct = $total > 0 ? round($hadir_total / $total * 100) : 0;
        ?>
          <tr>
            <td><?php echo bersihkan($r['nama']); ?></td>
            <td><span class="pill"><?php echo $r['jenis']; ?></span></td>
            <td><?php echo (int)$r['hadir']; ?></td>
            <td><?php echo (int)$r['terlambat']; ?></td>
            <td><?php echo (int)$r['sakit']; ?></td>
            <td><?php echo (int)$r['izin']; ?></td>
            <td><?php echo (int)$r['alpa']; ?></td>
            <td><?php echo $total; ?></td>
            <td><strong><?php echo $pct; ?>%</strong></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>

<script src="<?php echo BASE_URL; ?>assets/js/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('chartStatusPegawai'), {
  type: 'doughnut',
  data: {
    labels: ['Hadir', 'Terlambat', 'Sakit', 'Izin', 'Alpa'],
    datasets: [{
      data: [<?php echo $tot['hadir']; ?>, <?php echo $tot['terlambat']; ?>, <?php echo $tot['sakit']; ?>, <?php echo $tot['izin']; ?>, <?php echo $tot['alpa']; ?>],
      backgroundColor: ['#1F9D55', '#E0A700', '#328CC1', '#0B3C5D', '#D64545']
    }]
  },
  options: { plugins: { legend: { position: 'bottom' } } }
});
new Chart(document.getElementById('chartPerPegawai'), {
  type: 'bar',
  data: {
    labels: <?php echo json_encode($labels_grafik); ?>,
    datasets: [
      { label: 'Hadir', data: <?php echo json_encode($data_hadir_grafik); ?>, backgroundColor: '#1F9D55' },
      { label: 'Terlambat', data: <?php echo json_encode($data_telat_grafik); ?>, backgroundColor: '#E0A700' }
    ]
  },
  options: { plugins: { legend: { position: 'bottom' } }, scales: { x: { ticks: { autoSkip: false, maxRotation: 60, minRotation: 30 } } } }
});
</script>
