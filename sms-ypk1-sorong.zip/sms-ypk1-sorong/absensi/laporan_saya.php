<?php
require_once __DIR__ . '/../config/session.php';
cek_role('guru');
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Laporan Diminta Kepala Sekolah';
$modul_aktif = 'absensi';
$kelas_id = $_SESSION['kelas_id'] ?? 0;
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kirim_id'])) {
    $id = (int) $_POST['kirim_id'];
    $catatan = bersihkan($_POST['catatan_wali_kelas'] ?? '');
    $stmt = mysqli_prepare($conn, "UPDATE laporan_bulanan SET status='Sudah Dikirim', dikirim_oleh=?, tanggal_dikirim=NOW(), catatan_wali_kelas=? WHERE id=? AND kelas_id=?");
    mysqli_stmt_bind_param($stmt, 'isii', $_SESSION['user_id'], $catatan, $id, $kelas_id);
    mysqli_stmt_execute($stmt);
    $pesan = 'Laporan berhasil dikirim ke Kepala Sekolah.';
}

$list_result = mysqli_query($conn, "SELECT * FROM laporan_bulanan WHERE kelas_id=$kelas_id ORDER BY tanggal_diminta DESC");
$daftar_laporan = [];
if ($list_result) { while ($row = mysqli_fetch_assoc($list_result)) { $daftar_laporan[] = $row; } }

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Laporan Diminta Kepala Sekolah</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <?php if (empty($daftar_laporan)): ?>
      <div class="card"><p class="muted mb-0">Belum ada permintaan laporan dari Kepala Sekolah untuk kelas Anda.</p></div>
    <?php endif; ?>

    <?php foreach ($daftar_laporan as $l): ?>
      <div class="card">
        <div class="flex-between">
          <h3 class="mb-0">Laporan Bulan <?php echo bersihkan($l['bulan']); ?></h3>
          <?php echo $l['status']==='Sudah Dikirim' ? '<span class="badge-status badge-hadir">Sudah Dikirim</span>' : '<span class="badge-status badge-terlambat">Menunggu Dikirim</span>'; ?>
        </div>
        <?php if ($l['catatan_kepsek']): ?>
          <p class="muted">📝 Catatan Kepala Sekolah: <?php echo bersihkan($l['catatan_kepsek']); ?></p>
        <?php endif; ?>

        <div style="margin:12px 0;">
          <a class="btn btn-outline btn-sm" href="<?php echo BASE_URL; ?>absensi/rekap_siswa.php?bulan=<?php echo $l['bulan']; ?>">📊 Lihat Rekap di Sistem</a>
          <a class="btn btn-outline btn-sm" href="<?php echo BASE_URL; ?>manajemen/cetak_rekap_siswa.php?bulan=<?php echo $l['bulan']; ?>" target="_blank">📄 Pratinjau Lembar Resmi</a>
        </div>

        <?php if ($l['status'] === 'Diminta'): ?>
          <form method="POST">
            <input type="hidden" name="kirim_id" value="<?php echo $l['id']; ?>">
            <div class="form-group">
              <label>Catatan untuk Kepala Sekolah (opsional)</label>
              <textarea name="catatan_wali_kelas" class="form-control" rows="2" placeholder="contoh: 2 siswa izin karena acara keluarga, sudah dikonfirmasi orang tua"></textarea>
            </div>
            <button type="submit" class="btn btn-primary" onclick="return confirm('Kirim laporan bulan ini ke Kepala Sekolah?');">📨 Kirim Laporan Sekarang</button>
          </form>
        <?php else: ?>
          <p class="muted mb-0">✅ Dikirim pada <?php echo date('d/m/Y H:i', strtotime($l['tanggal_dikirim'])); ?><?php if ($l['catatan_wali_kelas']): ?><br>Catatan Anda: <?php echo bersihkan($l['catatan_wali_kelas']); ?><?php endif; ?></p>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
