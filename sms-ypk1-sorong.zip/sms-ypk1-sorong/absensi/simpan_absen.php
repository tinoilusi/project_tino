<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

function balas($arr) { echo json_encode($arr); exit; }
function info($pesan, $suara = null) { balas(['success' => false, 'info' => true, 'pesan' => $pesan, 'pesan_suara' => $suara ?: $pesan]); }
function gagal($pesan) { balas(['success' => false, 'pesan' => $pesan]); }

if (!isset($_SESSION['user_id'])) gagal('Sesi login berakhir. Silakan login ulang.');

$token = trim($_POST['token'] ?? '');
$tipe  = $_POST['tipe'] ?? '';
$role  = $_SESSION['role'];
$sekarang = date('H:i:s');
$tanggal  = date('Y-m-d');
$ta = tahun_ajaran_aktif($conn);
$ta_id = $ta['id'] ?? null;

if ($token === '') gagal('Kode QR tidak terbaca.');

/**
 * Logika inti absensi QR (dipakai siswa & pegawai):
 *  1. Belum ada catatan hari ini  -> ABSEN MASUK (Hadir/Terlambat).
 *  2. Sudah masuk, belum waktunya pulang -> DITOLAK (tidak boleh dobel), diberi tahu kapan pulang dibuka.
 *  3. Sudah masuk, sudah waktunya pulang (atau sekolah dipulangkan mendadak) -> ABSEN PULANG.
 *  4. Sudah masuk & pulang -> info sudah lengkap.
 */
function proses_absen_qr($conn, $tabel, $kolom_fk, $id, $nama, $sub, $ta_id, $user_id, $sekarang, $tanggal) {
    $buka_pulang = jam_buka_pulang($conn);
    $khusus = pulang_khusus_hari_ini($conn);
    $sudah_pulang_khusus = $khusus && $sekarang >= $khusus['jam'];
    $bisa_pulang = ($sekarang >= $buka_pulang) || $sudah_pulang_khusus;

    $res = mysqli_query($conn, "SELECT * FROM $tabel WHERE $kolom_fk=" . (int)$id . " AND tanggal='$tanggal' LIMIT 1");
    $row = $res ? mysqli_fetch_assoc($res) : null;

    // ---------- belum ada catatan: ABSEN MASUK ----------
    if (!$row) {
        if ($bisa_pulang) {
            $msg = $sudah_pulang_khusus
                ? "Sekolah sudah dipulangkan hari ini pukul " . substr($khusus['jam'], 0, 5) . ". Absen masuk tidak dapat dicatat."
                : "Jam sekolah sudah berakhir. Absen masuk tidak dapat dicatat. Hubungi wali kelas atau kepala sekolah untuk input manual.";
            info("$nama: $msg", "$nama, $msg");
        }
        $status = tentukan_status_masuk($conn, $sekarang);
        if ($tabel === 'absensi_siswa') {
            $st = mysqli_prepare($conn, "INSERT INTO absensi_siswa (siswa_id, tahun_ajaran_id, tanggal, jam_masuk, status, metode, input_by) VALUES (?,?,?,?,?,'QR',?)");
            mysqli_stmt_bind_param($st, 'iisssi', $id, $ta_id, $tanggal, $sekarang, $status, $user_id);
        } else {
            $st = mysqli_prepare($conn, "INSERT INTO absensi_pegawai (pegawai_id, tanggal, jam_masuk, status, metode, input_by) VALUES (?,?,?,?,'QR',?)");
            mysqli_stmt_bind_param($st, 'isssi', $id, $tanggal, $sekarang, $status, $user_id);
        }
        mysqli_stmt_execute($st);
        balas(['success' => true, 'jenis' => 'masuk', 'nama' => $nama, 'sub' => $sub, 'status' => $status, 'waktu' => date('H:i'),
               'pesan_suara' => salam_waktu() . ', ' . $nama . '. Absen masuk berhasil dicatat, status ' . $status . '.']);
    }

    // ---------- ada catatan manual tanpa jam masuk (Sakit / Izin / Alpa) ----------
    if (empty($row['jam_masuk'])) {
        if ($row['status'] === 'Alpa') {                       // ternyata hadir: ubah Alpa -> Hadir/Terlambat via QR
            if ($bisa_pulang) info("$nama tercatat Alpa dan jam sekolah sudah berakhir. Hubungi wali kelas untuk koreksi manual.");
            $status = tentukan_status_masuk($conn, $sekarang);
            mysqli_query($conn, "UPDATE $tabel SET jam_masuk='$sekarang', status='$status', metode='QR', keterangan='Semula tercatat Alpa, hadir via scan QR' WHERE id=" . (int)$row['id']);
            balas(['success' => true, 'jenis' => 'masuk', 'nama' => $nama, 'sub' => $sub, 'status' => $status, 'waktu' => date('H:i'),
                   'pesan_suara' => salam_waktu() . ', ' . $nama . '. Absen masuk berhasil dicatat, status ' . $status . '.']);
        }
        info("$nama sudah tercatat {$row['status']} hari ini. Hubungi wali kelas jika ingin mengubahnya.");
    }

    // ---------- sudah masuk, belum pulang ----------
    if (empty($row['jam_pulang'])) {
        if (!$bisa_pulang) {                                    // DOBEL MASUK dicegah, tunggu jam pulang
            $jam = substr($buka_pulang, 0, 5);
            info("$nama sudah absen masuk pukul " . substr($row['jam_masuk'], 0, 5) . ". Absen pulang baru dibuka pukul $jam.",
                 "$nama, Anda sudah absen masuk. Absen pulang baru dibuka pukul " . ucapan_jam($buka_pulang) . ".");
        }
        $jenis = ($sudah_pulang_khusus && $sekarang < $buka_pulang) ? 'Dipulangkan Sekolah' : 'Normal';
        $ket = $jenis === 'Dipulangkan Sekolah' ? ('Sekolah dipulangkan mendadak: ' . ($khusus['alasan'] ?: '-')) : null;
        $st = mysqli_prepare($conn, "UPDATE $tabel SET jam_pulang=?, jenis_pulang=?, keterangan=COALESCE(?, keterangan) WHERE id=?");
        mysqli_stmt_bind_param($st, 'sssi', $sekarang, $jenis, $ket, $row['id']);
        mysqli_stmt_execute($st);
        $suara = $jenis === 'Dipulangkan Sekolah'
            ? "$nama, absen pulang berhasil dicatat. Sekolah dipulangkan lebih awal hari ini. Hati-hati di jalan."
            : "$nama, absen pulang berhasil dicatat. Terima kasih, hati-hati di jalan.";
        balas(['success' => true, 'jenis' => 'pulang', 'nama' => $nama, 'sub' => $sub, 'status' => $row['status'], 'waktu' => date('H:i'), 'pesan_suara' => $suara]);
    }

    // ---------- sudah lengkap ----------
    $jp = ($row['jenis_pulang'] ?? '') === 'Izin Pulang Awal' ? ' (izin pulang awal)' : '';
    info("$nama sudah lengkap hari ini: masuk " . substr($row['jam_masuk'], 0, 5) . ", pulang " . substr($row['jam_pulang'], 0, 5) . "$jp.",
         "$nama, absensi Anda hari ini sudah lengkap.");
}

// ================= ABSENSI SISWA =================
if ($tipe === 'siswa') {
    $stmt = mysqli_prepare($conn, "SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id WHERE s.qr_token=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 's', $token);
    mysqli_stmt_execute($stmt);
    $siswa = mysqli_stmt_get_result($stmt)->fetch_assoc();

    if (!$siswa) gagal('Kode QR tidak dikenali di data siswa.');
    if ($siswa['status'] !== 'Aktif') gagal($siswa['nama'] . ' berstatus ' . $siswa['status'] . ', bukan siswa aktif.');
    if ($role === 'guru' && (int)$siswa['kelas_id'] !== (int)($_SESSION['kelas_id'] ?? 0)) {
        gagal($siswa['nama'] . ' bukan siswa dari kelas Anda (' . ($_SESSION['nama_kelas'] ?? '-') . ').');
    }
    proses_absen_qr($conn, 'absensi_siswa', 'siswa_id', $siswa['id'], $siswa['nama'], $siswa['nama_kelas'], $ta_id, $_SESSION['user_id'], $sekarang, $tanggal);
}

// ================= ABSENSI PEGAWAI (Guru, TU, Penjaga) =================
if ($tipe === 'pegawai') {
    if ($role !== 'kepala_sekolah') gagal('Hanya Kepala Sekolah yang dapat memproses absensi guru & staf.');
    $stmt = mysqli_prepare($conn, "SELECT * FROM pegawai WHERE qr_token=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 's', $token);
    mysqli_stmt_execute($stmt);
    $peg = mysqli_stmt_get_result($stmt)->fetch_assoc();

    if (!$peg) gagal('Kode QR tidak dikenali di data pegawai.');
    if (!$peg['status_aktif']) gagal($peg['nama'] . ' berstatus nonaktif.');
    proses_absen_qr($conn, 'absensi_pegawai', 'pegawai_id', $peg['id'], $peg['nama'], $peg['jenis'], null, $_SESSION['user_id'], $sekarang, $tanggal);
}

gagal('Tipe absensi tidak valid.');
