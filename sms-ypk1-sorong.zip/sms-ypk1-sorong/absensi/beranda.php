<?php
require_once __DIR__ . '/../config/session.php';
cek_login();
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Ringkasan Absensi';
$modul_aktif = 'absensi';
$role = $_SESSION['role'];
$tgl = date('Y-m-d');
$jam_masuk = get_setting($conn, 'jam_masuk');
$jam_pulang = get_setting($conn, 'jam_pulang');

if ($role === 'kepala_sekolah') {
    $total_siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM siswa WHERE status='Aktif'"))['c'];
    $hadir_siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM absensi_siswa WHERE tanggal='$tgl' AND status IN ('Hadir','Terlambat')"))['c'];
    $telat_siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM absensi_siswa WHERE tanggal='$tgl' AND status='Terlambat'"))['c'];

    $total_pegawai = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM pegawai WHERE status_aktif=1"))['c'];
    $hadir_pegawai = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM absensi_pegawai WHERE tanggal='$tgl' AND status IN ('Hadir','Terlambat')"))['c'];
    $telat_pegawai = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM absensi_pegawai WHERE tanggal='$tgl' AND status='Terlambat'"))['c'];

    $log_pegawai = mysqli_query($conn, "SELECT p.nama, p.jenis, a.jam_masuk, a.jam_pulang, a.jenis_pulang, a.status, a.bukti FROM absensi_pegawai a JOIN pegawai p ON p.id=a.pegawai_id WHERE a.tanggal='$tgl' ORDER BY a.jam_masuk DESC");
    $log_siswa = mysqli_query($conn, "SELECT s.nama, k.nama_kelas, a.jam_masuk, a.jam_pulang, a.jenis_pulang, a.status, a.bukti FROM absensi_siswa a JOIN siswa s ON s.id=a.siswa_id LEFT JOIN kelas k ON k.id=s.kelas_id WHERE a.tanggal='$tgl' ORDER BY a.jam_masuk DESC LIMIT 15");
    $belum_pegawai = mysqli_query($conn, "SELECT nama, jenis FROM pegawai WHERE status_aktif=1 AND id NOT IN (SELECT pegawai_id FROM absensi_pegawai WHERE tanggal='$tgl') ORDER BY nama");
    $belum_siswa_semua = mysqli_query($conn, "SELECT s.nama, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id WHERE s.status='Aktif' AND s.id NOT IN (SELECT siswa_id FROM absensi_siswa WHERE tanggal='$tgl') ORDER BY k.tingkat, s.nama");
} else {
    $kelas_id = $_SESSION['kelas_id'] ?? 0;
    $total_siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM siswa WHERE status='Aktif' AND kelas_id=$kelas_id"))['c'];
    $hadir_siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM absensi_siswa a JOIN siswa s ON s.id=a.siswa_id WHERE s.kelas_id=$kelas_id AND a.tanggal='$tgl' AND a.status IN ('Hadir','Terlambat')"))['c'];
    $telat_siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM absensi_siswa a JOIN siswa s ON s.id=a.siswa_id WHERE s.kelas_id=$kelas_id AND a.tanggal='$tgl' AND a.status='Terlambat'"))['c'];
    $log_siswa = mysqli_query($conn, "SELECT s.nama, k.nama_kelas, a.jam_masuk, a.jam_pulang, a.jenis_pulang, a.status, a.bukti FROM absensi_siswa a JOIN siswa s ON s.id=a.siswa_id LEFT JOIN kelas k ON k.id=s.kelas_id WHERE s.kelas_id=$kelas_id AND a.tanggal='$tgl' ORDER BY a.jam_masuk DESC");
    $belum_absen = mysqli_query($conn, "SELECT nama FROM siswa WHERE status='Aktif' AND kelas_id=$kelas_id AND id NOT IN (SELECT siswa_id FROM absensi_siswa WHERE tanggal='$tgl')");
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar">
    <h2><?php echo $role === 'kepala_sekolah' ? 'Ringkasan Absensi Sekolah' : 'Ringkasan Absensi Kelas ' . bersihkan($_SESSION['nama_kelas'] ?? '-'); ?></h2>
    <div class="clock" id="liveClock"></div>
  </div>
  <div class="content">

    <?php $khusus = pulang_khusus_hari_ini($conn); if ($khusus): ?>
      <div class="alert alert-success">📢 <b>Sekolah dipulangkan mendadak hari ini</b> mulai pukul <?php echo substr($khusus['jam'],0,5); ?> — <?php echo bersihkan($khusus['alasan']); ?>. Absen pulang sudah bisa di-scan.</div>
    <?php endif; ?>

    <div class="card">
      <div class="flex-between">
        <div><strong>⏰ Jadwal Absensi Hari Ini (WIT)</strong> — Masuk pukul <?php echo substr($jam_masuk,0,5); ?>, Pulang pukul <?php echo substr($jam_pulang,0,5); ?></div>
        <div>
          <?php if ($role === 'kepala_sekolah'): ?>
            <a href="scan_pegawai.php" class="btn btn-primary btn-sm">📷 Scan Guru &amp; Staf</a>
            <a href="scan_siswa.php" class="btn btn-outline btn-sm">📷 Scan Siswa</a>
            <a href="manual_pegawai.php" class="btn btn-outline btn-sm">✏️ Manual Guru &amp; Staf</a>
            <a href="manual_siswa.php" class="btn btn-outline btn-sm">✏️ Manual Siswa</a>
          <?php else: ?>
            <a href="scan_siswa.php" class="btn btn-primary btn-sm">📷 Mulai Scan Absen</a>
            <a href="manual_siswa.php" class="btn btn-outline btn-sm">✏️ Input Manual</a>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="grid <?php echo $role === 'kepala_sekolah' ? 'grid-4' : 'grid-3'; ?>">
      <div class="stat-card"><div class="label">Siswa Hadir Hari Ini</div><div class="value"><?php echo $hadir_siswa; ?> / <?php echo $total_siswa; ?></div></div>
      <div class="stat-card gold"><div class="label">Siswa Terlambat</div><div class="value"><?php echo $telat_siswa; ?></div></div>
      <?php if ($role === 'kepala_sekolah'): ?>
        <div class="stat-card blue"><div class="label">Guru &amp; Staf Hadir</div><div class="value"><?php echo $hadir_pegawai; ?> / <?php echo $total_pegawai; ?></div></div>
        <div class="stat-card dark"><div class="label">Guru &amp; Staf Terlambat</div><div class="value"><?php echo $telat_pegawai; ?></div></div>
      <?php else: ?>
        <div class="stat-card dark"><div class="label">Belum Absen</div><div class="value"><?php echo $total_siswa - $hadir_siswa; ?></div></div>
      <?php endif; ?>
    </div>

    <?php if ($role === 'kepala_sekolah'): ?>
    <div class="grid grid-2">
      <div class="card">
        <h3>Log Absensi Guru &amp; Staf Hari Ini</h3>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Nama</th><th>Jenis</th><th>Masuk</th><th>Pulang</th><th>Status</th><th>Bukti</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($log_pegawai)===0): ?><tr><td colspan="6" class="muted">Belum ada data hari ini.</td></tr><?php endif; ?>
          <?php while ($l = mysqli_fetch_assoc($log_pegawai)): ?>
            <tr>
              <td><?php echo bersihkan($l['nama']); ?></td>
              <td><span class="pill"><?php echo $l['jenis']; ?></span></td>
              <td><?php echo $l['jam_masuk'] ? substr($l['jam_masuk'],0,5) : '-'; ?></td>
              <td><?php echo tampil_jam_pulang($l); ?></td>
              <td><?php echo badge_status($l['status']); ?></td>
              <td><?php echo !empty($l['bukti']) ? '<a href="' . BASE_URL . 'assets/img/uploads/' . $l['bukti'] . '" target="_blank">📎</a>' : '-'; ?></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        </div>
      </div>
      <div class="card">
        <h3>Log Absensi Siswa Terbaru</h3>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Nama</th><th>Kelas</th><th>Masuk</th><th>Pulang</th><th>Status</th><th>Bukti</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($log_siswa)===0): ?><tr><td colspan="6" class="muted">Belum ada data hari ini.</td></tr><?php endif; ?>
          <?php while ($l = mysqli_fetch_assoc($log_siswa)): ?>
            <tr>
              <td><?php echo bersihkan($l['nama']); ?></td>
              <td><?php echo bersihkan($l['nama_kelas']); ?></td>
              <td><?php echo $l['jam_masuk'] ? substr($l['jam_masuk'],0,5) : '-'; ?></td>
              <td><?php echo tampil_jam_pulang($l); ?></td>
              <td><?php echo badge_status($l['status']); ?></td>
              <td><?php echo !empty($l['bukti']) ? '<a href="' . BASE_URL . 'assets/img/uploads/' . $l['bukti'] . '" target="_blank">📎</a>' : '-'; ?></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        </div>
      </div>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>👔 Guru &amp; Staf Belum Absen Hari Ini</h3>
        <?php if (mysqli_num_rows($belum_pegawai) === 0): ?>
          <p class="muted">Semua guru &amp; staf aktif sudah tercatat hari ini. 🎉</p>
        <?php else: ?>
          <div class="table-wrap">
          <table>
            <thead><tr><th>Nama</th><th>Jenis</th></tr></thead>
            <tbody>
            <?php while ($b = mysqli_fetch_assoc($belum_pegawai)): ?>
              <tr><td><?php echo bersihkan($b['nama']); ?></td><td><span class="pill"><?php echo bersihkan($b['jenis']); ?></span></td></tr>
            <?php endwhile; ?>
            </tbody>
          </table>
          </div>
          <a href="manual_pegawai.php" class="btn btn-outline btn-sm" style="margin-top:10px;">✏️ Input Manual Guru &amp; Staf</a>
        <?php endif; ?>
        <p class="muted" style="margin-top:10px; font-size:12px;">⏱️ Yang masih kosong di sini setelah pukul <?php echo substr(get_setting($conn,'jam_batas_alpa') ?: '14:00:00',0,5); ?> WIT akan otomatis ditandai <b>Alpa</b> oleh sistem.</p>
      </div>
      <div class="card">
        <h3>🧑‍🎓 Siswa Belum Absen Hari Ini (Semua Kelas)</h3>
        <?php if (mysqli_num_rows($belum_siswa_semua) === 0): ?>
          <p class="muted">Semua siswa aktif sudah tercatat hari ini. 🎉</p>
        <?php else: ?>
          <div class="table-wrap" style="max-height:260px; overflow-y:auto;">
          <table>
            <thead><tr><th>Nama</th><th>Kelas</th></tr></thead>
            <tbody>
            <?php while ($b = mysqli_fetch_assoc($belum_siswa_semua)): ?>
              <tr><td><?php echo bersihkan($b['nama']); ?></td><td><?php echo bersihkan($b['nama_kelas'] ?: '-'); ?></td></tr>
            <?php endwhile; ?>
            </tbody>
          </table>
          </div>
          <a href="manual_siswa.php" class="btn btn-outline btn-sm" style="margin-top:10px;">✏️ Input Manual Siswa</a>
        <?php endif; ?>
        <p class="muted" style="margin-top:10px; font-size:12px;">⏱️ Yang masih kosong di sini setelah pukul <?php echo substr(get_setting($conn,'jam_batas_alpa') ?: '14:00:00',0,5); ?> WIT akan otomatis ditandai <b>Alpa</b> oleh sistem.</p>
      </div>
    </div>
    <?php else: ?>
    <div class="grid grid-2">
      <div class="card">
        <h3>Log Absensi Kelas Saya Hari Ini</h3>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Nama</th><th>Masuk</th><th>Pulang</th><th>Status</th><th>Bukti</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($log_siswa)===0): ?><tr><td colspan="5" class="muted">Belum ada data hari ini.</td></tr><?php endif; ?>
          <?php while ($l = mysqli_fetch_assoc($log_siswa)): ?>
            <tr>
              <td><?php echo bersihkan($l['nama']); ?></td>
              <td><?php echo $l['jam_masuk'] ? substr($l['jam_masuk'],0,5) : '-'; ?></td>
              <td><?php echo tampil_jam_pulang($l); ?></td>
              <td><?php echo badge_status($l['status']); ?></td>
              <td><?php echo !empty($l['bukti']) ? '<a href="' . BASE_URL . 'assets/img/uploads/' . $l['bukti'] . '" target="_blank">📎</a>' : '-'; ?></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        </div>
      </div>
      <div class="card">
        <h3>Siswa Belum Absen</h3>
        <?php if (mysqli_num_rows($belum_absen)===0): ?>
          <p class="muted">Semua siswa sudah tercatat hari ini. 🎉</p>
        <?php else: ?>
          <ul>
            <?php while ($b = mysqli_fetch_assoc($belum_absen)): ?><li><?php echo bersihkan($b['nama']); ?></li><?php endwhile; ?>
          </ul>
          <a href="manual_siswa.php" class="btn btn-outline btn-sm">Input Manual (Sakit/Izin/Alpa)</a>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
