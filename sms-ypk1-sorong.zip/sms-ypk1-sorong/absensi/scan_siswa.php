<?php
require_once __DIR__ . '/../config/session.php';
cek_login();
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Scan Absen Siswa';
$modul_aktif = 'absensi';
$role = $_SESSION['role'];
$judul_scope = $role === 'guru' ? ('Kelas ' . ($_SESSION['nama_kelas'] ?? '-')) : 'Semua Kelas';

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Scan Absen Siswa — <?php echo bersihkan($judul_scope); ?></h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <div class="card">
      <p class="muted mb-0">Arahkan kamera ke kartu QR siswa. Sistem akan otomatis mendeteksi <b>absen masuk</b> atau <b>absen pulang</b> berdasarkan riwayat hari ini, lengkap dengan suara konfirmasi.</p>
    </div>

    <div id="kontrolSuara"></div>

    <div class="scan-wrap">
      <div class="scan-camera">
        <div id="qr-reader"></div>
        <div class="card" style="margin-top:14px;">
          <label style="font-weight:600; font-size:13px;">Kamera tidak berfungsi? Ketik kode QR / token manual lalu tekan Enter:</label>
          <input type="text" id="input-manual" class="form-control" placeholder="Contoh: SIS-2026001" style="margin-top:8px;">
        </div>
      </div>
      <div class="scan-result" id="hasilScan">
        <div class="big-icon">📷</div>
        <div class="nama">Menunggu Scan...</div>
        <div class="info">Arahkan kartu QR ke kamera</div>
      </div>
    </div>

    <div class="card">
      <h3>Log Scan Sesi Ini</h3>
      <div class="scan-log" id="logScan"></div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>

<script src="<?php echo BASE_URL; ?>assets/js/html5-qrcode.min.js"></script>
<script src="<?php echo aset('assets/js/scanner.js'); ?>"></script>
<script>
  const BASE_URL_JS = <?php echo json_encode(BASE_URL); ?>;
  pasangKontrolSuara('kontrolSuara');
  mulaiScanner('qr-reader', 'siswa', BASE_URL_JS, 'hasilScan', 'logScan');
  pasangInputManual('input-manual', 'siswa', BASE_URL_JS, 'hasilScan', 'logScan');
</script>
