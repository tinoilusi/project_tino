<?php
// =====================================================================
// KONFIGURASI KONEKSI DATABASE
// =====================================================================
date_default_timezone_set('Asia/Jayapura'); // Waktu Indonesia Timur (WIT)

// --- UBAH SESUAI KONFIGURASI SERVER ANDA (XAMPP default di bawah ini) ---
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'db_sms_ypk1_sorong';

// --- UBAH SESUAI NAMA FOLDER PROJECT DI htdocs/ ANDA ---
// Contoh: jika project ada di http://localhost/sms-ypk1-sorong/ maka BASE_URL = '/sms-ypk1-sorong/'
// Jika project ada di domain utama (root), gunakan BASE_URL = '/'
define('BASE_URL', '/sms-ypk1-sorong/');

// Konsistenkan perilaku semua versi PHP: query gagal mengembalikan false (bukan melempar exception),
// sehingga halaman tetap tampil rapi walau ada tabel yang belum ada.
mysqli_report(MYSQLI_REPORT_OFF);

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if (!$conn) {
    die('<div style="font-family:sans-serif;padding:40px;background:#fdecea;color:#611a15;border-radius:8px;margin:40px;">
        <h2>Koneksi Database Gagal</h2>
        <p>' . mysqli_connect_error() . '</p>
        <p>Pastikan MySQL sudah berjalan dan database <b>db_sms_ypk1_sorong</b> sudah diimport dari file <code>database/sms_ypk1_sorong.sql</code>.</p>
        </div>');
}
mysqli_set_charset($conn, 'utf8mb4');


// =====================================================================
// AUTO-UPGRADE SKEMA: menambahkan tabel/kolom baru secara otomatis pada database lama,
// sehingga Anda tidak perlu menjalankan SQL tambahan setiap ada pembaruan sistem.
// =====================================================================
(function ($conn) {
    $ada = function ($tabel, $kolom) use ($conn) {
        $r = mysqli_query($conn, "SHOW COLUMNS FROM `$tabel` LIKE '$kolom'");
        return $r && mysqli_num_rows($r) > 0;
    };
    $enum = "ENUM('Normal','Izin Pulang Awal','Dipulangkan Sekolah') DEFAULT NULL";
    if (!$ada('absensi_siswa', 'jenis_pulang')  && $ada('absensi_siswa', 'jam_pulang'))
        mysqli_query($conn, "ALTER TABLE absensi_siswa ADD COLUMN jenis_pulang $enum AFTER jam_pulang");
    if (!$ada('absensi_pegawai', 'jenis_pulang') && $ada('absensi_pegawai', 'jam_pulang'))
        mysqli_query($conn, "ALTER TABLE absensi_pegawai ADD COLUMN jenis_pulang $enum AFTER jam_pulang");
    if (!$ada('siswa', 'nik') && $ada('siswa', 'nisn'))
        mysqli_query($conn, "ALTER TABLE siswa ADD COLUMN nik VARCHAR(20) DEFAULT NULL AFTER nisn");
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'laporan_bulanan'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE IF NOT EXISTS laporan_bulanan (
          id INT AUTO_INCREMENT PRIMARY KEY, kelas_id INT NOT NULL, bulan CHAR(7) NOT NULL,
          status ENUM('Diminta','Sudah Dikirim') NOT NULL DEFAULT 'Diminta',
          diminta_oleh INT DEFAULT NULL, tanggal_diminta TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          dikirim_oleh INT DEFAULT NULL, tanggal_dikirim DATETIME DEFAULT NULL,
          catatan_wali_kelas TEXT DEFAULT NULL, catatan_kepsek VARCHAR(255) DEFAULT NULL,
          UNIQUE KEY unik_permintaan (kelas_id, bulan),
          FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE) ENGINE=InnoDB");
    }

    // =====================================================================
    // MODUL BARU: KEUANGAN SEKOLAH/KOMITE (role: bendahara) & E-RAPOR (role: guru/kepala_sekolah)
    // Dibuat otomatis di sini supaya tidak perlu import SQL manual tambahan.
    // =====================================================================

    // --- 1. Tambah role 'bendahara' pada tabel users (tanpa menghapus role yang sudah ada) ---
    $kolom_role = mysqli_fetch_assoc(mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'role'"));
    if ($kolom_role && strpos($kolom_role['Type'], 'bendahara') === false) {
        mysqli_query($conn, "ALTER TABLE users MODIFY COLUMN role ENUM('kepala_sekolah','guru','bendahara') NOT NULL");
    }

    // --- 2. E-RAPOR: mata pelajaran ---
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'mata_pelajaran'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE mata_pelajaran (
          id INT AUTO_INCREMENT PRIMARY KEY,
          kode VARCHAR(20) DEFAULT NULL,
          nama_mapel VARCHAR(100) NOT NULL,
          kelompok VARCHAR(30) NOT NULL DEFAULT 'Umum',
          kkm INT NOT NULL DEFAULT 75,
          urutan INT NOT NULL DEFAULT 0,
          status_aktif TINYINT(1) NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $default_mapel = [
            ['PAI','Pendidikan Agama dan Budi Pekerti','Umum',1],
            ['PPKN','Pendidikan Pancasila','Umum',2],
            ['BINDO','Bahasa Indonesia','Umum',3],
            ['MTK','Matematika','Umum',4],
            ['BING','Bahasa Inggris','Umum',5],
            ['PJOK','Pendidikan Jasmani, Olahraga dan Kesehatan','Umum',6],
            ['SEJ','Sejarah','Umum',7],
            ['SB','Seni Budaya','Umum',8],
            ['INF','Informatika','Umum',9],
            ['FIS','Fisika','Pilihan',10],
            ['KIM','Kimia','Pilihan',11],
            ['BIO','Biologi','Pilihan',12],
            ['EKO','Ekonomi','Pilihan',13],
            ['SOS','Sosiologi','Pilihan',14],
            ['GEO','Geografi','Pilihan',15],
            ['MULOK','Muatan Lokal','Umum',16],
        ];
        $stmt = mysqli_prepare($conn, "INSERT INTO mata_pelajaran (kode, nama_mapel, kelompok, urutan) VALUES (?,?,?,?)");
        foreach ($default_mapel as $m) { mysqli_stmt_bind_param($stmt, 'sssi', $m[0], $m[1], $m[2], $m[3]); mysqli_stmt_execute($stmt); }
    }

    // --- 3. E-RAPOR: penugasan guru per mapel & kelas ---
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'pengajaran'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE pengajaran (
          id INT AUTO_INCREMENT PRIMARY KEY,
          tahun_ajaran_id INT NOT NULL DEFAULT 0,
          kelas_id INT NOT NULL,
          mapel_id INT NOT NULL,
          pegawai_id INT NOT NULL,
          UNIQUE KEY unik_pengajaran (tahun_ajaran_id, kelas_id, mapel_id),
          FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE,
          FOREIGN KEY (mapel_id) REFERENCES mata_pelajaran(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    // --- 4. E-RAPOR: nilai akademik per siswa per mapel ---
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'nilai_akademik'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE nilai_akademik (
          id INT AUTO_INCREMENT PRIMARY KEY,
          siswa_id INT NOT NULL,
          mapel_id INT NOT NULL,
          kelas_id INT NOT NULL,
          tahun_ajaran_id INT NOT NULL DEFAULT 0,
          nilai_harian DECIMAL(5,2) DEFAULT NULL,
          nilai_uts DECIMAL(5,2) DEFAULT NULL,
          nilai_uas DECIMAL(5,2) DEFAULT NULL,
          nilai_akhir DECIMAL(5,2) DEFAULT NULL,
          predikat VARCHAR(2) DEFAULT NULL,
          deskripsi VARCHAR(255) DEFAULT NULL,
          diinput_oleh INT DEFAULT NULL,
          updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY unik_nilai (siswa_id, mapel_id, tahun_ajaran_id),
          FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
          FOREIGN KEY (mapel_id) REFERENCES mata_pelajaran(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    // --- 5. E-RAPOR: nilai sikap & catatan wali kelas ---
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'nilai_sikap'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE nilai_sikap (
          id INT AUTO_INCREMENT PRIMARY KEY,
          siswa_id INT NOT NULL,
          tahun_ajaran_id INT NOT NULL DEFAULT 0,
          spiritual VARCHAR(20) NOT NULL DEFAULT 'Baik',
          sosial VARCHAR(20) NOT NULL DEFAULT 'Baik',
          ekstrakurikuler VARCHAR(255) DEFAULT NULL,
          catatan_wali TEXT DEFAULT NULL,
          diinput_oleh INT DEFAULT NULL,
          updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY unik_sikap (siswa_id, tahun_ajaran_id),
          FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    // --- 6. KEUANGAN: kategori pemasukan/pengeluaran ---
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'kategori_keuangan'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE kategori_keuangan (
          id INT AUTO_INCREMENT PRIMARY KEY,
          nama_kategori VARCHAR(100) NOT NULL,
          tipe ENUM('Pemasukan','Pengeluaran') NOT NULL,
          keterangan VARCHAR(255) DEFAULT NULL,
          status_aktif TINYINT(1) NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $default_kategori = [
            ['SPP / Iuran Komite','Pemasukan'],
            ['Dana BOS','Pemasukan'],
            ['Sumbangan & Donasi','Pemasukan'],
            ['Pendapatan Lain-lain','Pemasukan'],
            ['Gaji & Honor Guru/Staf','Pengeluaran'],
            ['Operasional & Utilitas','Pengeluaran'],
            ['Sarana & Prasarana','Pengeluaran'],
            ['Kegiatan & Ekstrakurikuler Siswa','Pengeluaran'],
            ['Alat Tulis & Administrasi','Pengeluaran'],
            ['Pengeluaran Lain-lain','Pengeluaran'],
        ];
        $stmt = mysqli_prepare($conn, "INSERT INTO kategori_keuangan (nama_kategori, tipe) VALUES (?,?)");
        foreach ($default_kategori as $k) { mysqli_stmt_bind_param($stmt, 'ss', $k[0], $k[1]); mysqli_stmt_execute($stmt); }
    }

    // --- 7. KEUANGAN: tagihan SPP/komite bulanan per siswa ---
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'tagihan_spp'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE tagihan_spp (
          id INT AUTO_INCREMENT PRIMARY KEY,
          siswa_id INT NOT NULL,
          bulan CHAR(7) NOT NULL,
          jumlah_tagihan DECIMAL(12,2) NOT NULL DEFAULT 0,
          jumlah_dibayar DECIMAL(12,2) NOT NULL DEFAULT 0,
          status ENUM('Belum Bayar','Sebagian','Lunas') NOT NULL DEFAULT 'Belum Bayar',
          tanggal_bayar DATE DEFAULT NULL,
          dicatat_oleh INT DEFAULT NULL,
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY unik_tagihan (siswa_id, bulan),
          FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    // --- 8. KEUANGAN: buku kas (semua transaksi pemasukan & pengeluaran) ---
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'transaksi_keuangan'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE transaksi_keuangan (
          id INT AUTO_INCREMENT PRIMARY KEY,
          tanggal DATE NOT NULL,
          tipe ENUM('Pemasukan','Pengeluaran') NOT NULL,
          kategori_id INT DEFAULT NULL,
          keterangan VARCHAR(255) NOT NULL,
          jumlah DECIMAL(14,2) NOT NULL,
          metode ENUM('Tunai','Transfer') NOT NULL DEFAULT 'Tunai',
          bukti VARCHAR(255) DEFAULT NULL,
          tagihan_id INT DEFAULT NULL,
          dicatat_oleh INT DEFAULT NULL,
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (kategori_id) REFERENCES kategori_keuangan(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    // --- 9. KEUANGAN: gaji guru honorer (dibayar per jam, otomatis tercatat di Buku Kas) ---
    $t = mysqli_query($conn, "SHOW TABLES LIKE 'gaji_honorer'");
    if ($t && mysqli_num_rows($t) === 0) {
        mysqli_query($conn, "CREATE TABLE gaji_honorer (
          id INT AUTO_INCREMENT PRIMARY KEY,
          pegawai_id INT NOT NULL,
          bulan CHAR(7) NOT NULL,
          jam_dibayar DECIMAL(6,2) NOT NULL DEFAULT 0,
          tarif_per_jam DECIMAL(12,2) NOT NULL DEFAULT 0,
          tambahan DECIMAL(12,2) NOT NULL DEFAULT 0,
          potongan DECIMAL(12,2) NOT NULL DEFAULT 0,
          total_gaji DECIMAL(14,2) NOT NULL DEFAULT 0,
          catatan VARCHAR(255) DEFAULT NULL,
          status ENUM('Belum Dibayar','Sudah Dibayar') NOT NULL DEFAULT 'Belum Dibayar',
          tanggal_bayar DATE DEFAULT NULL,
          metode ENUM('Tunai','Transfer') DEFAULT NULL,
          dicatat_oleh INT DEFAULT NULL,
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY unik_gaji_honorer (pegawai_id, bulan),
          FOREIGN KEY (pegawai_id) REFERENCES pegawai(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    // penanda transaksi Buku Kas yang berasal dari pembayaran gaji honorer
    if (!$ada('transaksi_keuangan', 'gaji_id') && $ada('transaksi_keuangan', 'tagihan_id')) {
        mysqli_query($conn, "ALTER TABLE transaksi_keuangan ADD COLUMN gaji_id INT DEFAULT NULL AFTER tagihan_id");
    }
    // aturan honor bawaan: Rp 20.000 per jam, 18 jam dibayar per bulan (= 1 minggu mengajar)
    mysqli_query($conn, "INSERT IGNORE INTO pengaturan (nama_pengaturan, nilai_pengaturan) VALUES ('honor_tarif_per_jam','20000'), ('honor_jam_per_bulan','18')");

    // --- 10. ABSENSI: kolom bukti (foto/PDF surat sakit atau surat izin kegiatan) untuk siswa & pegawai ---
    if (!$ada('absensi_siswa', 'bukti') && $ada('absensi_siswa', 'keterangan')) {
        mysqli_query($conn, "ALTER TABLE absensi_siswa ADD COLUMN bukti VARCHAR(255) DEFAULT NULL AFTER keterangan");
    }
    if (!$ada('absensi_pegawai', 'bukti') && $ada('absensi_pegawai', 'keterangan')) {
        mysqli_query($conn, "ALTER TABLE absensi_pegawai ADD COLUMN bukti VARCHAR(255) DEFAULT NULL AFTER keterangan");
    }
    // jam batas otomatis tandai Alpa (siswa/pegawai yang sampai jam ini belum ada catatan absensi hari itu)
    mysqli_query($conn, "INSERT IGNORE INTO pengaturan (nama_pengaturan, nilai_pengaturan) VALUES ('jam_batas_alpa','14:00:00')");
})($conn);
