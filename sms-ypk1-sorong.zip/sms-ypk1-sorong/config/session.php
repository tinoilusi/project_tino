<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/koneksi.php';
require_once __DIR__ . '/../includes/functions.php';

function cek_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . 'login.php');
        exit;
    }
    // Tidak ada cron di hosting biasa, jadi pengecekan "siapa belum absen hari ini -> tandai Alpa"
    // dijalankan ringan di sini, setiap ada staf yang login/membuka halaman (aman & murah: hanya
    // benar-benar menulis data sekali per hari per orang, berkat NOT EXISTS + jam batas).
    global $conn;
    tandai_alpa_otomatis($conn);
}

function cek_role($allowed_roles) {
    cek_login();
    if (!in_array($_SESSION['role'], (array) $allowed_roles)) {
        include __DIR__ . '/../includes/akses_ditolak.php';
        exit;
    }
}

function is_kepsek() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'kepala_sekolah';
}

function is_bendahara() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'bendahara';
}

// true jika akun ini boleh mengelola modul Keuangan (Bendahara + Kepala Sekolah sebagai pengawas)
function bisa_akses_keuangan() {
    return in_array($_SESSION['role'] ?? '', ['bendahara', 'kepala_sekolah']);
}

// true jika akun ini adalah wali kelas (guru dengan kelas_id terpasang) atau Kepala Sekolah
function is_wali_kelas() {
    return $_SESSION['role'] === 'guru' && !empty($_SESSION['kelas_id']);
}
