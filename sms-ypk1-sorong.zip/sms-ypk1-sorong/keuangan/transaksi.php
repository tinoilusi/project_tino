<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'bendahara']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Buku Kas (Transaksi)';
$modul_aktif = 'keuangan';
$pesan = '';

// --- simpan / update transaksi ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan') {
    $tanggal    = $_POST['tanggal'];
    $tipe       = $_POST['tipe'] === 'Pengeluaran' ? 'Pengeluaran' : 'Pemasukan';
    $kategori_id = $_POST['kategori_id'] !== '' ? (int) $_POST['kategori_id'] : null;
    $keterangan = bersihkan($_POST['keterangan']);
    $jumlah     = (float) str_replace(['.', ','], ['', '.'], $_POST['jumlah']);
    $metode     = $_POST['metode'] === 'Transfer' ? 'Transfer' : 'Tunai';
    $id         = !empty($_POST['id']) ? (int) $_POST['id'] : null;
    $kunci_gaji = $id ? mysqli_fetch_assoc(mysqli_query($conn, "SELECT 1 FROM transaksi_keuangan t JOIN gaji_honorer g ON g.id=t.gaji_id WHERE t.id=$id")) : null;

    $bukti_baru = proses_upload_gambar('bukti', 'bukti_transaksi', 1200, 1200);

    if ($jumlah <= 0) {
        $pesan = 'Jumlah transaksi harus lebih dari 0.';
    } elseif ($kunci_gaji) {
        $pesan = 'Transaksi ini berasal dari pembayaran gaji guru honorer. Ubah atau batalkan lewat menu Gaji Guru Honorer agar data gaji tetap konsisten.';
    } elseif ($id) {
        if ($bukti_baru) {
            $stmt = mysqli_prepare($conn, "UPDATE transaksi_keuangan SET tanggal=?, tipe=?, kategori_id=?, keterangan=?, jumlah=?, metode=?, bukti=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'ssisdssi', $tanggal, $tipe, $kategori_id, $keterangan, $jumlah, $metode, $bukti_baru, $id);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE transaksi_keuangan SET tanggal=?, tipe=?, kategori_id=?, keterangan=?, jumlah=?, metode=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'ssisdsi', $tanggal, $tipe, $kategori_id, $keterangan, $jumlah, $metode, $id);
        }
        mysqli_stmt_execute($stmt);
        $pesan = 'Transaksi berhasil diperbarui.';
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO transaksi_keuangan (tanggal, tipe, kategori_id, keterangan, jumlah, metode, bukti, dicatat_oleh) VALUES (?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'ssisdssi', $tanggal, $tipe, $kategori_id, $keterangan, $jumlah, $metode, $bukti_baru, $_SESSION['user_id']);
        mysqli_stmt_execute($stmt);
        $pesan = 'Transaksi baru berhasil dicatat.';
    }
}

if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t.tagihan_id, g.id AS gaji_ada FROM transaksi_keuangan t LEFT JOIN gaji_honorer g ON g.id=t.gaji_id WHERE t.id=$id"));
    if ($cek && $cek['gaji_ada']) {
        $pesan = 'Transaksi ini berasal dari pembayaran gaji guru honorer. Batalkan pembayarannya lewat menu Gaji Guru Honorer, bukan dari sini.';
    } elseif ($cek && $cek['tagihan_id']) {
        $pesan = 'Transaksi ini berasal dari pembayaran SPP/Iuran Komite. Batalkan pembayarannya lewat menu SPP, bukan dari sini, agar data tagihan tetap konsisten.';
    } else {
        mysqli_query($conn, "DELETE FROM transaksi_keuangan WHERE id=$id");
        $pesan = 'Transaksi berhasil dihapus.';
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM transaksi_keuangan WHERE id=" . (int)$_GET['edit']));
}

$bulan = $_GET['bulan'] ?? date('Y-m');
$bulan = preg_match('/^\d{4}-\d{2}$/', $bulan) ? $bulan : date('Y-m');

$kategori_list = mysqli_query($conn, "SELECT id, nama_kategori, tipe FROM kategori_keuangan WHERE status_aktif=1 ORDER BY tipe DESC, nama_kategori");
$kategori_pemasukan = []; $kategori_pengeluaran = [];
while ($kk = mysqli_fetch_assoc($kategori_list)) {
    if ($kk['tipe'] === 'Pemasukan') $kategori_pemasukan[] = $kk; else $kategori_pengeluaran[] = $kk;
}

$list = mysqli_query($conn, "SELECT t.*, k.nama_kategori, g.id AS gaji_ada,
                                     COALESCE(p.nama, u.username) AS nama_pencatat
                              FROM transaksi_keuangan t
                              LEFT JOIN kategori_keuangan k ON k.id = t.kategori_id
                              LEFT JOIN gaji_honorer g ON g.id = t.gaji_id
                              LEFT JOIN users u ON u.id = t.dicatat_oleh
                              LEFT JOIN pegawai p ON p.id = u.pegawai_id
                              WHERE DATE_FORMAT(t.tanggal,'%Y-%m') = '$bulan'
                              ORDER BY t.tanggal DESC, t.id DESC");
$total_masuk = 0; $total_keluar = 0; $rows = [];
while ($r = mysqli_fetch_assoc($list)) {
    $rows[] = $r;
    if ($r['tipe'] === 'Pemasukan') $total_masuk += $r['jumlah']; else $total_keluar += $r['jumlah'];
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Buku Kas (Transaksi)</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3><?php echo $edit ? 'Edit Transaksi' : 'Catat Transaksi Baru'; ?></h3>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="aksi" value="simpan">
        <input type="hidden" name="id" value="<?php echo $edit['id'] ?? ''; ?>">
        <div class="grid grid-3">
          <div class="form-group">
            <label>Tanggal</label>
            <input type="date" name="tanggal" class="form-control" required value="<?php echo $edit['tanggal'] ?? date('Y-m-d'); ?>">
          </div>
          <div class="form-group">
            <label>Tipe</label>
            <select name="tipe" id="inputTipe" class="form-control" onchange="perbaruiKategori()">
              <option value="Pemasukan" <?php echo (($edit['tipe'] ?? '') === 'Pemasukan') ? 'selected' : ''; ?>>Pemasukan</option>
              <option value="Pengeluaran" <?php echo (($edit['tipe'] ?? '') === 'Pengeluaran') ? 'selected' : ''; ?>>Pengeluaran</option>
            </select>
          </div>
          <div class="form-group">
            <label>Kategori</label>
            <select name="kategori_id" id="inputKategori" class="form-control"></select>
          </div>
          <div class="form-group">
            <label>Keterangan</label>
            <input type="text" name="keterangan" class="form-control" required value="<?php echo bersihkan($edit['keterangan'] ?? ''); ?>" placeholder="contoh: Pembelian ATK bulan September">
          </div>
          <div class="form-group">
            <label>Jumlah (Rp)</label>
            <input type="text" name="jumlah" class="form-control" required value="<?php echo $edit ? (int)$edit['jumlah'] : ''; ?>" placeholder="contoh: 500000">
          </div>
          <div class="form-group">
            <label>Metode</label>
            <select name="metode" class="form-control">
              <option value="Tunai" <?php echo (($edit['metode'] ?? '') === 'Tunai') ? 'selected' : ''; ?>>Tunai</option>
              <option value="Transfer" <?php echo (($edit['metode'] ?? '') === 'Transfer') ? 'selected' : ''; ?>>Transfer</option>
            </select>
          </div>
          <div class="form-group">
            <label>Bukti / Struk (opsional)</label>
            <input type="file" name="bukti" class="form-control" accept="image/*">
            <?php if (!empty($edit['bukti'])): ?><div class="muted" style="margin-top:4px;">Sudah ada bukti tersimpan — unggah file baru untuk menggantinya.</div><?php endif; ?>
          </div>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $edit ? 'Simpan Perubahan' : '+ Catat Transaksi'; ?></button>
        <?php if ($edit): ?><a href="transaksi.php" class="btn btn-outline">Batal</a><?php endif; ?>
      </form>
    </div>

    <div class="card">
      <div class="flex-between" style="flex-wrap:wrap; gap:12px;">
        <h3 class="mb-0">Riwayat Transaksi</h3>
        <form method="GET" style="display:flex; gap:8px; align-items:center;">
          <input type="month" name="bulan" class="form-control" value="<?php echo bersihkan($bulan); ?>" onchange="this.form.submit()">
        </form>
      </div>
      <div class="grid grid-3" style="margin:16px 0;">
        <div class="stat-card green"><div class="label">Total Pemasukan</div><div class="value" style="font-size:19px;"><?php echo rupiah($total_masuk); ?></div></div>
        <div class="stat-card red"><div class="label">Total Pengeluaran</div><div class="value" style="font-size:19px;"><?php echo rupiah($total_keluar); ?></div></div>
        <div class="stat-card blue"><div class="label">Selisih Bulan Ini</div><div class="value" style="font-size:19px;"><?php echo rupiah($total_masuk - $total_keluar); ?></div></div>
      </div>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>Tipe</th><th>Kategori</th><th>Keterangan</th><th>Jumlah</th><th>Metode</th><th>Dicatat Oleh</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="8" class="muted" style="text-align:center; padding:20px;">Belum ada transaksi pada bulan ini.</td></tr>
        <?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?php echo format_tanggal_indo($r['tanggal']); ?></td>
            <td><span class="badge-status <?php echo $r['tipe']==='Pemasukan' ? 'badge-hadir' : 'badge-alpa'; ?>"><?php echo $r['tipe']; ?></span></td>
            <td><?php echo bersihkan($r['nama_kategori'] ?: '-'); ?></td>
            <td><?php echo bersihkan($r['keterangan']); ?><?php if ($r['tagihan_id']): ?> <span class="pill">Auto dari SPP</span><?php endif; ?><?php if ($r['gaji_ada']): ?> <span class="pill">Auto dari Gaji Honorer</span><?php endif; ?></td>
            <td style="font-weight:700; color:<?php echo $r['tipe']==='Pemasukan' ? '#1F9D55' : '#C0392B'; ?>;"><?php echo rupiah($r['jumlah']); ?></td>
            <td><?php echo bersihkan($r['metode']); ?></td>
            <td><?php echo bersihkan($r['nama_pencatat'] ?: '-'); ?></td>
            <td>
              <?php if ($r['bukti']): ?><a class="btn btn-outline btn-sm" href="<?php echo BASE_URL . 'assets/img/uploads/' . $r['bukti']; ?>" target="_blank">Bukti</a><?php endif; ?>
              <?php if (!$r['tagihan_id'] && !$r['gaji_ada']): ?>
                <a class="btn btn-outline btn-sm" href="?edit=<?php echo $r['id']; ?>&bulan=<?php echo $bulan; ?>">Edit</a>
                <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $r['id']; ?>&bulan=<?php echo $bulan; ?>" onclick="return confirm('Hapus transaksi ini?');">Hapus</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
<script>
var kategoriData = {
  Pemasukan: <?php echo json_encode($kategori_pemasukan); ?>,
  Pengeluaran: <?php echo json_encode($kategori_pengeluaran); ?>
};
var kategoriTerpilihAwal = <?php echo json_encode($edit['kategori_id'] ?? null); ?>;

function perbaruiKategori() {
  var tipe = document.getElementById('inputTipe').value;
  var select = document.getElementById('inputKategori');
  select.innerHTML = '<option value="">— Pilih Kategori —</option>';
  (kategoriData[tipe] || []).forEach(function (k) {
    var opt = document.createElement('option');
    opt.value = k.id;
    opt.textContent = k.nama_kategori;
    if (kategoriTerpilihAwal && String(kategoriTerpilihAwal) === String(k.id)) opt.selected = true;
    select.appendChild(opt);
  });
}
perbaruiKategori();
</script>
