<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'bendahara']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Dashboard Keuangan';
$modul_aktif = 'keuangan';
$bulan_ini = date('Y-m');

// --- Ringkasan kartu atas ---
$saldo_total  = (float) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(CASE WHEN tipe='Pemasukan' THEN jumlah ELSE -jumlah END),0) t FROM transaksi_keuangan"))['t'];
$masuk_bulan  = (float) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(jumlah),0) t FROM transaksi_keuangan WHERE tipe='Pemasukan' AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini'"))['t'];
$keluar_bulan = (float) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(jumlah),0) t FROM transaksi_keuangan WHERE tipe='Pengeluaran' AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini'"))['t'];
$gaji_bln = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) jml, COALESCE(SUM(total_gaji),0) total,
        COALESCE(SUM(CASE WHEN status='Belum Dibayar' THEN total_gaji ELSE 0 END),0) belum,
        COALESCE(SUM(status='Belum Dibayar'),0) jml_belum FROM gaji_honorer WHERE bulan='$bulan_ini'"));
$tunggak_spp  = (int) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM tagihan_spp WHERE bulan='$bulan_ini' AND status != 'Lunas'"))['c'];

// --- Grafik 6 bulan terakhir ---
$labels_bulan = []; $data_masuk = []; $data_keluar = [];
for ($i = 5; $i >= 0; $i--) {
    $b = date('Y-m', strtotime("-$i month"));
    $labels_bulan[] = date('M Y', strtotime($b . '-01'));
    $data_masuk[]  = (float) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(jumlah),0) t FROM transaksi_keuangan WHERE tipe='Pemasukan' AND DATE_FORMAT(tanggal,'%Y-%m')='$b'"))['t'];
    $data_keluar[] = (float) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(jumlah),0) t FROM transaksi_keuangan WHERE tipe='Pengeluaran' AND DATE_FORMAT(tanggal,'%Y-%m')='$b'"))['t'];
}

// --- Transaksi terbaru ---
$terbaru = mysqli_query($conn, "SELECT t.*, k.nama_kategori FROM transaksi_keuangan t
                                 LEFT JOIN kategori_keuangan k ON k.id = t.kategori_id
                                 ORDER BY t.tanggal DESC, t.id DESC LIMIT 8");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Dashboard Keuangan Sekolah &amp; Komite</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">

    <div class="card" style="background:linear-gradient(135deg,#0B3C5D,#082A42); color:#fff;">
      <div class="flex-between">
        <div>
          <div style="font-size:13px; opacity:.8;">Saldo Kas Sekolah/Komite Saat Ini</div>
          <div style="font-size:26px; font-weight:700;"><?php echo rupiah($saldo_total); ?></div>
        </div>
        <a href="<?php echo BASE_URL; ?>keuangan/transaksi.php" class="btn btn-gold btn-sm">+ Catat Transaksi</a>
      </div>
    </div>

    <div class="grid grid-4">
      <div class="stat-card green"><div class="label">Pemasukan Bulan Ini</div><div class="value" style="font-size:19px;"><?php echo rupiah($masuk_bulan); ?></div></div>
      <div class="stat-card red"><div class="label">Pengeluaran Bulan Ini</div><div class="value" style="font-size:19px;"><?php echo rupiah($keluar_bulan); ?></div></div>
      <div class="stat-card blue"><div class="label">Arus Kas Bersih Bulan Ini</div><div class="value" style="font-size:19px;"><?php echo rupiah($masuk_bulan - $keluar_bulan); ?></div></div>
      <div class="stat-card gold"><div class="label">Tunggakan SPP Bulan Ini</div><div class="value"><?php echo $tunggak_spp; ?> siswa</div></div>
    </div>

    <div class="card">
      <div class="flex-between">
        <div>
          <h3 style="margin-bottom:6px;">👩‍🏫 Gaji Guru Honorer — <?php echo bersihkan(nama_bulan_indo($bulan_ini)); ?></h3>
          <?php if ((int)$gaji_bln['jml'] === 0): ?>
            <div class="muted">Daftar gaji bulan ini belum dibuat. Honor: <?php echo format_jam(honor_jam_default($conn)); ?> jam × <?php echo rupiah(honor_tarif_default($conn)); ?> per guru.</div>
          <?php else: ?>
            <div class="muted"><?php echo (int)$gaji_bln['jml']; ?> guru · total <?php echo rupiah($gaji_bln['total']); ?> ·
              <?php echo (int)$gaji_bln['jml_belum'] > 0 ? '<strong style="color:#C0392B;">' . (int)$gaji_bln['jml_belum'] . ' guru belum dibayar (' . rupiah($gaji_bln['belum']) . ')</strong>' : '<strong style="color:#1F9D55;">semua sudah dibayar</strong>'; ?></div>
          <?php endif; ?>
        </div>
        <a href="<?php echo BASE_URL; ?>keuangan/gaji_honorer.php" class="btn btn-outline btn-sm">Kelola Gaji Honorer</a>
      </div>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>Arus Kas 6 Bulan Terakhir</h3>
        <canvas id="chartKeuangan" height="220"></canvas>
      </div>
      <div class="card">
        <div class="flex-between">
          <h3 class="mb-0">Transaksi Terbaru</h3>
          <a href="<?php echo BASE_URL; ?>keuangan/transaksi.php" class="btn btn-outline btn-sm">Lihat Semua</a>
        </div>
        <?php if (mysqli_num_rows($terbaru) === 0): ?>
          <p class="muted" style="margin-top:10px;">Belum ada transaksi tercatat.</p>
        <?php else: while ($t = mysqli_fetch_assoc($terbaru)): ?>
          <div style="padding:10px 0; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <div style="font-weight:600; font-size:13.5px;"><?php echo bersihkan($t['keterangan']); ?></div>
              <div class="muted" style="font-size:11.5px;"><?php echo bersihkan($t['nama_kategori'] ?: '-'); ?> · <?php echo format_tanggal_indo($t['tanggal']); ?></div>
            </div>
            <div style="font-weight:700; color:<?php echo $t['tipe']==='Pemasukan' ? '#1F9D55' : '#C0392B'; ?>;">
              <?php echo $t['tipe']==='Pemasukan' ? '+' : '-'; ?> <?php echo rupiah($t['jumlah']); ?>
            </div>
          </div>
        <?php endwhile; endif; ?>
      </div>
    </div>

    <div class="card">
      <h3>Akses Cepat</h3>
      <div class="grid grid-4">
        <a class="btn btn-outline" href="<?php echo BASE_URL; ?>keuangan/transaksi.php">💵 Buku Kas</a>
        <a class="btn btn-outline" href="<?php echo BASE_URL; ?>keuangan/spp.php">🧾 SPP / Iuran Komite</a>
        <a class="btn btn-outline" href="<?php echo BASE_URL; ?>keuangan/gaji_honorer.php">👩‍🏫 Gaji Guru Honorer</a>
        <a class="btn btn-outline" href="<?php echo BASE_URL; ?>keuangan/kategori.php">🗂️ Kategori Anggaran</a>
        <a class="btn btn-outline" href="<?php echo BASE_URL; ?>keuangan/laporan.php">🖨️ Cetak Laporan</a>
      </div>
    </div>

  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
<script src="<?php echo BASE_URL; ?>assets/js/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('chartKeuangan'), {
  type: 'bar',
  data: {
    labels: <?php echo json_encode($labels_bulan); ?>,
    datasets: [
      { label: 'Pemasukan', data: <?php echo json_encode($data_masuk); ?>, backgroundColor: '#1F9D55' },
      { label: 'Pengeluaran', data: <?php echo json_encode($data_keluar); ?>, backgroundColor: '#C0392B' }
    ]
  },
  options: { plugins: { legend: { position: 'bottom' } }, scales: { y: { beginAtZero: true } } }
});
</script>
