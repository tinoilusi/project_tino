<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'bendahara']);
require_once __DIR__ . '/../includes/functions.php';

$bulan = preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $_GET['bulan'] ?? '') ? $_GET['bulan'] : date('Y-m');
$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$alamat = get_setting($conn, 'alamat_sekolah') ?: 'Kota Sorong';
$logo_url = url_logo_sekolah($conn);

$res = mysqli_query($conn, "SELECT g.*, p.nama, p.nip_nuptk FROM gaji_honorer g JOIN pegawai p ON p.id=g.pegawai_id WHERE g.bulan='$bulan' ORDER BY p.nama");
$rows = []; $total = 0; $total_jam = 0;
while ($res && ($r = mysqli_fetch_assoc($res))) { $rows[] = $r; $total += $r['total_gaji']; $total_jam += $r['jam_dibayar']; }

$nama_kepsek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM pegawai WHERE jenis='Kepala Sekolah' AND status_aktif=1 LIMIT 1"))['nama'] ?? '';
$nama_bendahara = mysqli_fetch_assoc(mysqli_query($conn, "SELECT p.nama FROM users u JOIN pegawai p ON p.id=u.pegawai_id WHERE u.role='bendahara' AND u.status_aktif=1 LIMIT 1"))['nama'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rekap Gaji Guru Honorer <?php echo htmlspecialchars(nama_bulan_indo($bulan)); ?></title>
<style>
  *{ box-sizing:border-box; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  body{ font-family: Arial, Helvetica, sans-serif; font-size:13px; color:#1f2937; background:#eef1f4; margin:0; padding:16px; }
  .toolbar{ max-width:900px; margin:0 auto 14px; display:flex; justify-content:space-between; align-items:center; }
  .toolbar button{ background:#0B3C5D; color:#fff; border:0; border-radius:8px; padding:9px 16px; font-weight:700; cursor:pointer; }
  .lembar{ max-width:900px; margin:0 auto; background:#fff; border:1px solid #cfd6dd; border-radius:6px; padding:26px 30px; }
  .kop{ text-align:center; border-bottom:2px solid #0B3C5D; padding-bottom:12px; margin-bottom:16px; }
  .kop img{ width:52px; height:52px; object-fit:contain; margin-bottom:4px; }
  .kop .nm{ font-weight:800; color:#0B3C5D; font-size:16px; }
  .kop .jd{ font-size:13px; color:#6B7280; }
  .kop .pr{ font-size:13px; font-weight:700; margin-top:4px; }
  table{ width:100%; border-collapse:collapse; }
  th, td{ border:1px solid #cfd6dd; padding:7px 9px; text-align:left; vertical-align:middle; }
  th{ background:#EEF2F6; }
  .r{ text-align:right; } .c{ text-align:center; }
  tr.total td{ font-weight:800; background:#F3F5F7; }
  .ttd{ display:flex; justify-content:space-between; margin-top:34px; text-align:center; }
  .ttd > div{ width:44%; } .ttd .sp{ height:64px; }
  @media print{ body{ background:#fff; padding:0; } .toolbar{ display:none; } .lembar{ border:none; padding:0; } tr{ page-break-inside:avoid; } }
</style>
</head>
<body>
<div class="toolbar">
  <div><strong>Rekap Gaji Guru Honorer</strong></div>
  <button type="button" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
</div>
<div class="lembar">
  <div class="kop">
    <?php if ($logo_url): ?><img src="<?php echo $logo_url; ?>" alt="Logo"><?php endif; ?>
    <div class="nm"><?php echo tampil_db($nama_sekolah); ?></div>
    <div class="jd">DAFTAR PENERIMAAN HONOR GURU HONORER</div>
    <div class="pr">Periode: <?php echo htmlspecialchars(nama_bulan_indo($bulan)); ?></div>
  </div>

  <table>
    <thead>
      <tr><th class="c" style="width:36px;">No</th><th>Nama Guru</th><th>NIP / NUPTK</th><th class="c">Jam</th><th class="r">Honor/Jam</th><th class="r">Tambahan</th><th class="r">Potongan</th><th class="r">Total Diterima</th><th class="c" style="width:130px;">Tanda Tangan</th></tr>
    </thead>
    <tbody>
    <?php if (empty($rows)): ?><tr><td colspan="9" class="c" style="padding:18px;">Belum ada daftar gaji untuk bulan ini.</td></tr><?php endif; ?>
    <?php foreach ($rows as $i => $r): ?>
      <tr style="height:38px;">
        <td class="c"><?php echo $i + 1; ?></td>
        <td><?php echo tampil_db($r['nama']); ?></td>
        <td><?php echo tampil_db($r['nip_nuptk'] ?: '-'); ?></td>
        <td class="c"><?php echo format_jam($r['jam_dibayar']); ?></td>
        <td class="r"><?php echo rupiah($r['tarif_per_jam']); ?></td>
        <td class="r"><?php echo $r['tambahan'] > 0 ? rupiah($r['tambahan']) : '-'; ?></td>
        <td class="r"><?php echo $r['potongan'] > 0 ? rupiah($r['potongan']) : '-'; ?></td>
        <td class="r"><strong><?php echo rupiah($r['total_gaji']); ?></strong></td>
        <td></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!empty($rows)): ?>
      <tr class="total"><td colspan="3" class="r">TOTAL</td><td class="c"><?php echo format_jam($total_jam); ?></td><td colspan="3"></td><td class="r"><?php echo rupiah($total); ?></td><td></td></tr>
    <?php endif; ?>
    </tbody>
  </table>
  <?php if (!empty($rows)): ?><p style="margin-top:10px; font-style:italic;">Terbilang: <?php echo htmlspecialchars(terbilang_rupiah($total)); ?></p><?php endif; ?>

  <div class="ttd">
    <div>
      <div>Mengetahui,</div><div><strong>Kepala Sekolah</strong></div><div class="sp"></div>
      <div><strong><u><?php echo tampil_db($nama_kepsek ?: '.....................'); ?></u></strong></div>
    </div>
    <div>
      <div><?php echo tampil_db($alamat); ?>, <?php echo format_tanggal_indo(date('Y-m-d')); ?></div>
      <div><strong>Bendahara</strong></div><div class="sp"></div>
      <div><strong><u><?php echo tampil_db($nama_bendahara ?: '.....................'); ?></u></strong></div>
    </div>
  </div>
</div>
</body>
</html>
