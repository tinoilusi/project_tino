<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'bendahara']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'SPP / Iuran Komite';
$modul_aktif = 'keuangan';
$pesan = '';
$bulan = $_GET['bulan'] ?? date('Y-m');
$bulan = preg_match('/^\d{4}-\d{2}$/', $bulan) ? $bulan : date('Y-m');

// kategori "SPP / Iuran Komite" dipakai otomatis untuk pemasukan hasil pembayaran
$kategori_spp = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM kategori_keuangan WHERE nama_kategori='SPP / Iuran Komite' AND tipe='Pemasukan' LIMIT 1"));
$kategori_spp_id = $kategori_spp['id'] ?? null;

// --- 1. Generate tagihan massal untuk bulan terpilih ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'generate') {
    $bulan = preg_match('/^\d{4}-\d{2}$/', $_POST['bulan'] ?? '') ? $_POST['bulan'] : $bulan;
    $nominal = (float) str_replace(['.', ','], ['', '.'], $_POST['nominal']);
    $kelas_id = (int) $_POST['kelas_id'];
    if ($nominal <= 0) {
        $pesan = 'Nominal tagihan harus lebih dari 0.';
    } else {
        $filter_kelas = $kelas_id > 0 ? " AND kelas_id=$kelas_id" : '';
        $siswa_res = mysqli_query($conn, "SELECT id FROM siswa WHERE status='Aktif'$filter_kelas");
        $dibuat = 0;
        $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO tagihan_spp (siswa_id, bulan, jumlah_tagihan) VALUES (?,?,?)");
        while ($s = mysqli_fetch_assoc($siswa_res)) {
            mysqli_stmt_bind_param($stmt, 'isd', $s['id'], $bulan, $nominal);
            mysqli_stmt_execute($stmt);
            if (mysqli_stmt_affected_rows($stmt) > 0) $dibuat++;
        }
        $pesan = "Tagihan bulan " . date('F Y', strtotime($bulan . '-01')) . " berhasil dibuat untuk $dibuat siswa (siswa yang sudah punya tagihan bulan ini dilewati).";
    }
}

// --- 2. Catat pembayaran ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'bayar') {
    $tagihan_id = (int) $_POST['tagihan_id'];
    $jumlah_bayar = (float) str_replace(['.', ','], ['', '.'], $_POST['jumlah_bayar']);
    $tagihan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t.*, s.nama FROM tagihan_spp t JOIN siswa s ON s.id=t.siswa_id WHERE t.id=$tagihan_id"));

    if (!$tagihan || $jumlah_bayar <= 0) {
        $pesan = 'Data pembayaran tidak valid.';
    } else {
        $total_dibayar = (float)$tagihan['jumlah_dibayar'] + $jumlah_bayar;
        $status = $total_dibayar >= (float)$tagihan['jumlah_tagihan'] ? 'Lunas' : 'Sebagian';

        $stmt = mysqli_prepare($conn, "UPDATE tagihan_spp SET jumlah_dibayar=?, status=?, tanggal_bayar=?, dicatat_oleh=? WHERE id=?");
        $tgl_bayar = date('Y-m-d');
        mysqli_stmt_bind_param($stmt, 'dssii', $total_dibayar, $status, $tgl_bayar, $_SESSION['user_id'], $tagihan_id);
        mysqli_stmt_execute($stmt);

        $ket = 'Pembayaran SPP/Iuran Komite ' . date('F Y', strtotime($tagihan['bulan'] . '-01')) . ' — ' . $tagihan['nama'];
        $stmt2 = mysqli_prepare($conn, "INSERT INTO transaksi_keuangan (tanggal, tipe, kategori_id, keterangan, jumlah, metode, tagihan_id, dicatat_oleh) VALUES (?, 'Pemasukan', ?, ?, ?, 'Tunai', ?, ?)");
        mysqli_stmt_bind_param($stmt2, 'sisdii', $tgl_bayar, $kategori_spp_id, $ket, $jumlah_bayar, $tagihan_id, $_SESSION['user_id']);
        mysqli_stmt_execute($stmt2);

        $pesan = 'Pembayaran berhasil dicatat dan otomatis masuk ke Buku Kas.';
    }
}

// --- 3. Batalkan pembayaran (koreksi) ---
if (isset($_GET['batalkan_bayar'])) {
    $tagihan_id = (int) $_GET['batalkan_bayar'];
    mysqli_query($conn, "DELETE FROM transaksi_keuangan WHERE tagihan_id=$tagihan_id");
    mysqli_query($conn, "UPDATE tagihan_spp SET jumlah_dibayar=0, status='Belum Bayar', tanggal_bayar=NULL WHERE id=$tagihan_id");
    $pesan = 'Pembayaran dibatalkan, tagihan dikembalikan ke status Belum Bayar dan transaksi terkait di Buku Kas dihapus.';
}

$daftar_kelas = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY tingkat, nama_kelas");

$tagihan_list = mysqli_query($conn, "SELECT t.*, s.nama, s.nis, k.nama_kelas
                                      FROM tagihan_spp t
                                      JOIN siswa s ON s.id = t.siswa_id
                                      LEFT JOIN kelas k ON k.id = s.kelas_id
                                      WHERE t.bulan = '$bulan'
                                      ORDER BY k.tingkat, k.nama_kelas, s.nama");
$rows = []; $total_tagihan = 0; $total_dibayar = 0; $jml_lunas = 0; $jml_belum = 0; $jml_sebagian = 0;
while ($r = mysqli_fetch_assoc($tagihan_list)) {
    $rows[] = $r;
    $total_tagihan += $r['jumlah_tagihan'];
    $total_dibayar += $r['jumlah_dibayar'];
    if ($r['status'] === 'Lunas') $jml_lunas++;
    elseif ($r['status'] === 'Sebagian') $jml_sebagian++;
    else $jml_belum++;
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>SPP / Iuran Komite Siswa</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3>Buat Tagihan Bulanan</h3>
      <p class="muted">Buat tagihan SPP/iuran komite untuk semua siswa aktif (atau satu kelas saja) pada bulan tertentu. Siswa yang sudah memiliki tagihan pada bulan yang sama akan otomatis dilewati (tidak dobel).</p>
      <form method="POST" class="grid grid-4" style="align-items:end;">
        <input type="hidden" name="aksi" value="generate">
        <div class="form-group mb-0">
          <label>Bulan Tagihan</label>
          <input type="month" name="bulan" class="form-control" value="<?php echo bersihkan($bulan); ?>" required>
        </div>
        <div class="form-group mb-0">
          <label>Kelas</label>
          <select name="kelas_id" class="form-control">
            <option value="0">Semua Kelas</option>
            <?php mysqli_data_seek($daftar_kelas, 0); while ($k = mysqli_fetch_assoc($daftar_kelas)): ?>
              <option value="<?php echo $k['id']; ?>"><?php echo bersihkan($k['nama_kelas']); ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group mb-0">
          <label>Nominal per Siswa (Rp)</label>
          <input type="text" name="nominal" class="form-control" required placeholder="contoh: 150000">
        </div>
        <button type="submit" class="btn btn-primary">🧾 Buat Tagihan</button>
      </form>
    </div>

    <div class="card">
      <div class="flex-between" style="flex-wrap:wrap; gap:12px;">
        <h3 class="mb-0">Tagihan Bulan <?php echo bersihkan(date('F Y', strtotime($bulan . '-01'))); ?></h3>
        <form method="GET" style="display:flex; gap:8px;">
          <input type="month" name="bulan" class="form-control" value="<?php echo bersihkan($bulan); ?>" onchange="this.form.submit()">
        </form>
      </div>

      <div class="grid grid-4" style="margin:16px 0;">
        <div class="stat-card"><div class="label">Total Tagihan</div><div class="value" style="font-size:18px;"><?php echo rupiah($total_tagihan); ?></div></div>
        <div class="stat-card green"><div class="label">Sudah Terbayar</div><div class="value" style="font-size:18px;"><?php echo rupiah($total_dibayar); ?></div></div>
        <div class="stat-card gold"><div class="label">Lunas / Sebagian</div><div class="value"><?php echo $jml_lunas; ?> / <?php echo $jml_sebagian; ?></div></div>
        <div class="stat-card red"><div class="label">Belum Bayar</div><div class="value"><?php echo $jml_belum; ?> siswa</div></div>
      </div>

      <div class="table-wrap">
      <table>
        <thead><tr><th>Siswa</th><th>Kelas</th><th>Tagihan</th><th>Dibayar</th><th>Status</th><th>Tgl Bayar</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="7" class="muted" style="text-align:center; padding:20px;">Belum ada tagihan untuk bulan ini. Gunakan form di atas untuk membuatnya.</td></tr>
        <?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?php echo bersihkan($r['nama']); ?></td>
            <td><?php echo bersihkan($r['nama_kelas'] ?: '-'); ?></td>
            <td><?php echo rupiah($r['jumlah_tagihan']); ?></td>
            <td><?php echo rupiah($r['jumlah_dibayar']); ?></td>
            <td>
              <?php
                $bcls = $r['status'] === 'Lunas' ? 'badge-lunas' : ($r['status'] === 'Sebagian' ? 'badge-sebagian' : 'badge-belum-bayar');
                echo '<span class="badge-status ' . $bcls . '">' . bersihkan($r['status']) . '</span>';
              ?>
            </td>
            <td><?php echo $r['tanggal_bayar'] ? format_tanggal_indo($r['tanggal_bayar']) : '-'; ?></td>
            <td>
              <?php if ($r['status'] !== 'Lunas'): ?>
                <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('bayar-<?php echo $r['id']; ?>').style.display='flex'">Catat Bayar</button>
              <?php endif; ?>
              <?php if ($r['status'] !== 'Belum Bayar'): ?>
                <a class="btn btn-danger btn-sm" href="?batalkan_bayar=<?php echo $r['id']; ?>&bulan=<?php echo $bulan; ?>" onclick="return confirm('Batalkan pembayaran ini? Transaksi terkait di Buku Kas juga akan dihapus.');">Batalkan</a>
              <?php endif; ?>
              <form id="bayar-<?php echo $r['id']; ?>" method="POST" style="display:none; gap:6px; margin-top:8px;">
                <input type="hidden" name="aksi" value="bayar">
                <input type="hidden" name="tagihan_id" value="<?php echo $r['id']; ?>">
                <input type="text" name="jumlah_bayar" class="form-control" placeholder="Jumlah dibayar (Rp)" required style="width:160px; display:inline-block;">
                <button type="submit" class="btn btn-gold btn-sm">Simpan</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
