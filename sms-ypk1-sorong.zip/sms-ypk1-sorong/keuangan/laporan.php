<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'bendahara']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Cetak Laporan Keuangan';
$modul_aktif = 'keuangan';
$bulan = $_GET['bulan'] ?? date('Y-m');
$bulan = preg_match('/^\d{4}-\d{2}$/', $bulan) ? $bulan : date('Y-m');
$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$logo_url = url_logo_sekolah($conn);

// saldo awal = akumulasi seluruh transaksi SEBELUM bulan terpilih
$saldo_awal = (float) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(CASE WHEN tipe='Pemasukan' THEN jumlah ELSE -jumlah END),0) t
                                                                FROM transaksi_keuangan WHERE DATE_FORMAT(tanggal,'%Y-%m') < '$bulan'"))['t'];

$rekap_kategori = mysqli_query($conn, "SELECT k.nama_kategori, t.tipe, SUM(t.jumlah) AS total
                                        FROM transaksi_keuangan t
                                        LEFT JOIN kategori_keuangan k ON k.id = t.kategori_id
                                        WHERE DATE_FORMAT(t.tanggal,'%Y-%m') = '$bulan'
                                        GROUP BY t.kategori_id, t.tipe
                                        ORDER BY t.tipe DESC, total DESC");
$rincian_masuk = []; $rincian_keluar = []; $total_masuk = 0; $total_keluar = 0;
while ($r = mysqli_fetch_assoc($rekap_kategori)) {
    if ($r['tipe'] === 'Pemasukan') { $rincian_masuk[] = $r; $total_masuk += $r['total']; }
    else { $rincian_keluar[] = $r; $total_keluar += $r['total']; }
}
$saldo_akhir = $saldo_awal + $total_masuk - $total_keluar;

$detail = mysqli_query($conn, "SELECT t.*, k.nama_kategori FROM transaksi_keuangan t
                                LEFT JOIN kategori_keuangan k ON k.id = t.kategori_id
                                WHERE DATE_FORMAT(t.tanggal,'%Y-%m') = '$bulan'
                                ORDER BY t.tanggal, t.id");

$rincian_gaji = mysqli_query($conn, "SELECT p.nama, g.jam_dibayar, g.tarif_per_jam, g.total_gaji, g.tanggal_bayar
                                     FROM gaji_honorer g JOIN pegawai p ON p.id = g.pegawai_id
                                     WHERE g.bulan = '$bulan' AND g.status = 'Sudah Dibayar' ORDER BY p.nama");
$nama_kepsek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM pegawai WHERE jenis='Kepala Sekolah' AND status_aktif=1 LIMIT 1"))['nama'] ?? '(.....................)';
$nama_bendahara = mysqli_fetch_assoc(mysqli_query($conn, "SELECT p.nama FROM users u JOIN pegawai p ON p.id=u.pegawai_id WHERE u.role='bendahara' AND u.status_aktif=1 LIMIT 1"))['nama'] ?? '(.....................)';

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar no-print"><h2>Cetak Laporan Keuangan</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <div class="card no-print">
      <form method="GET" style="display:flex; gap:10px; align-items:end; flex-wrap:wrap;">
        <div class="form-group mb-0"><label>Pilih Bulan Laporan</label><input type="month" name="bulan" class="form-control" value="<?php echo bersihkan($bulan); ?>"></div>
        <button type="submit" class="btn btn-outline">Tampilkan</button>
        <button type="button" class="btn btn-primary" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
      </form>
    </div>

    <div class="card" id="lembarLaporan" style="max-width:820px; margin:0 auto;">
      <div style="text-align:center; border-bottom:2px solid var(--navy); padding-bottom:14px; margin-bottom:18px;">
        <?php if ($logo_url): ?><img src="<?php echo $logo_url; ?>" style="width:52px; height:52px; object-fit:contain; margin-bottom:6px;"><?php endif; ?>
        <div style="font-weight:800; color:var(--navy); font-size:16px;"><?php echo bersihkan($nama_sekolah); ?></div>
        <div style="font-size:13px; color:var(--text-muted);">LAPORAN KEUANGAN SEKOLAH &amp; KOMITE</div>
        <div style="font-size:13px; font-weight:700; margin-top:4px;">Periode: <?php echo bersihkan(date('F Y', strtotime($bulan . '-01'))); ?></div>
      </div>

      <div class="grid grid-3" style="margin-bottom:18px;">
        <div class="stat-card"><div class="label">Saldo Awal Bulan</div><div class="value" style="font-size:17px;"><?php echo rupiah($saldo_awal); ?></div></div>
        <div class="stat-card green"><div class="label">Total Pemasukan</div><div class="value" style="font-size:17px;"><?php echo rupiah($total_masuk); ?></div></div>
        <div class="stat-card red"><div class="label">Total Pengeluaran</div><div class="value" style="font-size:17px;"><?php echo rupiah($total_keluar); ?></div></div>
      </div>
      <div class="stat-card blue" style="margin-bottom:22px;"><div class="label">Saldo Akhir Bulan</div><div class="value" style="font-size:22px;"><?php echo rupiah($saldo_akhir); ?></div></div>

      <h3 style="margin-bottom:8px;">Rincian Pemasukan per Kategori</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Kategori</th><th style="text-align:right;">Jumlah</th></tr></thead>
        <tbody>
        <?php if (empty($rincian_masuk)): ?><tr><td colspan="2" class="muted">Tidak ada pemasukan bulan ini.</td></tr><?php endif; ?>
        <?php foreach ($rincian_masuk as $r): ?>
          <tr><td><?php echo bersihkan($r['nama_kategori'] ?: 'Tanpa kategori'); ?></td><td style="text-align:right;"><?php echo rupiah($r['total']); ?></td></tr>
        <?php endforeach; ?>
        <tr style="font-weight:700; background:#F3F5F7;"><td>Total Pemasukan</td><td style="text-align:right;"><?php echo rupiah($total_masuk); ?></td></tr>
        </tbody>
      </table>
      </div>

      <h3 style="margin:20px 0 8px;">Rincian Pengeluaran per Kategori</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Kategori</th><th style="text-align:right;">Jumlah</th></tr></thead>
        <tbody>
        <?php if (empty($rincian_keluar)): ?><tr><td colspan="2" class="muted">Tidak ada pengeluaran bulan ini.</td></tr><?php endif; ?>
        <?php foreach ($rincian_keluar as $r): ?>
          <tr><td><?php echo bersihkan($r['nama_kategori'] ?: 'Tanpa kategori'); ?></td><td style="text-align:right;"><?php echo rupiah($r['total']); ?></td></tr>
        <?php endforeach; ?>
        <tr style="font-weight:700; background:#F3F5F7;"><td>Total Pengeluaran</td><td style="text-align:right;"><?php echo rupiah($total_keluar); ?></td></tr>
        </tbody>
      </table>
      </div>

      <?php if ($rincian_gaji && mysqli_num_rows($rincian_gaji) > 0): $tot_gaji = 0; ?>
      <h3 style="margin:20px 0 8px;">Rincian Honor Guru Honorer (Periode <?php echo bersihkan(nama_bulan_indo($bulan)); ?>)</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Nama Guru</th><th>Jam</th><th>Honor/Jam</th><th>Tgl Bayar</th><th style="text-align:right;">Diterima</th></tr></thead>
        <tbody>
        <?php while ($g = mysqli_fetch_assoc($rincian_gaji)): $tot_gaji += $g['total_gaji']; ?>
          <tr>
            <td><?php echo tampil_db($g['nama']); ?></td>
            <td><?php echo format_jam($g['jam_dibayar']); ?></td>
            <td><?php echo rupiah($g['tarif_per_jam']); ?></td>
            <td><?php echo date('d/m/Y', strtotime($g['tanggal_bayar'])); ?></td>
            <td style="text-align:right;"><?php echo rupiah($g['total_gaji']); ?></td>
          </tr>
        <?php endwhile; ?>
        <tr style="font-weight:700; background:#F3F5F7;"><td colspan="4">Total Honor Guru Honorer</td><td style="text-align:right;"><?php echo rupiah($tot_gaji); ?></td></tr>
        </tbody>
      </table>
      </div>
      <?php endif; ?>

      <h3 style="margin:20px 0 8px;">Detail Transaksi Harian</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>Tipe</th><th>Kategori</th><th>Keterangan</th><th style="text-align:right;">Jumlah</th></tr></thead>
        <tbody>
        <?php mysqli_data_seek($detail, 0); if (mysqli_num_rows($detail) === 0): ?><tr><td colspan="5" class="muted">Tidak ada transaksi.</td></tr><?php endif; ?>
        <?php while ($d = mysqli_fetch_assoc($detail)): ?>
          <tr>
            <td><?php echo date('d/m/Y', strtotime($d['tanggal'])); ?></td>
            <td><?php echo bersihkan($d['tipe']); ?></td>
            <td><?php echo bersihkan($d['nama_kategori'] ?: '-'); ?></td>
            <td><?php echo bersihkan($d['keterangan']); ?></td>
            <td style="text-align:right;"><?php echo $d['tipe']==='Pemasukan' ? '' : '-'; ?><?php echo rupiah($d['jumlah']); ?></td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>

      <div class="grid grid-2" style="margin-top:50px; text-align:center;">
        <div>
          <div>Mengetahui,</div>
          <div style="font-weight:700; margin-top:4px;">Kepala Sekolah</div>
          <div style="height:70px;"></div>
          <div style="font-weight:700; text-decoration:underline;"><?php echo bersihkan($nama_kepsek); ?></div>
        </div>
        <div>
          <div><?php echo bersihkan(get_setting($conn,'alamat_sekolah') ?: 'Kota Sorong'); ?>, <?php echo format_tanggal_indo(date('Y-m-d')); ?></div>
          <div style="font-weight:700; margin-top:4px;">Bendahara</div>
          <div style="height:70px;"></div>
          <div style="font-weight:700; text-decoration:underline;"><?php echo bersihkan($nama_bendahara); ?></div>
        </div>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
<style>
@media print {
  *{ -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; color-adjust:exact !important; }
  .sidebar, .mobile-toggle, .no-print { display:none !important; }
  .main-content { margin:0 !important; width:100% !important; }
  body { background:#fff; }
  #lembarLaporan { box-shadow:none; border:none; }
}
</style>
