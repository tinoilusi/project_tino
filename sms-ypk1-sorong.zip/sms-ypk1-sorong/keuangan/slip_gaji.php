<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'bendahara']);
require_once __DIR__ . '/../includes/functions.php';

$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$alamat = get_setting($conn, 'alamat_sekolah') ?: 'Kota Sorong';
$logo_url = url_logo_sekolah($conn);

// satu slip (?id=) atau semua slip pada satu bulan (?bulan=)
if (isset($_GET['id'])) {
    $where = 'g.id=' . (int) $_GET['id'];
} else {
    $bulan = preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $_GET['bulan'] ?? '') ? $_GET['bulan'] : date('Y-m');
    $where = "g.bulan='$bulan'";
}
$res = mysqli_query($conn, "SELECT g.*, p.nama, p.nip_nuptk FROM gaji_honorer g JOIN pegawai p ON p.id=g.pegawai_id WHERE $where ORDER BY p.nama");
$slips = [];
while ($res && ($r = mysqli_fetch_assoc($res))) $slips[] = $r;

$nama_bendahara = mysqli_fetch_assoc(mysqli_query($conn, "SELECT p.nama FROM users u JOIN pegawai p ON p.id=u.pegawai_id WHERE u.role='bendahara' AND u.status_aktif=1 LIMIT 1"))['nama'] ?? '';
$nama_kepsek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM pegawai WHERE jenis='Kepala Sekolah' AND status_aktif=1 LIMIT 1"))['nama'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Slip Honor Guru — <?php echo tampil_db($nama_sekolah); ?></title>
<style>
  *{ box-sizing:border-box; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  body{ font-family: Arial, Helvetica, sans-serif; font-size:13px; color:#1f2937; background:#eef1f4; margin:0; padding:16px; }
  .toolbar{ max-width:720px; margin:0 auto 14px; display:flex; gap:8px; align-items:center; justify-content:space-between; }
  .toolbar button{ background:#0B3C5D; color:#fff; border:0; border-radius:8px; padding:9px 16px; font-weight:700; cursor:pointer; }
  .slip{ max-width:720px; margin:0 auto 18px; background:#fff; border:1px solid #cfd6dd; border-radius:6px; padding:22px 26px; page-break-inside:avoid; break-inside:avoid; }
  .kop{ display:flex; align-items:center; gap:12px; border-bottom:2px solid #0B3C5D; padding-bottom:10px; margin-bottom:12px; }
  .kop img{ width:48px; height:48px; object-fit:contain; }
  .kop .nm{ font-weight:800; color:#0B3C5D; font-size:15px; }
  .kop .al{ font-size:11.5px; color:#6B7280; }
  h2{ text-align:center; margin:4px 0 2px; font-size:15px; letter-spacing:.5px; }
  .periode{ text-align:center; font-weight:700; margin-bottom:12px; }
  table{ width:100%; border-collapse:collapse; }
  .info td{ padding:3px 0; vertical-align:top; }
  .info td:first-child{ width:150px; color:#6B7280; }
  .rinci{ margin-top:10px; }
  .rinci th, .rinci td{ border:1px solid #cfd6dd; padding:7px 10px; text-align:left; }
  .rinci th{ background:#EEF2F6; }
  .rinci td.r, .rinci th.r{ text-align:right; }
  .rinci tr.total td{ font-weight:800; background:#F3F5F7; font-size:14px; }
  .terbilang{ margin-top:10px; font-style:italic; }
  .ttd{ display:flex; justify-content:space-between; margin-top:22px; text-align:center; }
  .ttd > div{ width:44%; }
  .ttd .sp{ height:56px; }
  .status{ display:inline-block; padding:2px 10px; border-radius:20px; font-size:11.5px; font-weight:700; color:#fff; }
  .lunas{ background:#1F9D55; } .belum{ background:#C0392B; }
  @media print{
    body{ background:#fff; padding:0; }
    .toolbar{ display:none; }
    .slip{ margin:0 auto 10mm; border:1px solid #999; }
  }
</style>
</head>
<body>
<div class="toolbar">
  <div><strong>Slip Honor Guru Honorer</strong> — <?php echo count($slips); ?> slip</div>
  <button type="button" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
</div>

<?php if (empty($slips)): ?>
  <div class="slip">Data gaji tidak ditemukan. Buat daftar gaji terlebih dahulu di menu <strong>Gaji Guru Honorer</strong>.</div>
<?php endif; ?>

<?php foreach ($slips as $s): $sudah = $s['status'] === 'Sudah Dibayar'; $pokok = $s['jam_dibayar'] * $s['tarif_per_jam']; ?>
<div class="slip">
  <div class="kop">
    <?php if ($logo_url): ?><img src="<?php echo $logo_url; ?>" alt="Logo"><?php endif; ?>
    <div>
      <div class="nm"><?php echo tampil_db($nama_sekolah); ?></div>
      <div class="al"><?php echo tampil_db($alamat); ?></div>
    </div>
  </div>
  <h2>SLIP HONOR GURU HONORER</h2>
  <div class="periode">Periode: <?php echo htmlspecialchars(nama_bulan_indo($s['bulan'])); ?></div>

  <table class="info">
    <tr><td>Nama</td><td>: <strong><?php echo tampil_db($s['nama']); ?></strong></td></tr>
    <tr><td>NIP / NUPTK</td><td>: <?php echo tampil_db($s['nip_nuptk'] ?: '-'); ?></td></tr>
    <tr><td>Status</td><td>: Guru Honorer</td></tr>
    <tr><td>Status Pembayaran</td><td>: <span class="status <?php echo $sudah ? 'lunas' : 'belum'; ?>"><?php echo $sudah ? 'Sudah Dibayar' : 'Belum Dibayar'; ?></span>
      <?php if ($sudah): ?> pada <?php echo format_tanggal_indo($s['tanggal_bayar']); ?> (<?php echo htmlspecialchars($s['metode']); ?>)<?php endif; ?></td></tr>
  </table>

  <table class="rinci">
    <thead><tr><th>Rincian</th><th class="r">Jumlah</th></tr></thead>
    <tbody>
      <tr><td>Honor mengajar: <?php echo format_jam($s['jam_dibayar']); ?> jam × <?php echo rupiah($s['tarif_per_jam']); ?></td><td class="r"><?php echo rupiah($pokok); ?></td></tr>
      <?php if ($s['tambahan'] > 0): ?><tr><td>Tambahan</td><td class="r"><?php echo rupiah($s['tambahan']); ?></td></tr><?php endif; ?>
      <?php if ($s['potongan'] > 0): ?><tr><td>Potongan</td><td class="r">- <?php echo rupiah($s['potongan']); ?></td></tr><?php endif; ?>
      <tr class="total"><td>TOTAL DITERIMA</td><td class="r"><?php echo rupiah($s['total_gaji']); ?></td></tr>
    </tbody>
  </table>
  <div class="terbilang">Terbilang: <?php echo htmlspecialchars(terbilang_rupiah($s['total_gaji'])); ?></div>
  <?php if ($s['catatan']): ?><div style="margin-top:6px; color:#6B7280;">Catatan: <?php echo tampil_db($s['catatan']); ?></div><?php endif; ?>

  <div class="ttd">
    <div>
      <div>Penerima,</div><div class="sp"></div>
      <div><strong><u><?php echo tampil_db($s['nama']); ?></u></strong></div>
    </div>
    <div>
      <div><?php echo tampil_db($alamat); ?>, <?php echo format_tanggal_indo($sudah ? $s['tanggal_bayar'] : date('Y-m-d')); ?></div>
      <div>Bendahara,</div><div class="sp"></div>
      <div><strong><u><?php echo tampil_db($nama_bendahara ?: '.....................'); ?></u></strong></div>
    </div>
  </div>
</div>
<?php endforeach; ?>
</body>
</html>
