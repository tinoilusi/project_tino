<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'bendahara']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Gaji Guru Honorer';
$modul_aktif = 'keuangan';

$bulan = $_POST['bulan'] ?? $_GET['bulan'] ?? date('Y-m');
$bulan = preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $bulan) ? $bulan : date('Y-m');
$label_bulan = nama_bulan_indo($bulan);
$url_halaman = 'gaji_honorer.php?bulan=' . $bulan;
$uid = (int) $_SESSION['user_id'];

// simpan pesan lalu kembali ke halaman (mencegah pembayaran terkirim dobel saat halaman di-refresh)
function flash_dan_kembali($ok, $teks, $url) {
    $_SESSION['flash_gaji'] = ['ok' => $ok, 'teks' => $teks];
    header('Location: ' . $url);
    exit;
}

// =====================================================================
// PROSES AKSI (semua lewat POST)
// =====================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    // --- 1. Simpan aturan honor (tarif per jam & jam dibayar per bulan) ---
    if ($aksi === 'simpan_aturan') {
        $tarif = parse_rupiah($_POST['tarif'] ?? '');
        $jam   = parse_desimal($_POST['jam'] ?? '');
        if ($tarif <= 0 || $jam <= 0) {
            flash_dan_kembali(false, 'Tarif per jam dan jam dibayar per bulan harus lebih dari 0.', $url_halaman);
        }
        set_setting($conn, 'honor_tarif_per_jam', (string) (int) round($tarif));
        set_setting($conn, 'honor_jam_per_bulan', (string) $jam);
        flash_dan_kembali(true, 'Aturan honor disimpan: ' . format_jam($jam) . ' jam × ' . rupiah($tarif) . ' = ' . rupiah($jam * $tarif) . ' per guru per bulan. Berlaku untuk daftar gaji yang dibuat setelah ini.', $url_halaman);
    }

    // --- 2. Buat daftar gaji bulan terpilih untuk semua guru honorer aktif ---
    if ($aksi === 'generate') {
        $tarif = honor_tarif_default($conn);
        $jam   = honor_jam_default($conn);
        $total = round($jam * $tarif, 2);
        $guru  = mysqli_query($conn, "SELECT id FROM pegawai WHERE jenis='Guru' AND status_kepegawaian='Honorer' AND status_aktif=1");
        if (!$guru || mysqli_num_rows($guru) === 0) {
            flash_dan_kembali(false, 'Belum ada guru berstatus Honorer yang aktif. Atur status kepegawaian guru di menu Manajemen Sekolah → Data Guru & Staf (oleh Kepala Sekolah).', $url_halaman);
        }
        $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO gaji_honorer (pegawai_id, bulan, jam_dibayar, tarif_per_jam, total_gaji, dicatat_oleh) VALUES (?,?,?,?,?,?)");
        $dibuat = 0;
        while ($g = mysqli_fetch_assoc($guru)) {
            $pid = (int) $g['id'];
            mysqli_stmt_bind_param($stmt, 'isdddi', $pid, $bulan, $jam, $tarif, $total, $uid);
            mysqli_stmt_execute($stmt);
            if (mysqli_stmt_affected_rows($stmt) > 0) $dibuat++;
        }
        if ($dibuat > 0) {
            flash_dan_kembali(true, "Daftar gaji $label_bulan dibuat untuk $dibuat guru honorer (" . format_jam($jam) . ' jam × ' . rupiah($tarif) . ' = ' . rupiah($total) . ' per guru).', $url_halaman);
        }
        flash_dan_kembali(true, "Semua guru honorer aktif sudah ada di daftar gaji $label_bulan. Tidak ada yang ditambahkan.", $url_halaman);
    }

    // --- 3. Ubah baris gaji (jam, tarif, tambahan, potongan, catatan) — hanya yang belum dibayar ---
    if ($aksi === 'update_baris') {
        $id       = (int) ($_POST['id'] ?? 0);
        $jam      = parse_desimal($_POST['jam'] ?? '');
        $tarif    = parse_rupiah($_POST['tarif'] ?? '');
        $tambahan = parse_rupiah($_POST['tambahan'] ?? '');
        $potongan = parse_rupiah($_POST['potongan'] ?? '');
        $catatan  = mb_substr(bersihkan($_POST['catatan'] ?? ''), 0, 255);
        $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT status FROM gaji_honorer WHERE id=$id"));
        if (!$row) flash_dan_kembali(false, 'Data gaji tidak ditemukan.', $url_halaman);
        if ($row['status'] === 'Sudah Dibayar') flash_dan_kembali(false, 'Gaji yang sudah dibayar tidak bisa diubah. Batalkan pembayarannya lebih dulu bila ingin mengoreksi.', $url_halaman);
        if ($tarif <= 0) flash_dan_kembali(false, 'Tarif per jam harus lebih dari 0.', $url_halaman);
        $total = max(0, round($jam * $tarif + $tambahan - $potongan, 2));
        $stmt = mysqli_prepare($conn, "UPDATE gaji_honorer SET jam_dibayar=?, tarif_per_jam=?, tambahan=?, potongan=?, total_gaji=?, catatan=? WHERE id=? AND status='Belum Dibayar'");
        mysqli_stmt_bind_param($stmt, 'dddddsi', $jam, $tarif, $tambahan, $potongan, $total, $catatan, $id);
        mysqli_stmt_execute($stmt);
        flash_dan_kembali(true, 'Data gaji diperbarui. Total diterima: ' . rupiah($total) . '.', $url_halaman);
    }

    // --- 4. Bayar (satu guru / semua yang belum dibayar) → otomatis tercatat sebagai Pengeluaran di Buku Kas ---
    if ($aksi === 'bayar' || $aksi === 'bayar_semua') {
        $metode = ($_POST['metode'] ?? '') === 'Transfer' ? 'Transfer' : 'Tunai';
        $tgl    = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['tanggal'] ?? '') ? $_POST['tanggal'] : date('Y-m-d');
        $kat    = kategori_gaji_id($conn);
        $where  = $aksi === 'bayar' ? 'g.id=' . (int) ($_POST['id'] ?? 0) : "g.bulan='$bulan'";

        mysqli_begin_transaction($conn);
        $res = mysqli_query($conn, "SELECT g.*, p.nama FROM gaji_honorer g JOIN pegawai p ON p.id = g.pegawai_id
                                    WHERE $where AND g.status='Belum Dibayar' AND g.total_gaji > 0 FOR UPDATE");
        $daftar = [];
        while ($res && ($r = mysqli_fetch_assoc($res))) $daftar[] = $r;
        if (empty($daftar)) {
            mysqli_rollback($conn);
            flash_dan_kembali(false, 'Tidak ada gaji yang perlu dibayar (mungkin sudah dibayar, atau totalnya Rp 0).', $url_halaman);
        }

        $gagal = false; $jumlah_dibayar = 0;
        $st_trx = mysqli_prepare($conn, "INSERT INTO transaksi_keuangan (tanggal, tipe, kategori_id, keterangan, jumlah, metode, gaji_id, dicatat_oleh) VALUES (?, 'Pengeluaran', ?, ?, ?, ?, ?, ?)");
        $st_gaji = mysqli_prepare($conn, "UPDATE gaji_honorer SET status='Sudah Dibayar', tanggal_bayar=?, metode=?, dicatat_oleh=? WHERE id=?");
        foreach ($daftar as $r) {
            $gid = (int) $r['id'];
            $jml = (float) $r['total_gaji'];
            $ket = 'Gaji honorer ' . html_entity_decode($r['nama'], ENT_QUOTES, 'UTF-8') . ' — ' . format_jam($r['jam_dibayar']) . ' jam × ' . rupiah($r['tarif_per_jam']) . ' (' . nama_bulan_indo($r['bulan']) . ')';
            mysqli_stmt_bind_param($st_trx, 'sisdsii', $tgl, $kat, $ket, $jml, $metode, $gid, $uid);
            if (!mysqli_stmt_execute($st_trx)) { $gagal = true; break; }
            mysqli_stmt_bind_param($st_gaji, 'ssii', $tgl, $metode, $uid, $gid);
            if (!mysqli_stmt_execute($st_gaji)) { $gagal = true; break; }
            $jumlah_dibayar += $jml;
        }
        if ($gagal) {
            mysqli_rollback($conn);
            flash_dan_kembali(false, 'Pembayaran gagal disimpan, tidak ada data yang berubah. Coba lagi.', $url_halaman);
        }
        mysqli_commit($conn);

        $saldo = (float) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(CASE WHEN tipe='Pemasukan' THEN jumlah ELSE -jumlah END),0) t FROM transaksi_keuangan"))['t'];
        $teks = count($daftar) . ' gaji guru honorer dibayar (' . rupiah($jumlah_dibayar) . ', ' . $metode . ') dan otomatis tercatat sebagai pengeluaran di Buku Kas.';
        if ($saldo < 0) $teks .= ' Perhatian: saldo kas sekarang negatif (' . rupiah($saldo) . '). Pastikan pemasukan sudah dicatat.';
        flash_dan_kembali(true, $teks, $url_halaman);
    }

    // --- 5. Batalkan pembayaran (koreksi) ---
    if ($aksi === 'batalkan') {
        $id = (int) ($_POST['id'] ?? 0);
        mysqli_begin_transaction($conn);
        mysqli_query($conn, "DELETE FROM transaksi_keuangan WHERE gaji_id=$id");
        mysqli_query($conn, "UPDATE gaji_honorer SET status='Belum Dibayar', tanggal_bayar=NULL, metode=NULL WHERE id=$id AND status='Sudah Dibayar'");
        if (mysqli_affected_rows($conn) < 1) {
            mysqli_rollback($conn);
            flash_dan_kembali(false, 'Data gaji tidak ditemukan atau belum dibayar.', $url_halaman);
        }
        mysqli_commit($conn);
        flash_dan_kembali(true, 'Pembayaran dibatalkan. Gaji kembali berstatus Belum Dibayar dan transaksi terkait di Buku Kas dihapus.', $url_halaman);
    }

    // --- 6. Hapus baris gaji (hanya yang belum dibayar) ---
    if ($aksi === 'hapus') {
        $id = (int) ($_POST['id'] ?? 0);
        mysqli_query($conn, "DELETE FROM gaji_honorer WHERE id=$id AND status='Belum Dibayar'");
        if (mysqli_affected_rows($conn) > 0) flash_dan_kembali(true, 'Baris gaji dihapus dari daftar bulan ini.', $url_halaman);
        flash_dan_kembali(false, 'Baris gaji tidak dapat dihapus (sudah dibayar atau tidak ditemukan).', $url_halaman);
    }

    flash_dan_kembali(false, 'Aksi tidak dikenali.', $url_halaman);
}

// =====================================================================
// DATA TAMPILAN
// =====================================================================
$flash = $_SESSION['flash_gaji'] ?? null;
unset($_SESSION['flash_gaji']);

$tarif_default = honor_tarif_default($conn);
$jam_default   = honor_jam_default($conn);

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT g.*, p.nama FROM gaji_honorer g JOIN pegawai p ON p.id=g.pegawai_id
                                                    WHERE g.id=" . (int) $_GET['edit'] . " AND g.status='Belum Dibayar'"));
}

$res = mysqli_query($conn, "SELECT g.*, p.nama, p.nip_nuptk FROM gaji_honorer g JOIN pegawai p ON p.id = g.pegawai_id
                            WHERE g.bulan='$bulan' ORDER BY p.nama");
$rows = []; $tot_semua = 0; $tot_dibayar = 0; $tot_belum = 0; $jml_belum = 0; $jml_sudah = 0;
while ($res && ($r = mysqli_fetch_assoc($res))) {
    $rows[] = $r;
    $tot_semua += $r['total_gaji'];
    if ($r['status'] === 'Sudah Dibayar') { $tot_dibayar += $r['total_gaji']; $jml_sudah++; }
    else { $tot_belum += $r['total_gaji']; $jml_belum++; }
}

$belum_masuk = (int) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM pegawai p
    WHERE p.jenis='Guru' AND p.status_kepegawaian='Honorer' AND p.status_aktif=1
      AND NOT EXISTS (SELECT 1 FROM gaji_honorer g WHERE g.pegawai_id=p.id AND g.bulan='$bulan')"))['c'];

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Gaji Guru Honorer</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($flash): ?>
      <div class="alert <?php echo $flash['ok'] ? 'alert-success' : 'alert-error'; ?>"><?php echo htmlspecialchars($flash['teks']); ?></div>
    <?php endif; ?>

    <!-- ATURAN HONOR -->
    <div class="card">
      <div class="flex-between">
        <h3 class="mb-0">Aturan Honor Guru Honorer</h3>
        <span class="pill"><?php echo format_jam($jam_default); ?> jam × <?php echo rupiah($tarif_default); ?> = <?php echo rupiah($jam_default * $tarif_default); ?> / guru / bulan</span>
      </div>
      <p class="muted" style="margin:10px 0 14px;">
        Guru honorer dibayar per jam mengajar. Dalam sebulan yang dibayar hanya jam mengajar <strong>1 minggu</strong>
        (bawaan 18 jam). Angka ini menjadi nilai awal saat daftar gaji dibuat; tiap guru tetap bisa disesuaikan lewat tombol <em>Edit</em>
        (mis. jam mengajarnya berbeda). Perubahan aturan tidak mengubah gaji yang sudah dibuat sebelumnya.
      </p>
      <form method="POST" class="grid grid-3" style="align-items:end;">
        <input type="hidden" name="aksi" value="simpan_aturan">
        <input type="hidden" name="bulan" value="<?php echo bersihkan($bulan); ?>">
        <div class="form-group mb-0">
          <label>Honor per Jam (Rp)</label>
          <input type="text" name="tarif" class="form-control" required value="<?php echo (int) $tarif_default; ?>" inputmode="numeric">
        </div>
        <div class="form-group mb-0">
          <label>Jam Dibayar per Bulan (1 minggu)</label>
          <input type="text" name="jam" class="form-control" required value="<?php echo format_jam($jam_default); ?>" inputmode="decimal">
        </div>
        <button type="submit" class="btn btn-outline">💾 Simpan Aturan</button>
      </form>
    </div>

    <?php if ($edit): ?>
    <!-- EDIT BARIS -->
    <div class="card" style="border-color:var(--gold);">
      <h3>Edit Gaji — <?php echo tampil_db($edit['nama']); ?> (<?php echo bersihkan($label_bulan); ?>)</h3>
      <form method="POST">
        <input type="hidden" name="aksi" value="update_baris">
        <input type="hidden" name="id" value="<?php echo (int) $edit['id']; ?>">
        <input type="hidden" name="bulan" value="<?php echo bersihkan($bulan); ?>">
        <div class="grid grid-4">
          <div class="form-group"><label>Jam Dibayar</label>
            <input type="text" name="jam" class="form-control" required value="<?php echo format_jam($edit['jam_dibayar']); ?>" inputmode="decimal"></div>
          <div class="form-group"><label>Honor per Jam (Rp)</label>
            <input type="text" name="tarif" class="form-control" required value="<?php echo (int) $edit['tarif_per_jam']; ?>" inputmode="numeric"></div>
          <div class="form-group"><label>Tambahan (Rp)</label>
            <input type="text" name="tambahan" class="form-control" value="<?php echo (int) $edit['tambahan']; ?>" inputmode="numeric"></div>
          <div class="form-group"><label>Potongan (Rp)</label>
            <input type="text" name="potongan" class="form-control" value="<?php echo (int) $edit['potongan']; ?>" inputmode="numeric"></div>
        </div>
        <div class="form-group"><label>Catatan (opsional)</label>
          <input type="text" name="catatan" class="form-control" maxlength="255" value="<?php echo tampil_db($edit['catatan']); ?>" placeholder="contoh: ditambah honor pengawas ujian"></div>
        <p class="muted">Total diterima = jam × honor per jam + tambahan − potongan.</p>
        <button type="submit" class="btn btn-primary" style="width:auto;">Simpan Perubahan</button>
        <a href="<?php echo $url_halaman; ?>" class="btn btn-outline">Batal</a>
      </form>
    </div>
    <?php endif; ?>

    <!-- DAFTAR GAJI BULANAN -->
    <div class="card">
      <div class="flex-between" style="flex-wrap:wrap; gap:12px;">
        <h3 class="mb-0">Daftar Gaji — <?php echo bersihkan($label_bulan); ?></h3>
        <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
          <form method="GET" style="display:flex; gap:8px;">
            <input type="month" name="bulan" class="form-control" value="<?php echo bersihkan($bulan); ?>" onchange="this.form.submit()">
          </form>
          <form method="POST">
            <input type="hidden" name="aksi" value="generate">
            <input type="hidden" name="bulan" value="<?php echo bersihkan($bulan); ?>">
            <button type="submit" class="btn btn-gold btn-sm">➕ Buat / Lengkapi Daftar Gaji</button>
          </form>
        </div>
      </div>

      <?php if ($belum_masuk > 0): ?>
        <div class="alert alert-error" style="margin-top:14px;"><?php echo $belum_masuk; ?> guru honorer aktif belum masuk daftar gaji <?php echo bersihkan($label_bulan); ?>. Klik <strong>Buat / Lengkapi Daftar Gaji</strong>.</div>
      <?php endif; ?>

      <div class="grid grid-4" style="margin:16px 0;">
        <div class="stat-card"><div class="label">Jumlah Guru Honorer</div><div class="value"><?php echo count($rows); ?></div></div>
        <div class="stat-card blue"><div class="label">Total Gaji Bulan Ini</div><div class="value" style="font-size:19px;"><?php echo rupiah($tot_semua); ?></div></div>
        <div class="stat-card green"><div class="label">Sudah Dibayar (<?php echo $jml_sudah; ?>)</div><div class="value" style="font-size:19px;"><?php echo rupiah($tot_dibayar); ?></div></div>
        <div class="stat-card red"><div class="label">Belum Dibayar (<?php echo $jml_belum; ?>)</div><div class="value" style="font-size:19px;"><?php echo rupiah($tot_belum); ?></div></div>
      </div>

      <?php if (!empty($rows)): ?>
      <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:end; margin-bottom:16px;">
        <?php if ($jml_belum > 0): ?>
        <form method="POST" style="display:flex; gap:8px; flex-wrap:wrap; align-items:end;" onsubmit="return confirm('Bayar semua gaji yang belum dibayar (<?php echo $jml_belum; ?> guru, total <?php echo rupiah($tot_belum); ?>)? Pengeluaran otomatis tercatat di Buku Kas.');">
          <input type="hidden" name="aksi" value="bayar_semua">
          <input type="hidden" name="bulan" value="<?php echo bersihkan($bulan); ?>">
          <div class="form-group mb-0"><label>Tanggal Bayar</label><input type="date" name="tanggal" class="form-control" value="<?php echo date('Y-m-d'); ?>" required></div>
          <div class="form-group mb-0"><label>Metode</label>
            <select name="metode" class="form-control"><option>Tunai</option><option>Transfer</option></select></div>
          <button type="submit" class="btn btn-primary" style="width:auto;">💸 Bayar Semua yang Belum</button>
        </form>
        <?php endif; ?>
        <a class="btn btn-outline" target="_blank" href="cetak_gaji.php?bulan=<?php echo $bulan; ?>">🖨️ Cetak Rekap Gaji</a>
        <a class="btn btn-outline" target="_blank" href="slip_gaji.php?bulan=<?php echo $bulan; ?>">🧾 Cetak Semua Slip</a>
      </div>
      <?php endif; ?>

      <div class="table-wrap">
      <table>
        <thead><tr><th>Guru</th><th>Jam</th><th>Honor/Jam</th><th>Tambahan</th><th>Potongan</th><th>Total Diterima</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="8" class="muted" style="text-align:center; padding:20px;">Belum ada daftar gaji untuk bulan ini. Klik <strong>Buat / Lengkapi Daftar Gaji</strong> di atas.</td></tr>
        <?php endif; ?>
        <?php foreach ($rows as $r): $sudah = $r['status'] === 'Sudah Dibayar'; ?>
          <tr>
            <td>
              <strong><?php echo tampil_db($r['nama']); ?></strong>
              <?php if ($r['nip_nuptk']): ?><div class="muted" style="font-size:11.5px;"><?php echo tampil_db($r['nip_nuptk']); ?></div><?php endif; ?>
              <?php if ($r['catatan']): ?><div class="muted" style="font-size:11.5px;">📝 <?php echo tampil_db($r['catatan']); ?></div><?php endif; ?>
            </td>
            <td><?php echo format_jam($r['jam_dibayar']); ?> jam</td>
            <td><?php echo rupiah($r['tarif_per_jam']); ?></td>
            <td><?php echo $r['tambahan'] > 0 ? rupiah($r['tambahan']) : '-'; ?></td>
            <td><?php echo $r['potongan'] > 0 ? rupiah($r['potongan']) : '-'; ?></td>
            <td style="font-weight:700;"><?php echo rupiah($r['total_gaji']); ?></td>
            <td>
              <?php if ($sudah): ?>
                <span class="badge-status badge-lunas">Sudah Dibayar</span>
                <div class="muted" style="font-size:11.5px; margin-top:3px;"><?php echo format_tanggal_indo($r['tanggal_bayar']); ?> · <?php echo bersihkan($r['metode']); ?></div>
              <?php else: ?>
                <span class="badge-status badge-belum-bayar">Belum Dibayar</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if (!$sudah): ?>
                <button type="button" class="btn btn-gold btn-sm" onclick="document.getElementById('bayar-<?php echo $r['id']; ?>').style.display='flex'">Bayar</button>
                <a class="btn btn-outline btn-sm" href="?edit=<?php echo $r['id']; ?>&bulan=<?php echo $bulan; ?>">Edit</a>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Hapus baris gaji ini dari daftar bulan ini?');">
                  <input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?php echo $r['id']; ?>"><input type="hidden" name="bulan" value="<?php echo bersihkan($bulan); ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
                <form id="bayar-<?php echo $r['id']; ?>" method="POST" style="display:none; gap:6px; margin-top:8px; flex-wrap:wrap; align-items:center;">
                  <input type="hidden" name="aksi" value="bayar"><input type="hidden" name="id" value="<?php echo $r['id']; ?>"><input type="hidden" name="bulan" value="<?php echo bersihkan($bulan); ?>">
                  <input type="date" name="tanggal" class="form-control" value="<?php echo date('Y-m-d'); ?>" required style="width:150px;">
                  <select name="metode" class="form-control" style="width:110px;"><option>Tunai</option><option>Transfer</option></select>
                  <button type="submit" class="btn btn-gold btn-sm">Simpan</button>
                </form>
              <?php else: ?>
                <a class="btn btn-outline btn-sm" target="_blank" href="slip_gaji.php?id=<?php echo $r['id']; ?>">🧾 Slip</a>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Batalkan pembayaran ini? Transaksi terkait di Buku Kas juga akan dihapus.');">
                  <input type="hidden" name="aksi" value="batalkan"><input type="hidden" name="id" value="<?php echo $r['id']; ?>"><input type="hidden" name="bulan" value="<?php echo bersihkan($bulan); ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Batalkan</button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
        <?php if (!empty($rows)): ?>
        <tfoot><tr style="font-weight:700; background:#F3F5F7;"><td colspan="5" style="text-align:right;">Total</td><td colspan="3"><?php echo rupiah($tot_semua); ?></td></tr></tfoot>
        <?php endif; ?>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
