<?php
require_once __DIR__ . '/../config/session.php';
cek_role(['kepala_sekolah', 'bendahara']);
require_once __DIR__ . '/../includes/functions.php';

$judul_halaman = 'Kategori Anggaran';
$modul_aktif = 'keuangan';
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = bersihkan($_POST['nama_kategori']);
    $tipe = $_POST['tipe'] === 'Pengeluaran' ? 'Pengeluaran' : 'Pemasukan';
    $ket  = bersihkan($_POST['keterangan'] ?? '');

    if (!empty($_POST['id'])) {
        $id = (int) $_POST['id'];
        $stmt = mysqli_prepare($conn, "UPDATE kategori_keuangan SET nama_kategori=?, tipe=?, keterangan=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, 'sssi', $nama, $tipe, $ket, $id);
        mysqli_stmt_execute($stmt);
        $pesan = 'Kategori berhasil diperbarui.';
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO kategori_keuangan (nama_kategori, tipe, keterangan) VALUES (?,?,?)");
        mysqli_stmt_bind_param($stmt, 'sss', $nama, $tipe, $ket);
        mysqli_stmt_execute($stmt);
        $pesan = 'Kategori baru berhasil ditambahkan.';
    }
}

if (isset($_GET['toggle'])) {
    mysqli_query($conn, "UPDATE kategori_keuangan SET status_aktif = 1 - status_aktif WHERE id=" . (int)$_GET['toggle']);
    $pesan = 'Status kategori diperbarui.';
}
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    $dipakai = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi_keuangan WHERE kategori_id=$id"))['c'];
    if ($dipakai > 0) {
        $pesan = 'Kategori tidak dapat dihapus karena sudah dipakai pada transaksi. Nonaktifkan saja jika sudah tidak dipakai.';
    } else {
        mysqli_query($conn, "DELETE FROM kategori_keuangan WHERE id=$id");
        $pesan = 'Kategori berhasil dihapus.';
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM kategori_keuangan WHERE id=" . (int)$_GET['edit']));
}

$list = mysqli_query($conn, "SELECT k.*, (SELECT COUNT(*) FROM transaksi_keuangan t WHERE t.kategori_id=k.id) AS jml_dipakai
                              FROM kategori_keuangan k ORDER BY k.tipe DESC, k.nama_kategori");

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
  <div class="topbar"><h2>Kategori Anggaran</h2><div class="clock" id="liveClock"></div></div>
  <div class="content">
    <?php if ($pesan): ?><div class="alert alert-success"><?php echo $pesan; ?></div><?php endif; ?>

    <div class="card">
      <h3><?php echo $edit ? 'Edit Kategori' : 'Tambah Kategori Baru'; ?></h3>
      <p class="muted">Kategori mengelompokkan setiap transaksi di Buku Kas, sehingga laporan keuangan bisa dirinci per pos anggaran (mis. Gaji, Operasional, SPP, dsb).</p>
      <form method="POST" class="grid grid-3" style="align-items:end;">
        <input type="hidden" name="id" value="<?php echo $edit['id'] ?? ''; ?>">
        <div class="form-group mb-0">
          <label>Nama Kategori</label>
          <input type="text" name="nama_kategori" class="form-control" required value="<?php echo bersihkan($edit['nama_kategori'] ?? ''); ?>" placeholder="contoh: Operasional & Utilitas">
        </div>
        <div class="form-group mb-0">
          <label>Tipe</label>
          <select name="tipe" class="form-control">
            <option value="Pemasukan" <?php echo (($edit['tipe'] ?? '') === 'Pemasukan') ? 'selected' : ''; ?>>Pemasukan</option>
            <option value="Pengeluaran" <?php echo (($edit['tipe'] ?? '') === 'Pengeluaran') ? 'selected' : ''; ?>>Pengeluaran</option>
          </select>
        </div>
        <div class="form-group mb-0">
          <label>Keterangan (opsional)</label>
          <input type="text" name="keterangan" class="form-control" value="<?php echo bersihkan($edit['keterangan'] ?? ''); ?>">
        </div>
        <div style="grid-column: 1 / -1;">
          <button type="submit" class="btn btn-primary"><?php echo $edit ? 'Simpan Perubahan' : '+ Tambah Kategori'; ?></button>
          <?php if ($edit): ?><a href="kategori.php" class="btn btn-outline">Batal</a><?php endif; ?>
        </div>
      </form>
    </div>

    <div class="card">
      <h3>Daftar Kategori</h3>
      <div class="table-wrap">
      <table>
        <thead><tr><th>Nama Kategori</th><th>Tipe</th><th>Keterangan</th><th>Dipakai</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php while ($k = mysqli_fetch_assoc($list)): ?>
          <tr>
            <td><strong><?php echo bersihkan($k['nama_kategori']); ?></strong></td>
            <td><span class="badge-status <?php echo $k['tipe']==='Pemasukan' ? 'badge-hadir' : 'badge-alpa'; ?>"><?php echo $k['tipe']; ?></span></td>
            <td><?php echo bersihkan($k['keterangan'] ?: '-'); ?></td>
            <td><?php echo (int)$k['jml_dipakai']; ?>x</td>
            <td><?php echo $k['status_aktif'] ? '<span class="pill">Aktif</span>' : '<span class="pill" style="background:#fdecea;color:#b3261e;">Nonaktif</span>'; ?></td>
            <td>
              <a class="btn btn-outline btn-sm" href="?edit=<?php echo $k['id']; ?>">Edit</a>
              <a class="btn btn-outline btn-sm" href="?toggle=<?php echo $k['id']; ?>"><?php echo $k['status_aktif'] ? 'Nonaktifkan' : 'Aktifkan'; ?></a>
              <a class="btn btn-danger btn-sm" href="?hapus=<?php echo $k['id']; ?>" onclick="return confirm('Hapus kategori ini?');">Hapus</a>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
