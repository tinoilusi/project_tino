<?php
require_once __DIR__ . '/config/session.php';
cek_login();
if ($_SESSION['role'] === 'kepala_sekolah') {
    header('Location: ' . BASE_URL . 'pilihan.php');
} elseif ($_SESSION['role'] === 'bendahara') {
    header('Location: ' . BASE_URL . 'keuangan/dashboard.php');
} else {
    header('Location: ' . BASE_URL . 'absensi/beranda.php');
}
exit;
