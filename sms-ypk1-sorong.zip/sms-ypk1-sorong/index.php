<?php
// BERANDA PUBLIK — hanya untuk pengunjung (tanpa tombol login)
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/beranda_db.php';
$S = []; $q = mysqli_query($conn, "SELECT b.*, p.nama AS peg_nama, p.nip_nuptk AS peg_nomor, p.foto AS peg_foto
  FROM beranda_konten b LEFT JOIN pegawai p ON p.id = b.pegawai_id ORDER BY b.urutan, b.id");
while ($r = mysqli_fetch_assoc($q)) $S[$r['seksi']][] = $r;
$t = fn($x) => bersihkan(tk($conn, $x));
$g = fn($k) => $S[$k] ?? [];
$nama = get_setting($conn,'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
$logo = url_logo_sekolah($conn); $logoHero = url_logo_beranda($conn); $bg = url_background_sekolah($conn);
$hero = $g('hero')[0] ?? ['judul'=>$nama,'subjudul'=>'','isi'=>''];
$img = fn($r) => !empty($r['gambar']) ? BASE_URL.'assets/img/uploads/'.$t($r['gambar']) : '';
$lv = []; foreach ($g('struktur') as $r) $lv[$r['level']][] = $r; ksort($lv);
// Data pegawai untuk kartu struktur (foto & NIP/NUPTK selalu mengikuti menu Data Guru & Staf)
$kartuPeg = function ($r, $role) use ($conn) {
  return ['role'=>$role, 'nama'=>$r['nama'], 'nomor'=>trim((string)$r['nip_nuptk']), 'foto'=>foto_potret($r['foto']), 'orang'=>true];
};
$waliDari = []; $kelompok = ['guru'=>[], 'wali_kelas'=>[], 'tata_usaha'=>[]];
$q = mysqli_query($conn, "SELECT k.nama_kelas, p.* FROM kelas k JOIN pegawai p ON p.id=k.wali_kelas_id WHERE p.status_aktif=1 ORDER BY k.tingkat, k.nama_kelas");
while ($q && $r = mysqli_fetch_assoc($q)) { $waliDari[$r['id']][] = $r['nama_kelas']; $kelompok['wali_kelas'][] = $kartuPeg($r, 'Wali '.(stripos($r['nama_kelas'],'kelas')===0 ? $r['nama_kelas'] : 'Kelas '.$r['nama_kelas'])); }
$q = mysqli_query($conn, "SELECT * FROM pegawai WHERE status_aktif=1 AND jenis IN ('Guru','Tata Usaha') ORDER BY id");
while ($q && $r = mysqli_fetch_assoc($q)) {
  if ($r['jenis'] === 'Guru') $kelompok['guru'][] = $kartuPeg($r, 'Guru'.(isset($waliDari[$r['id']]) ? ' · Wali Kelas '.preg_replace('/^kelas\s+/i','',$waliDari[$r['id']][0]) : ''));
  else $kelompok['tata_usaha'][] = $kartuPeg($r, 'Tata Usaha');
}
// Akreditasi untuk lencana hero (ambil dari statistik "Akreditasi", default B)
$akr = 'B'; foreach ($g('statistik') as $r) if (stripos($r['judul'],'akreditasi') !== false) { $akr = trim(tk($conn,$r['subjudul'])) ?: 'B'; }
$bgcss = $bg ? "url('".$bg."')" : 'none';
?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= bersihkan($nama) ?> — Beranda</title>
<meta name="description" content="<?= $t($hero['isi']) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{--navy:#082A42;--navy2:#0B3C5D;--gold:#C9A24B;--gold2:#E6C877;--ink:#1F2937;--mut:#6B7280;--bg:#F8F6F1;--line:#E7E2D5;--nav-h:72px}
*,*:before,*:after{box-sizing:border-box}
*{margin:0}
html{scroll-behavior:smooth;scroll-padding-top:var(--nav-h)}
body{font-family:Inter,system-ui,sans-serif;color:var(--ink);background:var(--bg);line-height:1.7;overflow-x:hidden;-webkit-font-smoothing:antialiased}
img{max-width:100%;display:block}
h1,h2,h3{font-family:'Playfair Display',Georgia,serif;color:var(--navy);line-height:1.2}
:focus-visible{outline:3px solid var(--gold);outline-offset:3px;border-radius:6px}

/* ===== NAVBAR ===== */
#bar{position:fixed;top:0;left:0;height:3px;width:0;z-index:30;background:linear-gradient(90deg,var(--gold),var(--gold2))}
nav{position:fixed;inset:0 0 auto;z-index:20;height:var(--nav-h);display:flex;justify-content:space-between;align-items:center;gap:24px;padding:0 max(5%,20px);background:rgba(8,42,66,.55);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-bottom:1px solid rgba(201,162,75,.25);transition:background .3s,box-shadow .3s,height .3s}
nav.sc{--nav-h:62px;height:62px;background:rgba(8,42,66,.96);box-shadow:0 8px 30px rgba(0,0,0,.25)}
.brand{display:flex;align-items:center;gap:12px;color:#fff;text-decoration:none;font:700 18px 'Playfair Display',serif;min-width:0}
.brand img{height:44px;width:44px;object-fit:contain;border-radius:50%;background:none;padding:0;flex:none;filter:drop-shadow(0 2px 6px rgba(0,0,0,.35))}
.brand span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.links{display:flex;gap:6px;align-items:center}
.links a{color:#e8edf1;text-decoration:none;font-size:14px;font-weight:500;padding:8px 12px;border-radius:999px;transition:background .25s,color .25s}
.links a:hover{background:rgba(255,255,255,.1)}
.links a.on{color:var(--navy);background:var(--gold)}
.burger{display:none;width:44px;height:44px;border:1px solid rgba(255,255,255,.3);border-radius:12px;background:transparent;cursor:pointer;position:relative}
.burger i,.burger i:before,.burger i:after{position:absolute;left:50%;width:20px;height:2px;margin-left:-10px;background:#fff;border-radius:2px;transition:.3s}
.burger i{top:50%;margin-top:-1px}.burger i:before{content:"";top:-6px;left:0;margin:0}.burger i:after{content:"";top:6px;left:0;margin:0}
nav.open .burger i{background:transparent}nav.open .burger i:before{top:0;transform:rotate(45deg)}nav.open .burger i:after{top:0;transform:rotate(-45deg)}

/* ===== HERO ===== */
.hero{position:relative;min-height:100vh;min-height:100svh;display:flex;align-items:center;color:#fff;padding:calc(var(--nav-h) + 48px) max(6%,20px) 120px;isolation:isolate;background:var(--navy)}
.hero:before{content:"";position:absolute;inset:0;z-index:-2;background:<?= $bgcss ?> center/cover no-repeat}
.hero:after{content:"";position:absolute;inset:0;z-index:-1;background:linear-gradient(105deg,rgba(8,42,66,.97) 0%,rgba(8,42,66,.88) 45%,rgba(11,60,93,.72) 100%)}
.hero-in{width:100%;max-width:1200px;margin:auto;display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:clamp(32px,6vw,80px);align-items:center}
.eyebrow{display:inline-flex;align-items:center;gap:10px;color:var(--gold2);font-size:14px;font-weight:600;letter-spacing:.04em}
.eyebrow:before{content:"";width:28px;height:2px;background:var(--gold)}
.hero h1{color:#fff;font-size:clamp(36px,5.6vw,68px);margin:18px 0 20px;text-wrap:balance}
.hero p.lede{max-width:540px;color:#d5dee5;font-size:clamp(16px,1.6vw,19px)}
.cta{display:flex;flex-wrap:wrap;gap:14px;margin-top:36px}
.btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 30px;border-radius:999px;font-weight:600;font-size:15px;text-decoration:none;transition:transform .25s,box-shadow .25s,background .25s,border-color .25s}
.btn-gold{background:linear-gradient(135deg,var(--gold),#b88f35);color:#fff;box-shadow:0 10px 28px rgba(201,162,75,.35)}
.btn-gold:hover{transform:translateY(-3px);box-shadow:0 16px 34px rgba(201,162,75,.5)}
.btn-line{border:1.5px solid rgba(255,255,255,.45);color:#fff}
.btn-line:hover{background:rgba(255,255,255,.12);border-color:#fff}

/* Kartu logo: ukuran terkunci, tidak miring, tidak bisa meluap */
.crest{position:relative;justify-self:center;width:min(100%,400px);aspect-ratio:1;display:grid;place-items:center;border-radius:28px;background:linear-gradient(160deg,rgba(255,255,255,.14),rgba(255,255,255,.04));border:1px solid rgba(255,255,255,.22);box-shadow:0 30px 70px rgba(0,0,0,.35);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);animation:float 7s ease-in-out infinite}
.crest-in{width:80%;aspect-ratio:1;border-radius:50%;background:none;display:grid;place-items:center;padding:0;box-shadow:none}
.crest-in img{width:100%;height:100%;object-fit:contain;border-radius:50%;filter:drop-shadow(0 18px 30px rgba(0,0,0,.45))}
.crest-ph{display:grid;place-items:center;width:100%;height:100%;border-radius:50%;background:#fff;font:700 64px 'Playfair Display',serif;color:var(--navy)}
.badge{position:absolute;left:-22px;bottom:28px;display:flex;align-items:center;gap:12px;padding:10px 20px 10px 10px;background:#fff;border-radius:999px;box-shadow:0 14px 34px rgba(0,0,0,.28)}
.badge b{display:grid;place-items:center;width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,var(--gold),#a9802a);color:#fff;font:700 22px 'Playfair Display',serif}
.badge div{line-height:1.25}.badge strong{display:block;color:var(--navy);font-size:14px}.badge span{color:var(--mut);font-size:12px}
@keyframes float{50%{transform:translateY(-10px)}}
.cue{position:absolute;bottom:26px;left:50%;width:26px;height:42px;margin-left:-13px;border:2px solid rgba(255,255,255,.55);border-radius:14px}
.cue:after{content:"";position:absolute;top:8px;left:50%;width:4px;height:8px;margin-left:-2px;background:var(--gold);border-radius:2px;animation:cu 1.6s infinite}
@keyframes cu{to{transform:translateY(14px);opacity:0}}
.hero-in>*{animation:up .9s cubic-bezier(.2,.7,.2,1) both}.hero-in>*:nth-child(2){animation-delay:.18s}
@keyframes up{from{opacity:0;transform:translateY(26px)}to{opacity:1;transform:none}}

/* ===== STATISTIK ===== */
.stats{position:relative;z-index:2;display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:18px;margin:-64px auto 0;padding:0 max(6%,20px);max-width:1200px}
.stat{background:#fff;padding:26px 18px;text-align:center;border-radius:16px;box-shadow:0 18px 40px rgba(8,42,66,.12);border-top:3px solid var(--gold)}
.stat b{display:block;font:700 38px/1.1 'Playfair Display',serif;color:var(--navy)}
.stat span{display:block;margin-top:6px;color:var(--mut);font-size:14px}

/* ===== SECTION ===== */
section{padding:96px max(6%,20px);max-width:1200px;margin:auto}
.wide{background:#fff}.wide>section{max-width:1200px}
.tt{text-align:center;margin-bottom:52px}
.tt small{display:block;color:var(--gold);font-size:13px;font-weight:600;letter-spacing:.06em;margin-bottom:8px}
.tt h2{font-size:clamp(28px,4vw,40px)}
.tt:after{content:"";display:block;width:60px;height:3px;background:var(--gold);margin:16px auto 0;border-radius:3px}
.lead{font-size:clamp(16px,1.7vw,19px);max-width:820px;margin:auto;text-align:center;color:#374151;white-space:pre-line}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:24px}
.card{background:#fff;border-radius:16px;padding:28px;box-shadow:0 8px 28px rgba(8,42,66,.07);border:1px solid var(--line);transition:transform .35s,box-shadow .35s,border-color .35s}
.wide .card{background:var(--bg)}
.card:hover{transform:translateY(-6px);box-shadow:0 22px 44px rgba(8,42,66,.14);border-color:var(--gold)}
.card h3{font-size:20px;margin-bottom:8px}
.card img{width:100%;border-radius:10px;margin-bottom:14px;max-height:200px;object-fit:cover}
.card em{display:block;color:var(--gold);font-style:normal;font-size:13px;font-weight:600;margin-bottom:2px}
.idn{grid-template-columns:repeat(auto-fit,minmax(230px,1fr));margin-top:48px}.idn .card{padding:20px}.idn p{color:var(--navy);line-height:1.4;margin-top:4px}
.vm{background:linear-gradient(135deg,var(--navy),var(--navy2));color:#fff;border-radius:22px;padding:clamp(28px,5vw,56px);text-align:center}
.vm h2{color:var(--gold2)}.vm p{font:600 clamp(19px,2.4vw,26px)/1.5 'Playfair Display',serif;margin:14px auto 0;max-width:820px}
.num{width:40px;height:40px;border-radius:50%;background:var(--gold);color:#fff;display:grid;place-items:center;font-weight:700;margin-bottom:14px}

/* ===== SEJARAH ===== */
.tl{position:relative;max-width:760px;margin:auto;padding-left:36px}
.tl:before{content:"";position:absolute;left:0;top:6px;bottom:6px;width:2px;background:var(--line)}
.tl:after{content:"";position:absolute;left:0;top:6px;width:2px;height:var(--h,0%);max-height:calc(100% - 12px);background:var(--gold)}
.tl>div{position:relative;margin-bottom:36px}.tl>div:last-child{margin-bottom:0}
.tl>div:before{content:"";position:absolute;left:-45px;top:6px;width:18px;height:18px;border-radius:50%;background:var(--gold);border:4px solid var(--bg);box-shadow:0 0 0 2px var(--gold)}
.tl em{color:var(--gold);font-style:normal;font-weight:700;font-size:14px}.tl h3{margin:2px 0 6px}

/* ===== STRUKTUR ===== */
/* Semua kartu identik: foto potret 3:4 -> jabatan -> nama -> nomor induk. Rata tengah & simetris. */
.org{display:flex;flex-direction:column;align-items:center;--gap:20px;--stub:30px}
.row{position:relative;display:flex;justify-content:center;align-items:stretch;padding-top:var(--stub);width:100%}
.row:first-child{padding-top:0}
.row:not(:first-child):before{content:"";position:absolute;top:0;left:50%;height:var(--stub);border-left:2px solid var(--gold)}
.nd{position:relative;display:flex;padding:var(--stub) calc(var(--gap)/2) 0}
.row:first-child .nd{padding-top:0}
.nd:before,.nd:after{content:"";position:absolute;top:0;width:50%;border-top:2px solid var(--gold)}
.nd:before{left:0}.nd:after{right:0}
.nd>i{position:absolute;top:0;left:50%;height:var(--stub);border-left:2px solid var(--gold)}
.nd:first-child:before,.nd:last-child:after{border-top-color:transparent}
.row:first-child .nd:before,.row:first-child .nd:after,.row:first-child .nd>i{display:none}
/* kelompok otomatis (semua guru / wali kelas) */
.row.grp{flex-direction:column;align-items:center}
.gh{position:relative;display:inline-flex;align-items:baseline;gap:10px;padding:9px 24px;border-radius:99px;background:var(--navy);color:#fff;border:1px solid var(--gold);font:700 15px/1.2 'Playfair Display',Georgia,serif;margin-bottom:var(--stub)}
.gh small{font:500 12px Inter,sans-serif;color:var(--gold2);letter-spacing:.04em}
.gh:after{content:"";position:absolute;left:50%;top:100%;height:var(--stub);border-left:2px solid var(--gold)}
.gg{display:flex;flex-wrap:wrap;justify-content:center;gap:var(--gap);max-width:1040px}
.node{width:220px;display:grid;grid-template-rows:auto auto 1fr auto;justify-items:center;align-items:start;text-align:center;
  background:#fff;border:1px solid var(--line);border-top:4px solid var(--gold);border-radius:18px;padding:20px 16px 16px;
  box-shadow:0 6px 18px rgba(8,42,66,.08);transition:transform .35s,box-shadow .35s}
.node:hover{transform:translateY(-5px);box-shadow:0 18px 36px rgba(8,42,66,.16)}
.gg .node{height:100%}
.gg>.rv,.gg>.node{align-self:stretch}
.node .av{width:132px;aspect-ratio:3/4;border-radius:16px;padding:3px;background:linear-gradient(135deg,var(--gold2),var(--gold));margin-bottom:14px}
.node .av>*{width:100%;height:100%;border-radius:13px;border:3px solid #fff;object-fit:cover;object-position:center top;display:flex;align-items:center;justify-content:center;background:var(--navy2)}
.node .av.sm{width:96px;aspect-ratio:1}
.node .av span{color:var(--gold2);font:700 44px/1 'Playfair Display',Georgia,serif}
.node .av svg{padding:30%;color:var(--gold2);fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}
.node .role{display:flex;align-items:center;justify-content:center;min-height:2.7em;font-size:11px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:#A8801F;line-height:1.35}
.node b{display:flex;align-items:flex-start;justify-content:center;min-height:2.7em;margin-top:6px;font:700 15px/1.35 'Playfair Display',Georgia,serif;color:var(--navy)}
.node .id{align-self:end;margin-top:12px;width:100%;padding:7px 8px;border-radius:12px;background:var(--bg);border:1px solid var(--line);font-size:12.5px;line-height:1.3;color:var(--navy);font-weight:600;letter-spacing:.02em;font-variant-numeric:tabular-nums;word-break:break-all}
.node .id em{display:block;font-style:normal;font-weight:600;font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--mut);margin-bottom:1px}
.node .id.no{display:none}
.row.r1 .node,.row.r2 .node{background:var(--navy);border-color:var(--gold)}
.row.r1 .node b,.row.r2 .node b{color:#fff}
.row.r1 .node .role,.row.r2 .node .role{color:var(--gold2)}
.row.r1 .node .id,.row.r2 .node .id{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.18);color:#fff}
.row.r1 .node .id em,.row.r2 .node .id em{color:#9fb2bf}
.row.r1 .node .av>*,.row.r2 .node .av>*{border-color:var(--navy)}

/* ===== FOOTER ===== */
footer{background:var(--navy);color:#b9c6cf;text-align:center;padding:64px max(6%,20px) 40px}
footer h3{color:var(--gold2);margin-bottom:12px;font-size:26px}
footer p{max-width:620px;margin:auto}
footer .copy{margin-top:32px;padding-top:24px;border-top:1px solid rgba(255,255,255,.12);font-size:13px}
#top{position:fixed;right:20px;bottom:20px;width:46px;height:46px;border-radius:50%;border:2px solid var(--gold);background:var(--navy);color:var(--gold);font-size:20px;cursor:pointer;z-index:15;opacity:0;transform:translateY(20px);pointer-events:none;transition:.35s}
#top.show{opacity:1;transform:none;pointer-events:auto}#top:hover{background:var(--gold);color:var(--navy)}

/* ===== REVEAL (aman: konten tetap tampil jika JS mati) ===== */
.js .rv{opacity:0;transform:translateY(24px);transition:opacity .8s cubic-bezier(.2,.7,.2,1),transform .8s cubic-bezier(.2,.7,.2,1)}
.js .rv.on{opacity:1;transform:none}
.js .tt:after{width:0;transition:width .9s .2s}.js .tt.on:after{width:60px}

/* ===== RESPONSIF ===== */
@media(max-width:900px){
 .hero-in{grid-template-columns:1fr;text-align:center}
 .eyebrow{justify-content:center}.hero p.lede{margin:auto}.cta{justify-content:center}
 .crest{width:min(78vw,300px);order:-1}
 .badge{left:50%;bottom:-20px;transform:translateX(-50%);white-space:nowrap}
 .hero{padding-bottom:110px}
}
@media(max-width:820px){
 .burger{display:block}
 .links{position:fixed;top:var(--nav-h);left:0;right:0;flex-direction:column;align-items:stretch;gap:2px;padding:14px max(5%,20px) 20px;background:rgba(8,42,66,.98);border-bottom:1px solid rgba(201,162,75,.3);transform:translateY(-12px);opacity:0;pointer-events:none;transition:.3s}
 nav.open .links{transform:none;opacity:1;pointer-events:auto}
 .links a{padding:14px 16px;font-size:16px;border-radius:12px}
 section{padding:64px max(6%,20px)}
 .stats{margin-top:-48px}
}
@media(max-width:820px){.row{flex-direction:column;align-items:center}.nd{width:100%;justify-content:center;padding:22px 0 0}.nd:before,.nd:after{display:none}.nd>i{height:22px}.row:first-child .nd,.row:not(:first-child) .nd:first-child{padding-top:0}.row:not(:first-child) .nd:first-child>i{display:none}.org{--stub:22px}.node{width:min(100%,260px)}.gg .node{width:min(100%,230px)}}
@media(max-width:480px){.org{--gap:12px}.gg .node{width:calc(50% - 6px);padding:14px 10px 12px}.gg .node .av{width:100%}.gg .node .av span{font-size:34px}.gg .node b{font-size:13.5px}.gg .node .id{font-size:10.5px;letter-spacing:-.01em;padding:6px 2px;word-break:normal;white-space:nowrap}.gg .node .id em{font-size:9px}.btn{width:100%}.brand{font-size:16px}.node{width:100%;max-width:300px}}
@media(prefers-reduced-motion:reduce){*,*:before,*:after{animation:none!important;transition:none!important}html{scroll-behavior:auto}.js .rv{opacity:1;transform:none}}
</style></head><body>
<script>document.documentElement.classList.add('js')</script>
<div id="bar"></div><button id="top" aria-label="Kembali ke atas">↑</button>

<nav id="nav">
  <a class="brand" href="#"><?php if($logo):?><img src="<?= $logo ?>" alt="Logo"><?php endif; ?><span><?= bersihkan($nama) ?></span></a>
  <button class="burger" id="burger" aria-label="Buka menu" aria-expanded="false"><i></i></button>
  <div class="links" id="links"><a href="#tentang">Tentang</a><a href="#visi">Visi &amp; Misi</a><a href="#sejarah">Sejarah</a><a href="#struktur">Struktur</a><a href="#info">Informasi</a><a href="#kontak">Kontak</a></div>
</nav>

<header class="hero"><div class="hero-in">
  <div>
    <?php if(trim($hero['subjudul'])): ?><span class="eyebrow"><?= $t($hero['subjudul']) ?></span><?php endif ?>
    <h1><?= $t($hero['judul']) ?></h1>
    <p class="lede"><?= $t($hero['isi']) ?></p>
    <div class="cta"><a class="btn btn-gold" href="#kontak">Hubungi Sekolah</a><a class="btn btn-line" href="#tentang">Tentang Kami</a></div>
  </div>
  <div class="crest">
    <div class="crest-in"><?php if($logoHero): ?><img src="<?= $logoHero ?>" alt="Logo <?= bersihkan($nama) ?>"><?php else: ?><span class="crest-ph">YPK</span><?php endif ?></div>
    <div class="badge"><b><?= bersihkan($akr) ?></b><div><strong>Terakreditasi</strong><span>Akreditasi <?= bersihkan($akr) ?></span></div></div>
  </div>
</div><span class="cue"></span></header>

<?php if($g('statistik')): ?><div class="stats"><?php foreach($g('statistik') as $r): ?><div class="stat rv"><b><?= $t($r['subjudul']) ?></b><span><?= $t($r['judul']) ?></span></div><?php endforeach ?></div><?php endif ?>

<?php foreach($g('tentang') as $r): ?><section id="tentang" class="rv"><div class="tt"><small>Profil Sekolah</small><h2><?= $t($r['judul']) ?></h2></div>
<?php if($img($r)): ?><p style="text-align:center;margin-bottom:28px"><img src="<?= $img($r) ?>" alt="" style="margin:auto;border-radius:16px;max-height:380px"></p><?php endif ?>
<p class="lead"><?= $t($r['isi']) ?></p>
<?php if($g('identitas')): ?><div class="grid idn"><?php foreach($g('identitas') as $x): ?><div class="card"><em><?= $t($x['judul']) ?></em><p><b><?= $t($x['subjudul']) ?></b></p></div><?php endforeach ?></div><?php endif ?></section><?php endforeach ?>

<div class="wide" id="visi"><section class="rv">
<?php foreach($g('visi') as $r): ?><div class="vm"><h2><?= $t($r['judul']) ?></h2><p><?= $t($r['isi']) ?></p></div><?php endforeach ?>
<div class="tt" style="margin-top:64px"><small>Komitmen Kami</small><h2>Misi</h2></div>
<div class="grid"><?php foreach($g('misi') as $i=>$r): ?><div class="card"><div class="num"><?= $i+1 ?></div><h3><?= $t($r['judul']) ?></h3><p><?= $t($r['isi']) ?></p></div><?php endforeach ?></div></section></div>

<section id="sejarah" class="rv"><div class="tt"><small>Perjalanan Kami</small><h2>Sejarah Sekolah</h2></div>
<div class="tl"><?php foreach($g('sejarah') as $r): ?><div><em><?= $t($r['subjudul']) ?></em><h3><?= $t($r['judul']) ?></h3><p><?= $t($r['isi']) ?></p></div><?php endforeach ?></div></section>

<div class="wide" id="struktur"><section class="rv"><div class="tt"><small>Organisasi</small><h2>Struktur Kabinet</h2></div>
<div class="org"><?php
$ikon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 21h18M5 21V9l7-5 7 5v12M9 21v-6h6v6M9 11h.01M15 11h.01"/></svg>';
$kartu = function($c) use ($ikon) {
  $o = '<article class="node"><div class="av'.(!empty($c['kecil']) ? ' sm' : '').'">';
  if (!empty($c['foto'])) $o .= '<img src="'.bersihkan($c['foto']).'" alt="Foto '.bersihkan($c['nama']).'" loading="lazy" decoding="async">';
  elseif (!empty($c['orang'])) $o .= '<span>'.bersihkan(mb_strtoupper(mb_substr(trim($c['nama']) ?: '?',0,1))).'</span>';
  else $o .= $ikon;
  $o .= '</div><div class="role">'.bersihkan($c['role']).'</div><b>'.bersihkan($c['nama']).'</b>';
  $o .= !empty($c['orang']) ? '<div class="id"><em>NIP / NUPTK</em>'.($c['nomor'] !== '' ? bersihkan($c['nomor']) : '–').'</div>' : '<div class="id no"></div>';
  return $o.'</article>';
};
foreach($lv as $n=>$rows):
  $normal = []; $grup = [];
  foreach($rows as $r) { if (!empty($r['kelompok']) && isset($kelompok[$r['kelompok']])) $grup[] = $r; else $normal[] = $r; }
  $adaOrang = false; foreach($normal as $r) if (!empty($r['pegawai_id'])) $adaOrang = true;
  if ($normal): ?><div class="row r<?= (int)$n ?>"><?php foreach($normal as $r):
    $orang = !empty($r['pegawai_id']);
    $foto = $img($r) ?: ($orang ? (foto_potret($r['peg_foto'] ?? null) ?: '') : '');
    echo '<div class="nd"><i></i>', $kartu([
      'role'=>tk($conn,$r['judul']), 'nama'=>$orang ? (string)$r['peg_nama'] : tk($conn,$r['subjudul']),
      'nomor'=>trim((string)($r['peg_nomor'] ?? '')), 'foto'=>$foto, 'orang'=>$orang, 'kecil'=>!$adaOrang
    ]), '</div>';
  endforeach ?></div><?php endif;
  foreach($grup as $r): $cards = $kelompok[$r['kelompok']]; if (!$cards) continue; ?>
  <div class="row grp r<?= (int)$n ?>"><div class="gh"><?= $t($r['judul']) ?><small><?= count($cards) ?> orang</small></div>
  <div class="gg"><?php foreach($cards as $c) echo $kartu($c) ?></div></div>
<?php endforeach; endforeach ?></div></section></div>

<section id="info" class="rv"><div class="tt"><small>Kabar &amp; Layanan</small><h2>Informasi Sekolah</h2></div>
<div class="grid"><?php foreach($g('info') as $r): ?><div class="card"><?php if($img($r)): ?><img src="<?= $img($r) ?>" alt=""><?php endif ?><em><?= $t($r['subjudul']) ?></em><h3><?= $t($r['judul']) ?></h3><p><?= $t($r['isi']) ?></p></div><?php endforeach ?></div></section>

<footer id="kontak"><?php foreach($g('kontak') as $r): ?><h3><?= $t($r['judul']) ?></h3><p style="white-space:pre-line"><?= $t($r['isi']) ?></p><?php endforeach ?>
<p class="copy">&copy; <?= date('Y') ?> <?= bersihkan($nama) ?>. Yayasan Pendidikan Kristen (YPK) di Tanah Papua.</p></footer>

<script>
(function(){
var $=function(q,c){return Array.prototype.slice.call((c||document).querySelectorAll(q))};
var nav=document.getElementById('nav'),bar=document.getElementById('bar'),topb=document.getElementById('top'),burger=document.getElementById('burger');
/* menu mobile */
burger.onclick=function(){var o=nav.classList.toggle('open');burger.setAttribute('aria-expanded',o)};
$('#links a').forEach(function(a){a.addEventListener('click',function(){nav.classList.remove('open');burger.setAttribute('aria-expanded',false)})});
/* reveal berjenjang */
$('.card,.nd,.gg>.node,.tl>div').forEach(function(e){e.classList.add('rv')});
$('.grid,.stats,.row,.gg,.tl').forEach(function(g){$(':scope>.rv',g).forEach(function(e,i){e.style.transitionDelay=Math.min(i,6)*80+'ms'})});
var o=new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting){x.target.classList.add('on');if(x.target.classList.contains('stat'))count(x.target.querySelector('b'));o.unobserve(x.target)}})},{threshold:.12});
$('.rv,.tt').forEach(function(e){o.observe(e)});
/* hitung angka statistik */
function count(b){var m=b.textContent.match(/^(\D*)(\d+)(.*)$/);if(!m||b.dataset.d)return;b.dataset.d=1;var to=+m[2],t0=null;
 (function f(t){t0=t0||t;var p=Math.min((t-t0)/1300,1),e=1-Math.pow(1-p,3);b.textContent=m[1]+Math.round(to*e)+m[3];if(p<1)requestAnimationFrame(f)})(performance.now())}
/* scroll: progress, navbar, tombol atas, garis sejarah */
var tl=document.querySelector('.tl'),tick=false;
function onS(){var y=window.scrollY,H=document.documentElement.scrollHeight-innerHeight;
 bar.style.width=(H>0?y/H*100:0)+'%';nav.classList.toggle('sc',y>40);topb.classList.toggle('show',y>500);
 if(tl){var r=tl.getBoundingClientRect();tl.style.setProperty('--h',Math.max(0,Math.min(100,(innerHeight*.7-r.top)/r.height*100))+'%')}tick=false}
addEventListener('scroll',function(){if(!tick){tick=true;requestAnimationFrame(onS)}},{passive:true});onS();
topb.onclick=function(){scrollTo({top:0,behavior:'smooth'})};
/* menu aktif sesuai posisi */
var links=$('#links a'),sp=new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting)links.forEach(function(a){a.classList.toggle('on',a.getAttribute('href')==='#'+x.target.id)})})},{rootMargin:'-45% 0px -50% 0px'});
$('[id]').filter(function(e){return links.some(function(a){return a.getAttribute('href')==='#'+e.id})}).forEach(function(e){sp.observe(e)});
})();
</script>
<script src="<?php echo BASE_URL; ?>assets/js/lightbox.js"></script>
</body></html>
