</div><!-- /.app-shell -->
<script>
function tickClock(){
  var el = document.getElementById('liveClock');
  if(!el) return;
  var d = new Date();
  var hari = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][d.getDay()];
  function p(n){ return n.toString().padStart(2,'0'); }
  el.textContent = hari + ', ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) + ' WIT';
}
setInterval(tickClock, 1000);
tickClock();

// --- Navigasi mobile/tablet: buka-tutup sidebar ---
(function(){
  var btn = document.getElementById('mobileToggleBtn');
  var sidebar = document.getElementById('mainSidebar');
  var overlay = document.getElementById('sidebarOverlay');
  if(!btn || !sidebar || !overlay) return;

  function bukaSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); btn.textContent = '✕'; }
  function tutupSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); btn.textContent = '☰'; }

  btn.addEventListener('click', function(){
    sidebar.classList.contains('open') ? tutupSidebar() : bukaSidebar();
  });
  overlay.addEventListener('click', tutupSidebar);
  // tutup otomatis saat memilih menu (di layar kecil)
  sidebar.querySelectorAll('nav a').forEach(function(a){
    a.addEventListener('click', function(){ if (window.innerWidth <= 1024) tutupSidebar(); });
  });
  // reset saat resize ke ukuran desktop
  window.addEventListener('resize', function(){ if (window.innerWidth > 1024) tutupSidebar(); });
})();
</script>
<script src="<?php echo aset('assets/js/lightbox.js'); ?>"></script>
</body>
</html>
