<?php
// Variabel opsional yang bisa di-set di halaman sebelum include:
// $modul_aktif = 'manajemen' | 'absensi'
$role = $_SESSION['role'] ?? '';
$nama_user = $_SESSION['nama'] ?? 'Pengguna';
$current = basename($_SERVER['SCRIPT_NAME']);
$current_dir = basename(dirname($_SERVER['SCRIPT_NAME']));
function nav_active($file, $current) { return $current === $file ? ' active' : ''; }
$logo_side = url_logo_sekolah($conn);
$bg_side = url_background_sekolah($conn);
?>
<aside class="sidebar <?php echo $bg_side ? 'has-photo' : ''; ?>" id="mainSidebar" <?php echo $bg_side ? 'style="background-image:linear-gradient(180deg,rgba(6,28,46,.90),rgba(6,28,46,.94)),url(\'' . $bg_side . '\');background-size:cover;background-position:center;"' : ''; ?>>
  <div class="brand">
    <?php if ($logo_side): ?>
      <img src="<?php echo $logo_side; ?>" class="logo-sekolah" alt="Logo">
    <?php endif; ?>
    <div class="brand-text">
      <div class="name"><?php echo bersihkan($nama_sekolah ?? 'SMAS YPK 1 Sorong'); ?></div>
      <div class="npsn">NPSN <?php echo bersihkan(get_setting($conn,'npsn') ?: '60403645'); ?></div>
    </div>
  </div>
  <nav>
    <?php if ($role === 'kepala_sekolah'): ?>
      <a href="<?php echo BASE_URL; ?>pilihan.php"><?php echo ikon('home'); ?> Menu Utama</a>

      <?php if (($modul_aktif ?? '') === 'keuangan'): ?>
        <div class="section-title">Keuangan Sekolah &amp; Komite</div>
        <a class="<?php echo nav_active('dashboard.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/dashboard.php"><?php echo ikon('chart'); ?> Dashboard Keuangan</a>
        <a class="<?php echo nav_active('transaksi.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/transaksi.php"><?php echo ikon('wallet'); ?> Buku Kas (Transaksi)</a>
        <a class="<?php echo nav_active('spp.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/spp.php"><?php echo ikon('receipt'); ?> SPP / Iuran Komite</a>
        <a class="<?php echo nav_active('gaji_honorer.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/gaji_honorer.php"><?php echo ikon('staff'); ?> Gaji Guru Honorer</a>
        <a class="<?php echo nav_active('kategori.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/kategori.php"><?php echo ikon('folder'); ?> Kategori Anggaran</a>
        <a class="<?php echo nav_active('laporan.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/laporan.php"><?php echo ikon('printer'); ?> Cetak Laporan</a>

      <?php elseif (($modul_aktif ?? '') === 'erapor'): ?>
        <div class="section-title">E-Rapor / Akademik</div>
        <a class="<?php echo nav_active('dashboard.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/dashboard.php"><?php echo ikon('chart'); ?> Dashboard E-Rapor</a>
        <a class="<?php echo nav_active('mapel.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/mapel.php"><?php echo ikon('book'); ?> Mata Pelajaran</a>
        <a class="<?php echo nav_active('pengajaran.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/pengajaran.php"><?php echo ikon('staff'); ?> Penugasan Guru Mapel</a>
        <a class="<?php echo nav_active('nilai.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/nilai.php"><?php echo ikon('pencil'); ?> Input Nilai</a>
        <a class="<?php echo nav_active('sikap.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/sikap.php"><?php echo ikon('sprout'); ?> Sikap &amp; Catatan Wali Kelas</a>
        <a class="<?php echo nav_active('cetak_rapor.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/cetak_rapor.php"><?php echo ikon('printer'); ?> Cetak Rapor</a>

      <?php elseif (($modul_aktif ?? '') === 'manajemen'): ?>
        <div class="section-title">Manajemen Sekolah</div>
        <a class="<?php echo nav_active('dashboard.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/dashboard.php"><?php echo ikon('chart'); ?> Dashboard</a>
        <a class="<?php echo nav_active('tahun_ajaran.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/tahun_ajaran.php"><?php echo ikon('calendar'); ?> Tahun Ajaran</a>
        <a class="<?php echo nav_active('kelas.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/kelas.php"><?php echo ikon('school'); ?> Data Kelas</a>
        <a class="<?php echo nav_active('siswa.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/siswa.php"><?php echo ikon('student'); ?> Data Siswa</a>
        <a class="<?php echo nav_active('pegawai.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/pegawai.php"><?php echo ikon('staff'); ?> Data Guru &amp; Staf</a>
        <a class="<?php echo nav_active('users.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/users.php"><?php echo ikon('key'); ?> Akun Pengguna</a>
        <a class="<?php echo nav_active('kenaikan_kelas.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/kenaikan_kelas.php"><?php echo ikon('promote'); ?> Kenaikan Kelas</a>
        <a class="<?php echo nav_active('cetak_kartu.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/cetak_kartu.php"><?php echo ikon('qr'); ?> Cetak Kartu QR</a>
        <a class="<?php echo nav_active('beranda.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/beranda.php"><?php echo ikon('globe'); ?> Kelola Beranda</a>
        <a class="<?php echo nav_active('pengumuman.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/pengumuman.php"><?php echo ikon('megaphone'); ?> Pengumuman</a>
        <a class="<?php echo nav_active('pengaturan.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/pengaturan.php"><?php echo ikon('settings'); ?> Pengaturan Sekolah</a>
      <?php else: ?>
        <div class="section-title">Absensi Sekolah</div>
        <a class="<?php echo nav_active('beranda.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/beranda.php"><?php echo ikon('clipboard'); ?> Ringkasan Absensi</a>
        <a class="<?php echo nav_active('scan_pegawai.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/scan_pegawai.php"><?php echo ikon('camera'); ?> Scan Guru &amp; Staf</a>
        <a class="<?php echo nav_active('scan_siswa.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/scan_siswa.php"><?php echo ikon('camera'); ?> Scan Siswa (Semua Kelas)</a>
        <a class="<?php echo nav_active('manual_pegawai.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/manual_pegawai.php"><?php echo ikon('pencil'); ?> Input Manual Guru &amp; Staf</a>
        <a class="<?php echo nav_active('manual_siswa.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/manual_siswa.php"><?php echo ikon('pencil'); ?> Input Manual Siswa</a>
        <a class="<?php echo nav_active('pulang_awal.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/pulang_awal.php"><?php echo ikon('exit'); ?> Pulang Awal / Dipulangkan</a>
        <a class="<?php echo nav_active('rekap_pegawai.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/rekap_pegawai.php"><?php echo ikon('trend'); ?> Rekap Guru &amp; Staf</a>
        <a class="<?php echo nav_active('rekap_siswa.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/rekap_siswa.php"><?php echo ikon('trend'); ?> Rekap Siswa</a>
        <a class="<?php echo nav_active('permintaan_laporan.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/permintaan_laporan.php"><?php echo ikon('mail'); ?> Minta Laporan Wali Kelas</a>
      <?php endif; ?>

    <?php elseif ($role === 'bendahara'): ?>
      <div class="section-title">Keuangan Sekolah &amp; Komite</div>
      <a class="<?php echo nav_active('dashboard.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/dashboard.php"><?php echo ikon('chart'); ?> Dashboard Keuangan</a>
      <a class="<?php echo nav_active('transaksi.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/transaksi.php"><?php echo ikon('wallet'); ?> Buku Kas (Transaksi)</a>
      <a class="<?php echo nav_active('spp.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/spp.php"><?php echo ikon('receipt'); ?> SPP / Iuran Komite</a>
      <a class="<?php echo nav_active('gaji_honorer.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/gaji_honorer.php"><?php echo ikon('staff'); ?> Gaji Guru Honorer</a>
      <a class="<?php echo nav_active('kategori.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/kategori.php"><?php echo ikon('folder'); ?> Kategori Anggaran</a>
      <a class="<?php echo nav_active('laporan.php',$current); ?>" href="<?php echo BASE_URL; ?>keuangan/laporan.php"><?php echo ikon('printer'); ?> Cetak Laporan</a>
      <div class="section-title">Lainnya</div>
      <a class="<?php echo nav_active('pengumuman.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/pengumuman.php"><?php echo ikon('megaphone'); ?> Pengumuman</a>

    <?php elseif ($role === 'guru'): ?>
      <div class="section-title">Absensi Kelas Saya</div>
      <a class="<?php echo nav_active('beranda.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/beranda.php"><?php echo ikon('clipboard'); ?> Ringkasan Hari Ini</a>
      <a class="<?php echo nav_active('scan_siswa.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/scan_siswa.php"><?php echo ikon('camera'); ?> Scan Absen Siswa</a>
      <a class="<?php echo nav_active('manual_siswa.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/manual_siswa.php"><?php echo ikon('pencil'); ?> Input Manual (Sakit/Izin/Alpa)</a>
      <a class="<?php echo nav_active('pulang_awal.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/pulang_awal.php"><?php echo ikon('exit'); ?> Izin Pulang Awal</a>
      <a class="<?php echo nav_active('rekap_siswa.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/rekap_siswa.php"><?php echo ikon('trend'); ?> Rekap Kelas Saya</a>
      <?php
        $res_pending = mysqli_query($conn, "SELECT COUNT(*) c FROM laporan_bulanan WHERE kelas_id=" . (int)($_SESSION['kelas_id'] ?? 0) . " AND status='Diminta'");
        $jml_pending = $res_pending ? (int) (mysqli_fetch_assoc($res_pending)['c'] ?? 0) : 0;
      ?>
      <a class="<?php echo nav_active('laporan_saya.php',$current); ?>" href="<?php echo BASE_URL; ?>absensi/laporan_saya.php" style="display:flex;"><?php echo ikon('mail'); ?> Laporan Diminta Kepsek <?php if ($jml_pending > 0): ?><span class="badge-count"><?php echo $jml_pending; ?></span><?php endif; ?></a>

      <div class="section-title">E-Rapor / Akademik</div>
      <a class="<?php echo nav_active('nilai.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/nilai.php"><?php echo ikon('pencil'); ?> Input Nilai Mapel</a>
      <?php if (is_wali_kelas()): ?>
        <a class="<?php echo nav_active('sikap.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/sikap.php"><?php echo ikon('sprout'); ?> Sikap &amp; Catatan Wali Kelas</a>
        <a class="<?php echo nav_active('cetak_rapor.php',$current); ?>" href="<?php echo BASE_URL; ?>erapor/cetak_rapor.php"><?php echo ikon('printer'); ?> Cetak Rapor Kelas Saya</a>
      <?php endif; ?>

      <div class="section-title">Lainnya</div>
      <a class="<?php echo nav_active('cetak_kartu.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/cetak_kartu.php"><?php echo ikon('qr'); ?> Kartu QR Kelas Saya</a>
      <a class="<?php echo nav_active('pengumuman.php',$current); ?>" href="<?php echo BASE_URL; ?>manajemen/pengumuman.php"><?php echo ikon('megaphone'); ?> Pengumuman</a>
    <?php endif; ?>
  </nav>
  <?php $pf = profil_pengguna($conn); ?>
  <div class="user-box">
    <div class="user-card">
      <?php echo avatar_profil_html($pf); ?>
      <div class="user-info">
        <strong><?php echo bersihkan($pf['nama']); ?></strong>
        <span class="role"><?php echo bersihkan($pf['peran']); ?></span>
      </div>
    </div>
    <div class="nomor"><span><?php echo bersihkan($pf['label_nomor']); ?></span><b><?php echo $pf['nomor'] !== '' ? bersihkan($pf['nomor']) : '<em>belum diisi</em>'; ?></b></div>
    <a class="logout" href="<?php echo BASE_URL; ?>logout.php"><?php echo ikon('exit', 16); ?> Keluar</a>
  </div>
</aside>
