<?php
// =====================================================================
// FUNGSI CADANGAN: jika ekstensi mbstring tidak aktif di server, sistem tetap berjalan
// =====================================================================
if (!function_exists('mb_substr')) {
    function mb_substr($str, $start, $length = null, $enc = null) {
        $chars = preg_split('//u', (string)$str, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        return implode('', $length === null ? array_slice($chars, $start) : array_slice($chars, $start, $length));
    }
}
if (!function_exists('mb_strtoupper')) {
    function mb_strtoupper($str, $enc = null) { return strtoupper((string)$str); }
}
if (!function_exists('mb_strimwidth')) {
    function mb_strimwidth($str, $start, $width, $trim = '', $enc = null) {
        $str = (string)$str;
        $chars = preg_split('//u', $str, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (count($chars) - $start <= $width) return implode('', array_slice($chars, $start));
        $keep = max(0, $width - strlen($trim));
        return implode('', array_slice($chars, $start, $keep)) . $trim;
    }
}

// =====================================================================
// FUNGSI BANTUAN (HELPER FUNCTIONS)
// =====================================================================

function get_setting($conn, $key) {
    $key = mysqli_real_escape_string($conn, $key);
    $res = mysqli_query($conn, "SELECT nilai_pengaturan FROM pengaturan WHERE nama_pengaturan = '$key' LIMIT 1");
    if ($res && $row = mysqli_fetch_assoc($res)) {
        return $row['nilai_pengaturan'];
    }
    return null;
}

function set_setting($conn, $key, $value) {
    $key = mysqli_real_escape_string($conn, $key);
    $value = mysqli_real_escape_string($conn, $value);
    mysqli_query($conn, "INSERT INTO pengaturan (nama_pengaturan, nilai_pengaturan) VALUES ('$key','$value')
                          ON DUPLICATE KEY UPDATE nilai_pengaturan = '$value'");
}

function tahun_ajaran_aktif($conn) {
    $res = mysqli_query($conn, "SELECT * FROM tahun_ajaran WHERE status_aktif = 1 LIMIT 1");
    return $res ? mysqli_fetch_assoc($res) : null;
}

function generate_token($prefix, $length = 10) {
    return strtoupper($prefix . '-' . bin2hex(random_bytes($length)));
}

function badge_status($status) {
    $map = [
        'Hadir'     => 'badge-hadir',
        'Terlambat' => 'badge-terlambat',
        'Sakit'     => 'badge-sakit',
        'Izin'      => 'badge-izin',
        'Alpa'      => 'badge-alpa',
    ];
    $class = $map[$status] ?? 'badge-alpa';
    return '<span class="badge-status ' . $class . '">' . htmlspecialchars($status) . '</span>';
}

function format_tanggal_indo($tanggal) {
    if (!$tanggal) return '-';
    $bulan = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni',
              '07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
    $ts = strtotime($tanggal);
    return date('d', $ts) . ' ' . $bulan[date('m', $ts)] . ' ' . date('Y', $ts);
}

function salam_waktu() {
    $jam = (int) date('H');
    if ($jam < 11) return 'Selamat pagi';
    if ($jam < 15) return 'Selamat siang';
    if ($jam < 18) return 'Selamat sore';
    return 'Selamat malam';
}

// label tampilan untuk role akun (dipakai di Akun Pengguna & sidebar)
function label_role($role) {
    $map = [
        'kepala_sekolah' => 'Kepala Sekolah',
        'guru'           => 'Guru / Wali Kelas',
        'bendahara'      => 'Bendahara',
    ];
    return $map[$role] ?? ucfirst((string) $role);
}

// format angka menjadi Rupiah, contoh: 1500000 -> "Rp 1.500.000"
function rupiah($angka) {
    return 'Rp ' . number_format((float) $angka, 0, ',', '.');
}

// predikat huruf dari nilai akhir (skala 0-100), dipakai di e-rapor
function predikat_nilai($nilai, $kkm = 75) {
    if ($nilai === null || $nilai === '') return '-';
    $nilai = (float) $nilai;
    if ($nilai >= 90) return 'A';
    if ($nilai >= $kkm) return 'B';
    if ($nilai >= $kkm - 10) return 'C';
    return 'D';
}

// hitung nilai akhir (skala 0-100) dari komponen harian/UTS/UAS dengan bobot 30/30/40,
// bobot otomatis disesuaikan proporsional jika ada komponen yang belum diisi
function hitung_nilai_akhir($harian, $uts, $uas) {
    $komponen = ['harian' => [$harian, 0.3], 'uts' => [$uts, 0.3], 'uas' => [$uas, 0.4]];
    $total_bobot = 0; $total_nilai = 0;
    foreach ($komponen as [$nilai, $bobot]) {
        if ($nilai !== null && $nilai !== '') {
            $total_nilai += (float) $nilai * $bobot;
            $total_bobot += $bobot;
        }
    }
    if ($total_bobot <= 0) return null;
    return round($total_nilai / $total_bobot, 2);
}

function bersihkan($str) {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

// menentukan status kehadiran berdasarkan jam scan vs jam masuk yang ditentukan sekolah
function tentukan_status_masuk($conn, $waktu_scan) {
    $jam_masuk = get_setting($conn, 'jam_masuk') ?: '07:30:00';
    $toleransi = (int) (get_setting($conn, 'toleransi_terlambat_menit') ?: 15);
    $batas = date('H:i:s', strtotime($jam_masuk) + ($toleransi * 60));
    return ($waktu_scan <= $batas) ? 'Hadir' : 'Terlambat';
}

// --- Logo & Background sekolah (upload di menu Pengaturan) ---
function path_upload_dir() {
    return __DIR__ . '/../assets/img/uploads/';
}
function url_logo_sekolah($conn) {
    $file = get_setting($conn, 'logo_sekolah');
    if ($file && file_exists(path_upload_dir() . $file)) {
        return logo_bulat_url($file);
    }
    return null;
}

// ---------------------------------------------------------------------
// LOGO BULAT TRANSPARAN
// Logo yang berbentuk lingkaran sering diunggah dengan latar putih/abu-abu di sudut-sudutnya
// (JPG tidak bisa transparan). Fungsi di bawah membuat salinan PNG transparan otomatis:
// latar luar lingkaran dibuang, hanya logo bulatnya yang tersisa. File asli tidak diubah.
// Jika logo bukan bulat, atau ekstensi GD tidak ada, logo asli dipakai apa adanya.
// ---------------------------------------------------------------------
function logo_bulat_url($file) {
    $src = path_upload_dir() . $file;
    $asli = BASE_URL . 'assets/img/uploads/' . $file . '?v=' . filemtime($src);
    if (!function_exists('imagecreatefromstring')) return $asli;
    $nama = 'bulat_' . pathinfo($file, PATHINFO_FILENAME) . '.png';
    $dst  = path_upload_dir() . $nama;
    $gagal = $dst . '.skip';   // penanda: logo ini bukan bulat, jangan dicoba terus
    if (file_exists($gagal) && filemtime($gagal) >= filemtime($src)) return $asli;
    if (!file_exists($dst) || filemtime($dst) < filemtime($src)) {
        if (!proses_logo_bulat($src, $dst)) { @file_put_contents($gagal, '1'); return $asli; }
    }
    return BASE_URL . 'assets/img/uploads/' . $nama . '?v=' . filemtime($dst);
}
function hapus_logo_bulat($file) {
    if (!$file) return;
    $b = path_upload_dir() . 'bulat_' . pathinfo($file, PATHINFO_FILENAME) . '.png';
    if (file_exists($b)) @unlink($b);
    if (file_exists($b . '.skip')) @unlink($b . '.skip');
}
// Membuat PNG bulat transparan dari $src. Mengembalikan false jika logo tidak berbentuk lingkaran.
function proses_logo_bulat($src, $dst) {
    $im = @imagecreatefromstring((string)@file_get_contents($src));
    if (!$im) return false;
    $w = imagesx($im); $h = imagesy($im);
    if ($w < 20 || $h < 20 || $w * $h > 4000000) { imagedestroy($im); return false; }
    $pix = function ($x, $y) use ($im) {
        $c = imagecolorat($im, $x, $y);
        return [($c >> 24) & 127, ($c >> 16) & 255, ($c >> 8) & 255, $c & 255];
    };
    // warna latar = rata-rata empat sudut (atau transparan jika sudutnya sudah transparan)
    $sudut = [$pix(1,1), $pix($w-2,1), $pix(1,$h-2), $pix($w-2,$h-2)];
    $bgTransparan = true; $r = $g = $b = 0;
    foreach ($sudut as $c) { if ($c[0] < 100) $bgTransparan = false; $r += $c[1]; $g += $c[2]; $b += $c[3]; }
    $r = intdiv($r, 4); $g = intdiv($g, 4); $b = intdiv($b, 4);
    $isi = function ($x, $y) use ($pix, $bgTransparan, $r, $g, $b) {
        $c = $pix($x, $y);
        if ($bgTransparan) return $c[0] < 100;
        if ($c[0] >= 100) return false;
        return abs($c[1]-$r) + abs($c[2]-$g) + abs($c[3]-$b) > 60;
    };
    // kotak pembatas isi logo
    $minx = $w; $maxx = -1; $miny = $h; $maxy = -1;
    for ($y = 0; $y < $h; $y++) for ($x = 0; $x < $w; $x++) {
        if ($isi($x, $y)) { if ($x < $minx) $minx = $x; if ($x > $maxx) $maxx = $x; if ($y < $miny) $miny = $y; if ($y > $maxy) $maxy = $y; }
    }
    $bw = $maxx - $minx + 1; $bh = $maxy - $miny + 1;
    if ($maxx < 0 || $bw < 20 || $bh < 20 || $bw / $bh < 0.9 || $bw / $bh > 1.1) { imagedestroy($im); return false; }
    // pastikan benar-benar lingkaran: sudut kotak harus kosong (latar), bukan isi logo
    $in = (int) round(min($bw, $bh) * 0.04);
    foreach ([[$minx+$in,$miny+$in],[$maxx-$in,$miny+$in],[$minx+$in,$maxy-$in],[$maxx-$in,$maxy-$in]] as $t) {
        if ($isi($t[0], $t[1])) { imagedestroy($im); return false; }
    }
    $size = max($bw, $bh);
    $cx = $minx + $bw / 2; $cy = $miny + $bh / 2;
    $rad = $size / 2 - 1.2;                 // potong ~1 piksel di dalam tepi agar tidak ada halo putih
    $out = imagecreatetruecolor($size, $size);
    imagealphablending($out, false); imagesavealpha($out, true);
    imagefill($out, 0, 0, imagecolorallocatealpha($out, 0, 0, 0, 127));
    for ($y = 0; $y < $size; $y++) {
        for ($x = 0; $x < $size; $x++) {
            $dx = $x + 0.5 - $size / 2; $dy = $y + 0.5 - $size / 2;
            $a = $rad + 0.5 - sqrt($dx*$dx + $dy*$dy);       // tepi halus (anti-alias)
            if ($a <= 0) continue;
            if ($a > 1) $a = 1;
            $sx = (int) round($cx - $size / 2 + $x); $sy = (int) round($cy - $size / 2 + $y);
            if ($sx < 0 || $sy < 0 || $sx >= $w || $sy >= $h) continue;
            $c = $pix($sx, $sy);
            $alpha = 127 - (int) round((127 - $c[0]) * $a);
            imagesetpixel($out, $x, $y, imagecolorallocatealpha($out, $c[1], $c[2], $c[3], $alpha));
        }
    }
    $ok = @imagepng($out, $dst, 6);
    imagedestroy($im); imagedestroy($out);
    return $ok;
}
function url_background_sekolah($conn) {
    $file = get_setting($conn, 'background_sekolah');
    if ($file && file_exists(path_upload_dir() . $file)) {
        return BASE_URL . 'assets/img/uploads/' . $file . '?v=' . filemtime(path_upload_dir() . $file);
    }
    return null;
}

// Ikon garis (SVG) yang seragam untuk sidebar & dashboard, warna mengikuti teks (currentColor)
function ikon($nama, $ukuran = 18) {
    static $p = [
      'home'     => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
      'chart'    => '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
      'calendar' => '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
      'school'   => '<path d="M3 21h18"/><path d="M5 21V9l7-5 7 5v12"/><path d="M9 21v-5h6v5"/><path d="M12 9.5v.01"/>',
      'student'  => '<path d="m2 9 10-5 10 5-10 5z"/><path d="M6 11.5V16c0 1.4 2.7 3 6 3s6-1.6 6-3v-4.5"/>',
      'staff'    => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.4 3.2-5.5 6.5-5.5s5.9 2.1 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.8c1.9.8 3.1 2.6 3.5 5.2"/>',
      'key'      => '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M16 7l3 3M14 9l2 2"/>',
      'promote'  => '<circle cx="12" cy="12" r="9"/><path d="m8 12 4-4 4 4M12 8v8"/>',
      'qr'       => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><path d="M14 14h3v3M21 14v.01M14 21h.01M17 21h4v-4"/>',
      'globe'    => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.6 2.8 3.9 5.8 3.9 9s-1.3 6.2-3.9 9c-2.6-2.8-3.9-5.8-3.9-9S9.4 5.8 12 3z"/>',
      'megaphone'=> '<path d="M3 11v3a1 1 0 0 0 1 1h3l8 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M19 9a4 4 0 0 1 0 6"/>',
      'settings' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
      'clipboard'=> '<rect x="5" y="4" width="14" height="17" rx="2.5"/><path d="M9 4.5h6V3H9zM9 11h6M9 15h4"/>',
      'camera'   => '<path d="M4 8h3l1.5-2h7L17 8h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
      'pencil'   => '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
      'exit'     => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
      'trend'    => '<path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
      'mail'     => '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3.5 7 8.5 6 8.5-6"/>',
      'wallet'   => '<path d="M19 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5"/><path d="M17 14h.01"/>',
      'receipt'  => '<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
      'folder'   => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
      'printer'  => '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
      'book'     => '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5M9 7h6"/>',
      'sprout'   => '<path d="M12 21v-9"/><path d="M12 12C12 8 9 6 4 6c0 4 2.5 6 8 6z"/><path d="M12 14c0-3.2 2.4-5 7-5 0 3.4-2.2 5-7 5z"/>',
      'clock'    => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      'check'    => '<circle cx="12" cy="12" r="9"/><path d="m8 12 2.7 2.7L16 9.5"/>',
    ];
    $d = $p[$nama] ?? $p['home'];
    return '<svg class="ikon" width="' . $ukuran . '" height="' . $ukuran . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
}

// Logo KHUSUS jendela/banner di beranda publik (terpisah dari logo navbar & sidebar).
// Jika belum diunggah, otomatis memakai logo sekolah agar jendela tidak kosong.
function url_logo_beranda($conn) {
    $file = get_setting($conn, 'logo_beranda');
    if ($file && file_exists(path_upload_dir() . $file)) {
        return logo_bulat_url($file);
    }
    return url_logo_sekolah($conn);
}
// true jika logo beranda sudah diunggah sendiri (bukan fallback)
function logo_beranda_khusus_ada($conn) {
    $file = get_setting($conn, 'logo_beranda');
    return $file && file_exists(path_upload_dir() . $file);
}

// Profil akun yang sedang login: foto, nama, nomor induk (NIP/NUPTK), dan peran.
function profil_pengguna($conn) {
    static $p = null;
    if ($p !== null) return $p;
    $role = $_SESSION['role'] ?? '';
    $p = [
        'nama'  => $_SESSION['nama'] ?? 'Pengguna',
        'nomor' => '', 'label_nomor' => 'NIP/NUPTK', 'foto_url' => null,
        'peran' => label_role($role), 'jabatan' => '',
    ];
    $pid = (int)($_SESSION['pegawai_id'] ?? 0);
    if ($pid > 0) {
        $r = mysqli_query($conn, "SELECT nama, nip_nuptk, foto, jenis FROM pegawai WHERE id=$pid LIMIT 1");
        $d = $r ? mysqli_fetch_assoc($r) : null;
        if ($d) {
            $p['nama']     = $d['nama'] ?: $p['nama'];
            $p['nomor']    = trim((string)$d['nip_nuptk']);
            $p['foto_url'] = url_foto_profil($d['foto']);
            $p['jabatan']  = $d['jenis'];
        }
    }
    return $p;
}
// HTML avatar profil (foto bulat, atau inisial jika belum ada foto)
function avatar_profil_html($p, $kelas = 'user-ava') {
    if (!empty($p['foto_url'])) {
        return '<img src="' . $p['foto_url'] . '" class="' . $kelas . '" alt="Foto ' . htmlspecialchars($p['nama']) . '">';
    }
    $ini = $p['nama'] ? strtoupper(mb_substr(trim($p['nama']), 0, 1)) : '?';
    return '<span class="' . $kelas . ' ph">' . htmlspecialchars($ini) . '</span>';
}

// foto profil siswa/pegawai (kolom `foto` di tabel masing-masing)
function url_foto_profil($nama_file) {
    if ($nama_file && file_exists(path_upload_dir() . $nama_file)) {
        return BASE_URL . 'assets/img/uploads/' . $nama_file . '?v=' . filemtime(path_upload_dir() . $nama_file);
    }
    return null;
}


// Foto potret 3:4 untuk kartu struktur. Foto studio berlatar polos (merah/biru) dipotong otomatis
// agar orangnya memenuhi bingkai; hasil disimpan di cache (assets/img/uploads/struktur/) dan dibuat ulang
// bila foto sumber berubah. Jika GD tidak ada / gagal, foto asli dipakai apa adanya.
function foto_potret($nama_file, $lebar = 300, $tinggi = 400) {
    if (!$nama_file) return null;
    $nama_file = basename($nama_file);
    $src = path_upload_dir() . $nama_file;
    if (!is_file($src)) return null;
    $dirCache = path_upload_dir() . 'struktur/';
    $cache = $dirCache . 'p_' . md5($nama_file . $lebar . 'x' . $tinggi) . '.jpg';
    $url = function ($f) { return BASE_URL . 'assets/img/uploads/' . substr($f, strlen(path_upload_dir())) . '?v=' . filemtime($f); };
    if (is_file($cache) && filemtime($cache) >= filemtime($src)) return $url($cache);
    if (!function_exists('imagecreatetruecolor')) return url_foto_profil($nama_file);

    $info = @getimagesize($src);
    $im = null;
    if ($info) {
        if ($info[2] === IMAGETYPE_JPEG) $im = @imagecreatefromjpeg($src);
        elseif ($info[2] === IMAGETYPE_PNG) $im = @imagecreatefrompng($src);
        elseif ($info[2] === IMAGETYPE_WEBP && function_exists('imagecreatefromwebp')) $im = @imagecreatefromwebp($src);
    }
    if (!$im) return url_foto_profil($nama_file);
    $w = imagesx($im); $h = imagesy($im);

    // warna latar = warna dua sudut atas
    $rgb = function ($x, $y) use ($im) { $c = imagecolorat($im, $x, $y); return [($c >> 16) & 255, ($c >> 8) & 255, $c & 255]; };
    $bg = [$rgb(2, 2), $rgb($w - 3, 2)];
    $beda = function ($p) use ($bg) {
        foreach ($bg as $b) if (abs($p[0]-$b[0]) + abs($p[1]-$b[1]) + abs($p[2]-$b[2]) < 90) return false;
        return true;
    };
    // kotak pembatas objek (sampling tiap 3 px; baris/kolom dihitung bila >=3% pikselnya bukan latar)
    $st = 3; $minX = $w; $maxX = 0; $minY = $h; $maxY = 0;
    $kol = array_fill(0, $w, 0); $bar = array_fill(0, $h, 0);
    for ($y = 0; $y < $h; $y += $st) for ($x = 0; $x < $w; $x += $st) if ($beda($rgb($x, $y))) { $kol[$x]++; $bar[$y]++; }
    $ambangBar = max(2, (int)($w / $st * 0.03)); $ambangKol = max(2, (int)($h / $st * 0.03));
    for ($y = 0; $y < $h; $y += $st) if ($bar[$y] >= $ambangBar) { $minY = min($minY, $y); $maxY = max($maxY, $y); }
    for ($x = 0; $x < $w; $x += $st) if ($kol[$x] >= $ambangKol) { $minX = min($minX, $x); $maxX = max($maxX, $x); }

    $rasio = $lebar / $tinggi;
    if ($maxX - $minX < $w * 0.2 || $maxY - $minY < $h * 0.2) { $minX = 0; $maxX = $w; $minY = 0; $maxY = $h; } // gagal deteksi
    $bw = $maxX - $minX; $bh = $maxY - $minY;
    // beri ruang di atas kepala (±6%) dan sisi (±8%), lalu paskan ke rasio 3:4
    $cw = $bw * 1.16; $ch = $bh * 1.06;
    if ($cw / $ch > $rasio) $ch = $cw / $rasio; else $cw = $ch * $rasio;
    $cw = min($cw, $w); $ch = min($ch, $h);
    if ($cw / $ch > $rasio) $cw = $ch * $rasio; else $ch = $cw / $rasio;
    $cx = $minX + $bw / 2; $cx0 = (int)round(max(0, min($w - $cw, $cx - $cw / 2)));
    $cy0 = (int)round(max(0, min($h - $ch, $minY - $bh * 0.06)));  // jangkar di atas kepala

    $out = imagecreatetruecolor($lebar, $tinggi);
    imagecopyresampled($out, $im, 0, 0, $cx0, $cy0, $lebar, $tinggi, (int)round($cw), (int)round($ch));
    if (!is_dir($dirCache)) @mkdir($dirCache, 0755, true);
    $ok = @imagejpeg($out, $cache, 88);
    imagedestroy($im); imagedestroy($out);
    return $ok ? $url($cache) : url_foto_profil($nama_file);
}

// render avatar bulat kecil untuk tabel: foto asli jika ada, atau inisial nama sebagai placeholder
function render_avatar($nama, $nama_file_foto) {
    $url = url_foto_profil($nama_file_foto);
    if ($url) {
        return '<img src="' . $url . '" class="avatar-thumb" alt="Foto">';
    }
    $inisial = $nama ? strtoupper(mb_substr(trim($nama), 0, 1)) : '?';
    return '<span class="avatar-placeholder">' . htmlspecialchars($inisial) . '</span>';
}

// proses upload gambar (logo/background/foto profil) - mengembalikan nama file baru atau null jika gagal/tidak ada file
// $max_lebar / $max_tinggi: gambar otomatis diperkecil (resize) jika melebihi ukuran ini, supaya tampilan rapi & file tidak terlalu besar
function proses_upload_gambar($files_key, $prefix, $max_lebar = 1600, $max_tinggi = 1600) {
    if (empty($_FILES[$files_key]) || $_FILES[$files_key]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $tmp = $_FILES[$files_key]['tmp_name'];
    $info = @getimagesize($tmp);
    if (!$info) return false; // bukan file gambar valid
    $ext_map = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];
    $ext = $ext_map[$info[2]] ?? null;
    if (!$ext) return false;
    if ($_FILES[$files_key]['size'] > 8 * 1024 * 1024) return false; // maks 8MB sebelum diperkecil

    $nama_baru = $prefix . '_' . time() . '_' . mt_rand(1000,9999) . '.' . $ext;
    $tujuan = path_upload_dir() . $nama_baru;
    if (!is_dir(path_upload_dir())) @mkdir(path_upload_dir(), 0755, true);

    if (!move_uploaded_file($tmp, $tujuan)) return false;

    // perkecil otomatis jika melebihi ukuran maksimum (butuh ekstensi GD; jika tidak ada, file asli tetap dipakai)
    resize_gambar_jika_perlu($tujuan, $info[2], $max_lebar, $max_tinggi);

    return $nama_baru;
}

// perkecil gambar di tempat (in-place) menjaga rasio aspek, hanya jika GD tersedia dan gambar melebihi batas
function resize_gambar_jika_perlu($path_file, $tipe_gambar, $max_lebar, $max_tinggi) {
    if (!extension_loaded('gd')) return; // GD tidak tersedia di server ini, lewati resize (file asli tetap dipakai)

    [$lebar_asli, $tinggi_asli] = @getimagesize($path_file) ?: [0, 0];
    if (!$lebar_asli || !$tinggi_asli) return;
    if ($lebar_asli <= $max_lebar && $tinggi_asli <= $max_tinggi) return; // sudah cukup kecil, tidak perlu diapa-apakan

    $rasio = min($max_lebar / $lebar_asli, $max_tinggi / $tinggi_asli);
    $lebar_baru = max(1, (int) round($lebar_asli * $rasio));
    $tinggi_baru = max(1, (int) round($tinggi_asli * $rasio));

    try {
        switch ($tipe_gambar) {
            case IMAGETYPE_JPEG: $src = @imagecreatefromjpeg($path_file); break;
            case IMAGETYPE_PNG:  $src = @imagecreatefrompng($path_file); break;
            case IMAGETYPE_WEBP: $src = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path_file) : false; break;
            case IMAGETYPE_GIF:  $src = @imagecreatefromgif($path_file); break;
            default: $src = false;
        }
        if (!$src) return;

        $tujuan_img = imagecreatetruecolor($lebar_baru, $tinggi_baru);
        if ($tipe_gambar === IMAGETYPE_PNG || $tipe_gambar === IMAGETYPE_WEBP) {
            imagealphablending($tujuan_img, false);
            imagesavealpha($tujuan_img, true);
        }
        imagecopyresampled($tujuan_img, $src, 0, 0, 0, 0, $lebar_baru, $tinggi_baru, $lebar_asli, $tinggi_asli);

        switch ($tipe_gambar) {
            case IMAGETYPE_JPEG: imagejpeg($tujuan_img, $path_file, 85); break;
            case IMAGETYPE_PNG:  imagepng($tujuan_img, $path_file, 6); break;
            case IMAGETYPE_WEBP: if (function_exists('imagewebp')) imagewebp($tujuan_img, $path_file, 85); break;
            case IMAGETYPE_GIF:  imagegif($tujuan_img, $path_file); break;
        }
        imagedestroy($src);
        imagedestroy($tujuan_img);
    } catch (\Throwable $e) {
        // jika terjadi masalah saat resize, biarkan file asli (yang sudah divalidasi sebagai gambar) tetap dipakai
    }
}


// upload bukti dokumen (surat sakit / surat izin kegiatan) - menerima gambar (JPG/PNG/WEBP) ATAU PDF.
// Berbeda dari proses_upload_gambar() yang hanya menerima gambar. Mengembalikan nama file baru,
// null jika tidak ada file dipilih, atau false jika file tidak valid/gagal diunggah.
function proses_upload_dokumen($files_key, $prefix) {
    if (empty($_FILES[$files_key]) || $_FILES[$files_key]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    if ($_FILES[$files_key]['size'] > 8 * 1024 * 1024) return false; // maks 8MB

    $tmp = $_FILES[$files_key]['tmp_name'];
    $info = @getimagesize($tmp);
    $ext_map = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];

    if ($info && isset($ext_map[$info[2]])) {
        $ext = $ext_map[$info[2]];
        $gambar = true;
    } else {
        $handle = @fopen($tmp, 'rb');
        $head = $handle ? fread($handle, 4) : '';
        if ($handle) fclose($handle);
        if ($head !== '%PDF') return false; // bukan gambar maupun PDF yang valid
        $ext = 'pdf';
        $gambar = false;
    }

    if (!is_dir(path_upload_dir())) @mkdir(path_upload_dir(), 0755, true);
    $nama_baru = $prefix . '_' . time() . '_' . mt_rand(1000, 9999) . '.' . $ext;
    $tujuan = path_upload_dir() . $nama_baru;
    if (!move_uploaded_file($tmp, $tujuan)) return false;

    if ($gambar) resize_gambar_jika_perlu($tujuan, $info[2], 1600, 1600);

    return $nama_baru;
}

// true jika nama file bukti adalah PDF (dipakai untuk memilih ikon/tampilan link yang tepat)
function bukti_adalah_pdf($nama_file) {
    return $nama_file && strtolower(pathinfo($nama_file, PATHINFO_EXTENSION)) === 'pdf';
}

// Tandai otomatis status 'Alpa' untuk siswa/pegawai aktif yang SAMA SEKALI belum punya catatan
// absensi hari ini (tidak scan QR maupun diinput manual), begitu melewati jam batas yang diatur
// Kepala Sekolah (Pengaturan Sekolah > "Batas Otomatis Tandai Alpa", default 14:00 WIT).
// Hanya berlaku untuk HARI INI, aman dipanggil berkali-kali (idempotent): baris yang sudah ada
// tidak diubah/dobel. Jika nanti ternyata hadir, scan QR tetap bisa mengubah Alpa -> Hadir/Terlambat.
function tandai_alpa_otomatis($conn) {
    static $sudah_jalan = false;
    if ($sudah_jalan) return; // cukup sekali per request, query berikutnya di halaman yang sama tidak perlu diulang
    $sudah_jalan = true;

    $jam_batas = get_setting($conn, 'jam_batas_alpa') ?: '14:00:00';
    if (date('H:i:s') < $jam_batas) return; // belum lewat jam batas, jangan tandai dulu

    $tgl = date('Y-m-d');
    $ta = tahun_ajaran_aktif($conn);
    $ta_id = $ta['id'] ?? null;
    $ta_sql = $ta_id ? (int) $ta_id : 'NULL';

    mysqli_query($conn, "INSERT IGNORE INTO absensi_siswa (siswa_id, tahun_ajaran_id, tanggal, status, metode, keterangan)
                          SELECT s.id, $ta_sql, '$tgl', 'Alpa', 'Manual', 'Otomatis sistem: tidak ada catatan absensi sampai jam batas'
                          FROM siswa s
                          WHERE s.status='Aktif'
                            AND NOT EXISTS (SELECT 1 FROM absensi_siswa a WHERE a.siswa_id=s.id AND a.tanggal='$tgl')");

    mysqli_query($conn, "INSERT IGNORE INTO absensi_pegawai (pegawai_id, tanggal, status, metode, keterangan)
                          SELECT p.id, '$tgl', 'Alpa', 'Manual', 'Otomatis sistem: tidak ada catatan absensi sampai jam batas'
                          FROM pegawai p
                          WHERE p.status_aktif=1
                            AND NOT EXISTS (SELECT 1 FROM absensi_pegawai a WHERE a.pegawai_id=p.id AND a.tanggal='$tgl')");
}

// --- URL aset dengan versi (cache-busting) agar CSS/JS terbaru selalu dimuat browser ---
function aset($path) {
    return BASE_URL . $path . '?v=' . (@filemtime(__DIR__ . '/../' . $path) ?: 1);
}

// --- Pulang mendadak / dipulangkan sekolah (diumumkan Kepala Sekolah, berlaku HARI INI saja) ---
function pulang_khusus_hari_ini($conn) {
    if (get_setting($conn, 'pulang_khusus_tanggal') === date('Y-m-d')) {
        return ['jam' => get_setting($conn, 'pulang_khusus_jam') ?: date('H:i:s'), 'alasan' => get_setting($conn, 'pulang_khusus_alasan') ?: ''];
    }
    return null;
}

// jam mulai absen pulang dibuka (jam pulang dikurangi menit pembukaan awal, default 0)
function jam_buka_pulang($conn) {
    $jam = get_setting($conn, 'jam_pulang') ?: '13:45:00';
    $menit = (int) (get_setting($conn, 'pulang_buka_menit_sebelum') ?: 0);
    return date('H:i:s', strtotime($jam) - $menit * 60);
}

// kalimat jam untuk suara: "13 lewat 45 menit" / "13 tepat"
function ucapan_jam($hms) {
    [$h, $m] = explode(':', substr($hms, 0, 5));
    return ((int)$h) . ((int)$m === 0 ? ' tepat' : ' lewat ' . (int)$m . ' menit');
}

// tampilan jam pulang di tabel log + label jenis pulang bila bukan pulang normal
function tampil_jam_pulang($row) {
    if (empty($row['jam_pulang'])) return '-';
    $out = substr($row['jam_pulang'], 0, 5);
    $j = $row['jenis_pulang'] ?? '';
    if ($j === 'Izin Pulang Awal') $out .= ' <span class="pill" style="background:#fff3cd;color:#7a5a00;">Izin pulang awal</span>';
    elseif ($j === 'Dipulangkan Sekolah') $out .= ' <span class="pill" style="background:#e3f0fb;color:#0B3C5D;">Dipulangkan</span>';
    return $out;
}


// =====================================================================
// KEUANGAN: GAJI GURU HONORER (tarif per jam)
// =====================================================================

// nama bulan Indonesia dari format "YYYY-MM", contoh: "2026-09" -> "September 2026"
function nama_bulan_indo($ym) {
    $bulan = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni',
              '07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
    if (!preg_match('/^(\d{4})-(\d{2})$/', (string)$ym, $m)) return (string)$ym;
    return ($bulan[$m[2]] ?? $m[2]) . ' ' . $m[1];
}

// ubah isian uang dari form ("20.000", "Rp 20.000", "20000") menjadi angka
function parse_rupiah($teks) {
    $teks = preg_replace('/[^0-9,.]/', '', (string)$teks);
    return max(0, (float) str_replace(['.', ','], ['', '.'], $teks));
}

// ubah isian desimal dari form ("18", "18,5", "18.5") menjadi angka
function parse_desimal($teks) {
    $teks = preg_replace('/[^0-9,.]/', '', (string)$teks);
    return max(0, (float) str_replace(',', '.', $teks));
}

// tampilkan jumlah jam tanpa nol berlebih: 18 -> "18", 18.5 -> "18,5"
function format_jam($jam) {
    return rtrim(rtrim(number_format((float)$jam, 2, ',', '.'), '0'), ',');
}

// teks dari database (yang sebelumnya sudah di-escape saat disimpan) -> aman ditampilkan tanpa double-escape
function tampil_db($teks) {
    return htmlspecialchars(html_entity_decode((string)$teks, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'UTF-8');
}

// tarif honor per jam & jam dibayar per bulan (bisa diubah di halaman Gaji Guru Honorer)
function honor_tarif_default($conn) {
    $v = (float) get_setting($conn, 'honor_tarif_per_jam');
    return $v > 0 ? $v : 20000;
}
function honor_jam_default($conn) {
    $v = (float) get_setting($conn, 'honor_jam_per_bulan');
    return $v > 0 ? $v : 18;
}

// id kategori Buku Kas untuk gaji (dibuat otomatis bila belum ada)
function kategori_gaji_id($conn) {
    $r = mysqli_query($conn, "SELECT id FROM kategori_keuangan WHERE nama_kategori LIKE 'Gaji%' AND tipe='Pengeluaran' ORDER BY id LIMIT 1");
    if ($r && ($row = mysqli_fetch_assoc($r))) return (int) $row['id'];
    mysqli_query($conn, "INSERT INTO kategori_keuangan (nama_kategori, tipe) VALUES ('Gaji & Honor Guru/Staf','Pengeluaran')");
    return (int) mysqli_insert_id($conn);
}

// angka -> kalimat terbilang Bahasa Indonesia, contoh: 360000 -> "tiga ratus enam puluh ribu"
function terbilang($n) {
    $n = (int) floor(abs($n));
    $h = ['', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan', 'sembilan', 'sepuluh', 'sebelas'];
    if ($n < 12)         return $h[$n];
    if ($n < 20)         return terbilang($n - 10) . ' belas';
    if ($n < 100)        return terbilang(intdiv($n, 10)) . ' puluh' . ($n % 10 ? ' ' . terbilang($n % 10) : '');
    if ($n < 200)        return 'seratus' . ($n - 100 ? ' ' . terbilang($n - 100) : '');
    if ($n < 1000)       return terbilang(intdiv($n, 100)) . ' ratus' . ($n % 100 ? ' ' . terbilang($n % 100) : '');
    if ($n < 2000)       return 'seribu' . ($n - 1000 ? ' ' . terbilang($n - 1000) : '');
    if ($n < 1000000)    return terbilang(intdiv($n, 1000)) . ' ribu' . ($n % 1000 ? ' ' . terbilang($n % 1000) : '');
    if ($n < 1000000000) return terbilang(intdiv($n, 1000000)) . ' juta' . ($n % 1000000 ? ' ' . terbilang($n % 1000000) : '');
    return terbilang(intdiv($n, 1000000000)) . ' miliar' . ($n % 1000000000 ? ' ' . terbilang($n % 1000000000) : '');
}
function terbilang_rupiah($n) {
    $t = terbilang($n);
    return ucfirst($t === '' ? 'nol' : $t) . ' rupiah';
}
