<?php
// Variabel $judul_halaman bisa di-set sebelum include file ini
if (!isset($judul_halaman)) $judul_halaman = 'Sistem Sekolah';
$nama_sekolah = get_setting($conn, 'nama_sekolah') ?: 'SMAS YPK 1 Sorong';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo bersihkan($judul_halaman); ?> - <?php echo bersihkan($nama_sekolah); ?></title>
<link rel="stylesheet" href="<?php echo aset('assets/css/style.css'); ?>">
<script>window.SMS = { base: <?php echo json_encode(BASE_URL); ?>, bell: <?php echo !empty($_SESSION['user_id']) ? 'true' : 'false'; ?> };</script>
<script src="<?php echo aset('assets/js/notify.js'); ?>" defer></script>
</head>
<body>
<div class="papua-watermark"></div>
<button type="button" class="mobile-toggle" id="mobileToggleBtn" aria-label="Buka menu">☰</button>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<div class="app-shell">
