<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Akses Ditolak</title>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css"></head>
<body>
<div class="login-wrap">
  <div class="login-card" style="text-align:center;">
    <div class="school-badge">🔒</div>
    <h1>Akses Ditolak</h1>
    <p class="sub">Anda tidak memiliki izin untuk mengakses halaman ini.</p>
    <a class="btn btn-primary" href="<?php echo BASE_URL; ?>home.php">Kembali ke Beranda</a>
  </div>
</div>
</body></html>
