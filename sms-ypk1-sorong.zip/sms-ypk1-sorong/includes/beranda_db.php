<?php
// Tabel konten beranda publik + data awal (dibuat otomatis sekali)
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS beranda_konten (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seksi VARCHAR(30) NOT NULL,
  judul VARCHAR(200) NOT NULL,
  subjudul VARCHAR(200) DEFAULT NULL,
  isi TEXT DEFAULT NULL,
  gambar VARCHAR(255) DEFAULT NULL,
  level TINYINT NOT NULL DEFAULT 1,
  urutan INT NOT NULL DEFAULT 0,
  KEY (seksi, urutan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Migrasi: kolom penaut ke data pegawai (foto & NIP/NUPTK diambil otomatis dari tabel pegawai)
$cek = mysqli_query($conn, "SHOW COLUMNS FROM beranda_konten LIKE 'pegawai_id'");
if ($cek && mysqli_num_rows($cek) === 0) {
  mysqli_query($conn, "ALTER TABLE beranda_konten ADD COLUMN pegawai_id INT NULL DEFAULT NULL AFTER gambar");
}

$cek = mysqli_query($conn, "SHOW COLUMNS FROM beranda_konten LIKE 'kelompok'");
if ($cek && mysqli_num_rows($cek) === 0) {
  // kelompok otomatis: 'guru' (semua guru), 'wali_kelas' (dari Data Kelas), 'tata_usaha' (semua tata usaha)
  mysqli_query($conn, "ALTER TABLE beranda_konten ADD COLUMN kelompok VARCHAR(20) NULL DEFAULT NULL AFTER pegawai_id");
}

// Token dinamis: teks di beranda bisa memuat {siswa} {guru} {pegawai} {kelas} {tahun} {npsn} {email} {alamat}
// sehingga angka selalu mengikuti data di basis data. Kepala Sekolah boleh mengganti dengan angka biasa.
function tk($conn, $s) {
    static $v = null;
    if ($v === null) {
        $n = function ($q) use ($conn) { $r = mysqli_query($conn, $q); $x = $r ? mysqli_fetch_row($r) : [0]; return (int)$x[0]; };
        $v = [
          '{siswa}'   => $n("SELECT COUNT(*) FROM siswa WHERE status='Aktif'"),
          '{guru}'    => $n("SELECT COUNT(*) FROM pegawai WHERE status_aktif=1 AND jenis IN ('Kepala Sekolah','Guru')"),
          '{pegawai}' => $n("SELECT COUNT(*) FROM pegawai WHERE status_aktif=1"),
          '{kelas}'   => $n("SELECT COUNT(*) FROM kelas"),
          '{tahun}'   => (int)date('Y') - 1970,
          '{npsn}'    => get_setting($conn, 'npsn') ?: '60403645',
          '{email}'   => get_setting($conn, 'email_sekolah') ?: '-',
          '{alamat}'  => get_setting($conn, 'alamat_sekolah') ?: '-',
        ];
    }
    return strtr((string)$s, $v);
}

// Data awal (versi 2): profil resmi SMAS YPK 1 Kota Sorong
if ((int)get_setting($conn, 'beranda_seed_v') < 2) {
  set_setting($conn, 'nama_sekolah', 'SMAS YPK 1 Kota Sorong');
  set_setting($conn, 'alamat_sekolah', 'Jl. Mawar, Klademak IIIA, Kelurahan Klademak, Distrik Sorong Kota, Kota Sorong, Papua Barat Daya');
  mysqli_query($conn, "DELETE FROM beranda_konten");
  $seed = [
   ['hero','SMAS YPK 1 Kota Sorong','Selamat Datang di Sistem Informasi','Mencerdaskan generasi muda Papua: berwawasan, berbudaya, dan berdaya saing.',1],
   ['statistik','Siswa Aktif','{siswa}','',1],['statistik','Guru & Tenaga Pendidik','{guru}','',2],['statistik','Rombongan Belajar','{kelas}','',3],['statistik','Akreditasi','B','',4],['statistik','Tahun Berkarya','{tahun}+','',5],
   ['tentang','Tentang Kami','','SMAS YPK 1 merupakan institusi pendidikan jenjang Sekolah Menengah Atas (SMA) berstatus Swasta yang berlokasi di Distrik Sorong Kota, Kota Sorong, Papua Barat Daya. Berdiri sejak 1 Januari 1970 di bawah naungan Yayasan Pendidikan Kristen (YPK) di Tanah Papua, sekolah ini berkomitmen penuh dalam mencerdaskan generasi muda Papua. Saat ini SMAS YPK 1 telah mengantongi Akreditasi B dan didukung oleh {guru} tenaga pendidik profesional yang siap membimbing siswa-siswi menjadi pribadi yang berwawasan, berbudaya, dan berdaya saing.',1],
   ['identitas','Nama Sekolah','SMAS YPK 1 Kota Sorong','',1],['identitas','NPSN','{npsn}','',2],['identitas','Status Sekolah','Swasta','',3],['identitas','Bentuk Pendidikan','SMA (Sekolah Menengah Atas)','',4],
   ['identitas','Akreditasi','B (SK No. 572/BAN-SM-P/SK/2018)','',5],['identitas','Tanggal Berdiri','1 Januari 1970','',6],['identitas','Naungan','Yayasan Pendidikan Kristen (YPK) di Tanah Papua','',7],
   ['identitas','Waktu Penyelenggaraan','Pagi / 6 Hari','',8],['identitas','Kepala Sekolah','Juliana Pattipeilohy, S.Pd','',9],['identitas','Operator Dapodik','Selly Baselisa Bille, S.Pd','',10],
   ['visi','Visi','','Menjadi sekolah yang melahirkan generasi muda Papua yang berwawasan, berbudaya, beriman, dan berdaya saing.',1],
   ['misi','Pendidikan Beriman','','Menanamkan nilai iman dan moral Kristiani dalam setiap kegiatan belajar.',1],
   ['misi','Pembelajaran Bermutu','','Menyelenggarakan pembelajaran yang aktif dan bermutu dengan dukungan teknologi.',2],
   ['misi','Cinta Budaya Papua','','Menumbuhkan kebanggaan dan kepedulian terhadap budaya serta lingkungan Papua.',3],
   ['misi','Karakter & Daya Saing','','Membentuk siswa yang disiplin, mandiri, dan siap bersaing.',4],
   ['sejarah','Sekolah Berdiri','1 Januari 1970','SMAS YPK 1 didirikan di Kota Sorong di bawah naungan Yayasan Pendidikan Kristen (YPK) di Tanah Papua.',1],
   ['sejarah','Akreditasi B','2018','Sekolah memperoleh Akreditasi B berdasarkan SK BAN-SM No. 572/BAN-SM-P/SK/2018.',2],
   ['sejarah','Sistem Informasi Terpadu','Sekarang','Sekolah mengelola absensi QR Code, e-rapor, keuangan, dan data siswa dalam satu sistem informasi digital.',3],
   ['struktur','Yayasan Pendidikan Kristen (YPK) di Tanah Papua','Penaung Sekolah','',1],
   ['struktur','Kepala Sekolah','Juliana Pattipeilohy, S.Pd','',2],
   ['struktur','Tata Usaha & Operator Dapodik','Selly Baselisa Bille, S.Pd','',3],['struktur','Bendahara','Pengelola Keuangan Sekolah','',3],['struktur','Wali Kelas','Kelas X · XI A · XII','',3],
   ['struktur','Guru Mata Pelajaran','{guru} tenaga pendidik','',4],['struktur','Penjaga Sekolah','Keamanan & Kebersihan','',4],
   ['info','Jam Belajar','Informasi','Kegiatan belajar mengajar diselenggarakan pagi hari, enam hari dalam seminggu.',1],
   ['info','Penerimaan Peserta Didik Baru','Informasi','Hubungi sekolah untuk informasi pendaftaran dan persyaratan setiap tahun ajaran.',2],
   ['info','Absensi Digital QR Code','Layanan','Kehadiran siswa dan guru dicatat secara digital dan transparan.',3],
   ['kontak','Hubungi Kami','','{alamat}\nEmail: {email}',1],
  ];
  $st = mysqli_prepare($conn, "INSERT INTO beranda_konten (seksi,judul,subjudul,isi,level,urutan) VALUES (?,?,?,?,?,?)");
  foreach ($seed as $i => $r) { mysqli_stmt_bind_param($st,'ssssii',$r[0],$r[1],$r[2],$r[3],$r[4],$i); mysqli_stmt_execute($st); }
  set_setting($conn, 'beranda_seed_v', '2');
}

// Tautkan otomatis (sekali) jabatan tunggal di struktur ke data pegawai berdasarkan jenis pegawai.
// Kepala Sekolah dan Penjaga Sekolah ditautkan langsung; Tata Usaha ditautkan ke baris "Tata Usaha ...".
if ((int)get_setting($conn, 'beranda_link_v') < 1) {
  $map = ['Kepala Sekolah' => 'Kepala Sekolah', 'Tata Usaha%' => 'Tata Usaha', 'Penjaga Sekolah' => 'Penjaga Sekolah'];
  foreach ($map as $judulLike => $jenis) {
    $pg = mysqli_prepare($conn, "SELECT id FROM pegawai WHERE jenis=? AND status_aktif=1 ORDER BY id LIMIT 1");
    mysqli_stmt_bind_param($pg, 's', $jenis); mysqli_stmt_execute($pg);
    $row = mysqli_fetch_row(mysqli_stmt_get_result($pg));
    if ($row) {
      $pid = (int)$row[0];
      $up = mysqli_prepare($conn, "UPDATE beranda_konten SET pegawai_id=? WHERE seksi='struktur' AND judul LIKE ? AND pegawai_id IS NULL");
      mysqli_stmt_bind_param($up, 'is', $pid, $judulLike); mysqli_stmt_execute($up);
    }
  }
  set_setting($conn, 'beranda_link_v', '1');
}

// Versi 2: (a) "Guru Mata Pelajaran" & "Wali Kelas" menjadi kelompok otomatis yang menampilkan SELURUH
// guru/wali kelas dari data pegawai; (b) kartu yang namanya sama dengan data pegawai ditautkan otomatis.
if ((int)get_setting($conn, 'beranda_link_v') < 2) {
  mysqli_query($conn, "UPDATE beranda_konten SET kelompok='guru', pegawai_id=NULL WHERE seksi='struktur' AND judul LIKE 'Guru Mata Pelajaran%' AND kelompok IS NULL");
  mysqli_query($conn, "UPDATE beranda_konten SET kelompok='wali_kelas', pegawai_id=NULL WHERE seksi='struktur' AND judul LIKE 'Wali Kelas%' AND kelompok IS NULL");
  $norm = function ($t) { return preg_replace('/[^a-z0-9]/', '', strtolower((string)$t)); };
  $peg = [];
  $q = mysqli_query($conn, "SELECT id, nama FROM pegawai WHERE status_aktif=1");
  while ($q && $r = mysqli_fetch_assoc($q)) $peg[$norm($r['nama'])] = (int)$r['id'];
  $q = mysqli_query($conn, "SELECT id, subjudul FROM beranda_konten WHERE seksi='struktur' AND pegawai_id IS NULL AND kelompok IS NULL AND subjudul <> ''");
  while ($q && $r = mysqli_fetch_assoc($q)) {
    $k = $norm($r['subjudul']);
    if ($k !== '' && isset($peg[$k])) mysqli_query($conn, "UPDATE beranda_konten SET pegawai_id=".$peg[$k]." WHERE id=".(int)$r['id']);
  }
  set_setting($conn, 'beranda_link_v', '2');
}
