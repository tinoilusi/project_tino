<?php
/**
 * API notifikasi langsung (dipanggil lonceng di topbar setiap ±30 detik).
 *   GET  ?aksi=cek   -> daftar notifikasi sesuai peran + jumlah yang belum dibaca
 *   POST ?aksi=baca  -> tandai semua sudah dibaca (per akun, tersimpan di database)
 * Sumber notifikasi dihitung dari data yang sudah ada (pengumuman, laporan wali kelas,
 * pulang mendadak, keterlambatan/alpa guru & staf) sehingga tidak ada proses terjadwal (cron).
 */
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/includes/functions.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function keluar($arr, $kode = 200) { http_response_code($kode); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }

if (empty($_SESSION['user_id'])) keluar(['ok' => false, 'pesan' => 'Sesi berakhir'], 401);
$uid  = (int) $_SESSION['user_id'];
$role = $_SESSION['role'] ?? '';
$aksi = $_GET['aksi'] ?? 'cek';

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS notifikasi_dibaca (
  user_id INT NOT NULL PRIMARY KEY,
  terakhir_dibaca BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$now = time();
if ($aksi === 'baca') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') keluar(['ok' => false, 'pesan' => 'Gunakan POST'], 405);
    $st = mysqli_prepare($conn, "INSERT INTO notifikasi_dibaca (user_id, terakhir_dibaca) VALUES (?, ?) ON DUPLICATE KEY UPDATE terakhir_dibaca = VALUES(terakhir_dibaca)");
    mysqli_stmt_bind_param($st, 'ii', $uid, $now);
    mysqli_stmt_execute($st);
    keluar(['ok' => true, 'now' => $now]);
}

// batas "sudah dibaca": akun baru dianggap terakhir membaca 1 hari lalu
$st = mysqli_prepare($conn, "SELECT terakhir_dibaca FROM notifikasi_dibaca WHERE user_id = ?");
mysqli_stmt_bind_param($st, 'i', $uid); mysqli_stmt_execute($st);
$row = mysqli_fetch_row(mysqli_stmt_get_result($st));
$terakhir = $row ? (int) $row[0] : $now - 86400;

$items = [];
$tambah = function ($id, $tipe, $judul, $teks, $ts, $url = null) use (&$items, $terakhir) {
    $items[] = ['id' => $id, 'tipe' => $tipe, 'judul' => $judul, 'teks' => $teks, 'ts' => (int) $ts,
                'url' => $url, 'baru' => ((int) $ts > $terakhir)];
};
$potong = function ($t, $n = 110) { $t = trim(preg_replace('/\s+/', ' ', (string) $t)); return mb_strlen($t) > $n ? mb_substr($t, 0, $n - 1) . '…' : $t; };

// ---- 1. Pengumuman baru dari akun lain (semua peran) ----
$q = mysqli_query($conn, "SELECT id, judul, isi, dibuat_oleh, UNIX_TIMESTAMP(created_at) ts FROM pengumuman
                          WHERE created_at >= NOW() - INTERVAL 14 DAY ORDER BY created_at DESC LIMIT 8");
while ($q && $r = mysqli_fetch_assoc($q)) {
    if ((int) $r['dibuat_oleh'] === $uid) continue;
    $tambah('pg' . $r['id'], 'info', 'Pengumuman: ' . $potong($r['judul'], 70), $potong($r['isi']), $r['ts'], BASE_URL . 'manajemen/pengumuman.php');
}

// ---- 2. Sekolah dipulangkan mendadak hari ini (semua peran) ----
$khusus = pulang_khusus_hari_ini($conn);
if ($khusus) {
    $dibuat = (int) strtotime((string) get_setting($conn, 'pulang_khusus_dibuat')) ?: (int) strtotime(date('Y-m-d') . ' ' . $khusus['jam']);
    $tambah('pk' . date('Ymd'), 'warning', 'Sekolah dipulangkan mendadak',
            'Pulang pukul ' . substr($khusus['jam'], 0, 5) . ($khusus['alasan'] ? ' — ' . $potong($khusus['alasan'], 80) : ''),
            min($dibuat, $now), $role === 'kepala_sekolah' ? BASE_URL . 'absensi/pulang_awal.php' : null);
}

// ---- 3. Wali kelas: permintaan laporan dari Kepala Sekolah ----
if ($role === 'guru' && !empty($_SESSION['kelas_id'])) {
    $kid = (int) $_SESSION['kelas_id'];
    $q = mysqli_query($conn, "SELECT id, bulan, catatan_kepsek, UNIX_TIMESTAMP(tanggal_diminta) ts FROM laporan_bulanan
                              WHERE kelas_id = $kid AND status = 'Diminta' ORDER BY tanggal_diminta DESC LIMIT 5");
    while ($q && $r = mysqli_fetch_assoc($q)) {
        $tambah('lm' . $r['id'] . '_' . $r['ts'], 'warning', 'Kepala Sekolah meminta laporan bulan ' . $r['bulan'],
                $r['catatan_kepsek'] ? $potong($r['catatan_kepsek']) : 'Silakan kirim rekap kehadiran kelas Anda.', $r['ts'], BASE_URL . 'absensi/laporan_saya.php');
    }
}

if ($role === 'kepala_sekolah') {
    // ---- 4. Laporan masuk dari wali kelas ----
    $q = mysqli_query($conn, "SELECT l.id, l.bulan, k.nama_kelas, UNIX_TIMESTAMP(l.tanggal_dikirim) ts FROM laporan_bulanan l
                              JOIN kelas k ON k.id = l.kelas_id
                              WHERE l.status = 'Sudah Dikirim' AND l.tanggal_dikirim >= NOW() - INTERVAL 14 DAY
                              ORDER BY l.tanggal_dikirim DESC LIMIT 6");
    while ($q && $r = mysqli_fetch_assoc($q)) {
        $tambah('ld' . $r['id'] . '_' . $r['ts'], 'success', 'Laporan diterima dari wali kelas',
                'Kelas ' . $r['nama_kelas'] . ' mengirim laporan bulan ' . $r['bulan'] . '.', $r['ts'], BASE_URL . 'manajemen/permintaan_laporan.php');
    }

    // ---- 5. Guru & staf terlambat hari ini (real-time saat scan) ----
    $q = mysqli_query($conn, "SELECT a.id, p.nama, a.jam_masuk, UNIX_TIMESTAMP(a.created_at) ts FROM absensi_pegawai a
                              JOIN pegawai p ON p.id = a.pegawai_id
                              WHERE a.tanggal = CURDATE() AND a.status = 'Terlambat' ORDER BY a.created_at DESC LIMIT 8");
    while ($q && $r = mysqli_fetch_assoc($q)) {
        $tambah('tl' . $r['id'], 'warning', $potong($r['nama'], 60) . ' terlambat',
                'Absen masuk pukul ' . substr((string) $r['jam_masuk'], 0, 5) . '.', $r['ts'], BASE_URL . 'absensi/rekap_pegawai.php');
    }

    // ---- 6. Guru & staf alpa hari ini (ditandai otomatis lewat jam batas) ----
    $r = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) n, MAX(UNIX_TIMESTAMP(created_at)) ts FROM absensi_pegawai WHERE tanggal = CURDATE() AND status = 'Alpa'"));
    if ($r && (int) $r['n'] > 0) {
        $tambah('al' . date('Ymd') . '_' . (int) $r['n'], 'error', (int) $r['n'] . ' guru/staf alpa hari ini',
                'Tidak ada catatan kehadiran sampai jam batas.', $r['ts'], BASE_URL . 'absensi/rekap_pegawai.php');
    }
}

usort($items, function ($a, $b) { return $b['ts'] <=> $a['ts']; });
$items = array_slice($items, 0, 20);
$unread = count(array_filter($items, function ($i) { return $i['baru']; }));

keluar(['ok' => true, 'now' => $now, 'unread' => $unread, 'items' => $items]);
